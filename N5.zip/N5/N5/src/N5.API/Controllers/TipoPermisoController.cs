﻿using MediatR;
using Microsoft.AspNetCore.Mvc;
using N5.Domain.Features.Queries;
using System.Net;

namespace N5.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TipoPermisoController : ControllerBase
    {
        private readonly IMediator _mediator;

        public TipoPermisoController(IMediator mediator)
        {
            _mediator = mediator;
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> TipoPermisoById([FromRoute] TipoPermisoByIdQuery qry, CancellationToken cancellationToken)
        {
          
            var resultado = await _mediator.Send(qry, cancellationToken);

            return Ok(resultado);
        
        }

        [HttpGet]
        public async Task<IActionResult> TipoPermisoAll(CancellationToken cancellationToken)
        {
            var qry = new TipoPermisoAllQuery();

            var resultado = await _mediator.Send(qry, cancellationToken);

            return Ok(resultado);

        }

    }
}
