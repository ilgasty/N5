﻿using MediatR;
using Microsoft.AspNetCore.Mvc;
using N5.Domain.DTOs;
using N5.Domain.Features.Queries;
using N5.Domain.Features.Commands;
using Confluent.Kafka;
using System.Text.Json;
using Nest;
using ElasticsearchCRUDNSP;

namespace N5.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public partial class PermisoController : ControllerBase
    {
        private readonly IMediator _mediator;
        private readonly ProducerConfig config = new ProducerConfig { BootstrapServers = "localhost:9092" };
        private readonly string topic = "topic_N5";

        private ConnectionSettings _connectionSettings = new ConnectionSettings(new Uri("http://localhost:9200"))
                                                                          .EnableApiVersioningHeader()
                                                                          .BasicAuthentication("elastic", "FB05frj9mu7uQOBuoYJe");
        private ElasticsearchCRUD _elasticsearchCRUD;

        public PermisoController(IMediator mediator) //, ProducerConfig _config , ConnectionSettings connectionSettings)
        {
            _mediator = mediator;
            //config = _config;
            //_connectionSettings=connectionSettings;
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> PermisoById([FromRoute] PermisoByIdQuery qry, CancellationToken cancellationToken)
        {
            
            var resultado = await _mediator.Send(qry, cancellationToken);

            var a = SendToKafka(topic, "get");


            var client = new ElasticClient(_connectionSettings);

            _elasticsearchCRUD = new ElasticsearchCRUD(client, "n5index");
            await _elasticsearchCRUD.CreateIndexIfNotExists("n5index");

            var document = resultado;

            var resElastic = await _elasticsearchCRUD.AddOrUpdate(document);

            var resGet = await _elasticsearchCRUD.Get<PermisoDto>(qry.id.ToString());

            return Ok(resultado);

        }


        [HttpGet]
        public async Task<IActionResult> PermisoAll(CancellationToken cancellationToken)
        {
            var qry = new PermisoAllQuery();

            var resultado = await _mediator.Send(qry, cancellationToken);

            var a = SendToKafka(topic, "get");

            return Ok(resultado);

        }



        [HttpPost]
        public async Task<IActionResult> PermisoRequest([FromBody] PermisoAddCommand permisoComd, CancellationToken cancellationToken) 
        {

            var resultado = await _mediator.Send(permisoComd, cancellationToken);

            var a = SendToKafka(topic, "request");


            var client = new ElasticClient(_connectionSettings);

            _elasticsearchCRUD = new ElasticsearchCRUD(client, "n5index");
            await _elasticsearchCRUD.CreateIndexIfNotExists("n5index");

            var document = permisoComd;

            var resElastic = await _elasticsearchCRUD.AddOrUpdate(document);

            return Ok(resultado);
        }


        [HttpPut]
        public async Task<IActionResult> PermisoModify([FromBody] PermisoUpdtCommand permisoMdfy, CancellationToken cancellationToken)
        {

            var resultado = await _mediator.Send(permisoMdfy, cancellationToken);

            var a = SendToKafka(topic, "modify");

            var client = new ElasticClient(_connectionSettings);

            _elasticsearchCRUD = new ElasticsearchCRUD(client, "n5index");
            await _elasticsearchCRUD.CreateIndexIfNotExists("n5index");

            var document = permisoMdfy;

            var resElastic = await _elasticsearchCRUD.AddOrUpdate(document);

            return Ok(resultado);
        }


        private async Task<bool> SendToKafka(string topic, string message)
        {
            bool resKafka;

            using (var producer =
                 new ProducerBuilder<Null, string>(config).Build())
            {
                try
                {
                    var topicMsg = JsonSerializer.Serialize(new KafkaMsgDto { id = Guid.NewGuid(), Name = message });

                    var result = await producer.ProduceAsync(topic, new Message<Null, string> { Value = topicMsg });

                    Console.WriteLine($"Enviado a las :{ result.Timestamp.UtcDateTime}");

                    resKafka = true;

                }
                catch (Exception e)
                {
                    Console.WriteLine($"Error al enviar : {e}");
                    resKafka = false;
                }
            }
            return resKafka;
        }

    }
}
