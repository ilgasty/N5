﻿using AutoMapper;
using Confluent.Kafka;
using Microsoft.EntityFrameworkCore;
using N5.Domain.Contracts;
using N5.Infraestructure.Persistence;
using Nest;

namespace N5.API
{
    public class Startup
    {
        public Startup(IConfiguration configuration) { Configuration = configuration; }
        public IConfiguration Configuration { get; }

        public void ConfigureServices(IServiceCollection services)
        {
            services.AddCors(o => o.AddPolicy("corsApp", builder =>
            {

                builder.AllowAnyOrigin();
                builder.AllowAnyMethod();
                builder.AllowAnyHeader();

            }));
            
            services.AddControllers();
           
            services.AddDbContext<GenericDBContext>(options => options.UseSqlServer(
                    Configuration.GetConnectionString("APIDBConection")

                    ));

            services.AddScoped<IGenericDBContext, GenericDBContext>();

            services.AddScoped<IUnitOfWork, UnitOfWork>();

            services.AddScoped<ProducerConfig>();

            services.AddScoped<ConnectionSettings>();
       

            services.AddMediatR(cfg => cfg.RegisterServicesFromAssemblies(AppDomain.CurrentDomain.GetAssemblies()));

            var mappingConfig = new MapperConfiguration(cfg => { cfg.AddMaps((AppDomain.CurrentDomain.GetAssemblies())); });
            IMapper mapper = mappingConfig.CreateMapper();
            services.AddSingleton(mapper);
            
        }   

        public void Configure(IApplicationBuilder app, IWebHostEnvironment env) {
            app.UseCors("corsApp");
            app.UseHttpsRedirection();
                app.UseRouting();
                app.UseAuthorization();
                //app.UseSwagger();
                //app.UseSwaggerUI();
                app.UseEndpoints(endpoints => {
                    endpoints.MapControllers();
                });
                app.UseStaticFiles(new StaticFileOptions { ServeUnknownFileTypes = true });
           
        }
    }
}
