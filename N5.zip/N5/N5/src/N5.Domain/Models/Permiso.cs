﻿using N5.Domain.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Reflection.PortableExecutable;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;

namespace N5.Domain.Models
{
    public class Permiso : BaseEntitity
    {
        public string NombreEmpleado { get; set; }
        public string ApellidoEmpleado { get; set; }
        public DateTime FechaPermiso { get; set; }

        [ForeignKey("TipoPermiso")]
        public int TipoPermisoId { get; set; }
        public virtual TipoPermiso TipoPermiso { get; set; }

    }
}
