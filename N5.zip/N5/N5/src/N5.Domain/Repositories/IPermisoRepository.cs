﻿using N5.Domain.Models;

namespace N5.Domain.Repositories
{
    public interface IPermisoRepository : IGenericRepository<Permiso>
    {

        

    }
}
