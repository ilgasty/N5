﻿

namespace N5.Domain.DTOs
{
    public class PermisoDto
    {
        public int Id { get; set; }
        public string NombreEmpleado { get; set; }
        public string ApellidoEmpleado { get; set; }
        public DateTime FechaPermiso { get; set; }
        public int TipoPermisoId { get; set; }
        public virtual TipoPermisoDto TipoPermiso { get; set; }

    }
}
