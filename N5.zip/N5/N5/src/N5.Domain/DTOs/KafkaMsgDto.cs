﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace N5.Domain.DTOs
{
    public  class KafkaMsgDto
    {
        public Guid id { get; set; }
        public string Name { get; set; }


    }
}
