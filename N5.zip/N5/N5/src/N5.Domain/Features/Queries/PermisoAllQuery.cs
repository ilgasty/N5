﻿using MediatR;
using N5.Domain.DTOs;

namespace N5.Domain.Features.Queries
{
    public class PermisoAllQuery : IRequest<List<PermisoDto>>
    {

    }




}
