﻿using MediatR;
using N5.Domain.DTOs;
using N5.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace N5.Domain.Features.Queries
{
    public class TipoPermisoByIdQuery: IRequest<TipoPermisoDto>
    {
        public int id{ get; set; }
    }

}
