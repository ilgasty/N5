﻿using MediatR;
using N5.Domain.DTOs;

namespace N5.Domain.Features.Commands
{
  
    public class PermisoAddCommand : IRequest<int> {
        public string nombre_empleado { get; set; }
        public string apellido_empleado { get; set; }
        public string fecha_permiso { get; set; }
        public int tipo_permiso { get; set; }
    }

  
}
