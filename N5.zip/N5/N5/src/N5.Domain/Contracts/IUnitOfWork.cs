﻿using N5.Domain.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace N5.Domain.Contracts
{
    public interface IUnitOfWork: IDisposable
    {
        IPermisoRepository PermisoRepository { get; }
        ITipoPermisoRepository TipoPermisoRepository { get; }

        Task<int> Save();
    }
}
