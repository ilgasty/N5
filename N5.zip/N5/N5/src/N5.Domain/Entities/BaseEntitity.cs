﻿using System.ComponentModel.DataAnnotations;

namespace N5.Domain.Entities
{
    public abstract class BaseEntitity
    {
        [Key]
        public int Id { get; set; }
      
    }
}