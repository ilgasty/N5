﻿using AutoMapper;
using N5.Domain.DTOs;
using N5.Domain.Models;
using N5.Domain.Features.Commands;

namespace N5.Infraestructure.Profiles
{
    public class MappingProfile: Profile
    {
        public MappingProfile()
        {
            CreateMap<Permiso, PermisoDto>().ReverseMap();
            
            CreateMap<TipoPermiso, TipoPermisoDto>().ReverseMap();


            CreateMap<PermisoAddCommand, Permiso>()
                .ForMember(m => m.NombreEmpleado, opt => opt.MapFrom(m => m.nombre_empleado))
                .ForMember(m => m.ApellidoEmpleado, opt => opt.MapFrom(m => m.apellido_empleado))
                .ForMember(m => m.FechaPermiso, opt => opt.MapFrom(m => DateTime.ParseExact(m.fecha_permiso, "yyyy-MM-dd", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None)))
                .ForMember(m => m.TipoPermisoId, opt => opt.MapFrom(m => m.tipo_permiso))
                .ReverseMap();


            CreateMap<PermisoUpdtCommand, Permiso>()
               .ForMember(m => m.NombreEmpleado, opt => opt.MapFrom(m => m.nombre_empleado))
               .ForMember(m => m.ApellidoEmpleado, opt => opt.MapFrom(m => m.apellido_empleado))
               .ForMember(m => m.FechaPermiso, opt => opt.MapFrom(m => DateTime.ParseExact(m.fecha_permiso, "yyyy-MM-dd", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None)))
               .ForMember(m => m.TipoPermisoId, opt => opt.MapFrom(m => m.tipo_permiso))
               .ForMember(m => m.Id, opt => opt.MapFrom(m => m.empleado_id))
               .ReverseMap();

        }

    }
}