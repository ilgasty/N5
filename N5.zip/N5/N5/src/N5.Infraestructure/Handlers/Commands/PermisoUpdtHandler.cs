﻿using AutoMapper;
using MediatR;
using N5.Domain.Contracts;
using N5.Domain.Models;
using N5.Domain.Features.Commands;
using N5.Infraestructure.Validators;
using System.Threading.Channels;

namespace N5.Infraestructure.Handlers.Commands
{
        public class PermisoUpdtHandler : IRequestHandler<PermisoUpdtCommand, int>
        {
            private readonly IUnitOfWork _unitOfWork;
            private readonly IMapper _mapper;

            public PermisoUpdtHandler(IUnitOfWork unitOfWork, IMapper mapper)
            {
                _unitOfWork = unitOfWork;
                _mapper = mapper;
            }

            public async Task<int> Handle(PermisoUpdtCommand request, CancellationToken cancellationToken)
            {
                try
                {
                    //Valido formato datos request

                    var validator = new PermisoUpdtValidator();
                    var resValidator = validator.Validate(request);

                    if (!resValidator.IsValid)
                    {
                        return -1;
                    }

                    var addReq = _mapper.Map<Permiso>(request);

                    //Grabo
                    _unitOfWork.PermisoRepository.Update(addReq);
                 
                    //confirmo
                    var res = await _unitOfWork.Save();

                    Console.WriteLine(res);

                    return res; 

                }
                catch (Exception ex)
                {
                   Console.WriteLine($"{ex.Message} ");
                   if (ex.InnerException != null)
                    {
                        Console.WriteLine($" Inner {ex.InnerException.Message} ");
                    }

                    return -1;
                }
            }
 

    }
}
