﻿using AutoMapper;
using MediatR;
using N5.Domain.Contracts;
using N5.Domain.Models;
using N5.Domain.Features.Commands;
using N5.Infraestructure.Validators;

namespace N5.Infraestructure.Handlers.Commands
{
        public class PermisoAddHandler : IRequestHandler<PermisoAddCommand, int>
        {
            private readonly IUnitOfWork _unitOfWork;
            private readonly IMapper _mapper;

            public PermisoAddHandler(IUnitOfWork unitOfWork, IMapper mapper)
            {
                _unitOfWork = unitOfWork;
                _mapper = mapper;
            }

            public async Task<int> Handle(PermisoAddCommand request, CancellationToken cancellationToken)
            {
                try
                {
                    //Valido formato datos request
                    var validator = new PermisoAddValidator();
                    var resValidator = validator.Validate(request);

                    if (!resValidator.IsValid)
                    {
                        return -1;
                    }

                    var addReq = _mapper.Map<Permiso>(request);

                    //Grado
                    _unitOfWork.PermisoRepository.Add(addReq);

                    //confirmo
                    var res = await _unitOfWork.Save();

                    ///insert elastic
                   

                    ///insert kafka
                    

                    return res; 

                }
                catch (Exception ex)
                {
                    Console.WriteLine($"{ex.Message} ");
                    if (ex.InnerException != null)
                    {
                        Console.WriteLine($" Inner {ex.InnerException.Message} ");
                    }
                    return -1;
                }
            }
 

    }
}
