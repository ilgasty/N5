﻿using AutoMapper;
using MediatR;
using N5.Domain.Contracts;
using N5.Domain.DTOs;
using N5.Domain.Features.Queries;
using N5.Infraestructure.Validators;

namespace N5.Infraestructure.Handlers.Queries

{
    public class TipoPermisoByIdHandler : IRequestHandler<TipoPermisoByIdQuery, TipoPermisoDto>
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly IMapper _mapper;

        public TipoPermisoByIdHandler(IUnitOfWork unitOfWork, IMapper mapper)
        {
            _unitOfWork = unitOfWork;
            _mapper = mapper;
        }

        public async Task<TipoPermisoDto> Handle(TipoPermisoByIdQuery request, CancellationToken cancellationToken)
        {
            try
            {
                //Valido formato datos request

                var validator= new TipoPermisoByIdValidator();
                var resValidator= validator.Validate(request);

                if (!resValidator.IsValid) {
                    return new TipoPermisoDto();
                }

                //Obtengo datos 
                var res = await _unitOfWork.TipoPermisoRepository.GetById(request.id);

                Console.WriteLine(res );


                return _mapper.Map<TipoPermisoDto>(res);

            }catch (Exception ex)
            {
                return new TipoPermisoDto();
            }
        }
    }

}
