﻿using AutoMapper;
using MediatR;
using N5.Domain.Contracts;
using N5.Domain.DTOs;
using N5.Domain.Features.Queries;
using N5.Infraestructure.Validators;

namespace N5.Infraestructure.Handlers.Queries

{
    public class PermisoByIdHandler : IRequestHandler<PermisoByIdQuery, PermisoDto>
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly IMapper _mapper;

        public PermisoByIdHandler(IUnitOfWork unitOfWork, IMapper mapper)
        {
            _unitOfWork = unitOfWork;
            _mapper = mapper;
        }

        public async Task<PermisoDto> Handle(PermisoByIdQuery request, CancellationToken cancellationToken)
        {
            try
            {
                //Valido formato datos request

                var validator= new PermisoByIdValidator();
                var resValidator= validator.Validate(request);

                if (!resValidator.IsValid) {
                    return new PermisoDto();
                }

                //Obtengo datos 
                var res = await _unitOfWork.PermisoRepository.GetById(request.id);

                Console.WriteLine(res );


                return _mapper.Map<PermisoDto>(res);

            }catch (Exception ex)
            {
                Console.WriteLine($"{ex.Message} ");
                if (ex.InnerException != null)
                {
                    Console.WriteLine($" Inner {ex.InnerException.Message} ");
                }
                return new PermisoDto();
            }
        }
    }

}
