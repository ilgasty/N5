﻿using AutoMapper;
using MediatR;
using N5.Domain.Contracts;
using N5.Domain.DTOs;
using N5.Domain.Features.Queries;

namespace N5.Infraestructure.Handlers.Queries
{
    public class TipoPermisoAllHandler : IRequestHandler<TipoPermisoAllQuery, List<TipoPermisoDto>>
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly IMapper _mapper;

        public TipoPermisoAllHandler(IUnitOfWork unitOfWork, IMapper mapper)
        {
            _unitOfWork = unitOfWork;
            _mapper = mapper;
        }

        public async Task<List<TipoPermisoDto>> Handle(TipoPermisoAllQuery request, CancellationToken cancellationToken)
        {
            try
            {

                //Obtengo datos 
                var res = await _unitOfWork.TipoPermisoRepository.GetAll();

                Console.WriteLine(res);


                return _mapper.Map<List<TipoPermisoDto>>(res);

            }
            catch (Exception ex)
            {
                return new List<TipoPermisoDto>();
            }
        }
    }




}
