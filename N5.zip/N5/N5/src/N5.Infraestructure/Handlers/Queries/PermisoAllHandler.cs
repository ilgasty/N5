﻿using AutoMapper;
using MediatR;
using N5.Domain.Contracts;
using N5.Domain.DTOs;
using N5.Domain.Features.Queries;

namespace N5.Infraestructure.Handlers.Queries
{
    public class PermisoAllHandler : IRequestHandler<PermisoAllQuery, List<PermisoDto>>
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly IMapper _mapper;

        public PermisoAllHandler(IUnitOfWork unitOfWork, IMapper mapper)
        {
            _unitOfWork = unitOfWork;
            _mapper = mapper;
        }

        public async Task<List<PermisoDto>> Handle(PermisoAllQuery request, CancellationToken cancellationToken)
        {
            try
            {

                //Obtengo datos 
                var res = await _unitOfWork.PermisoRepository.GetAll();

                Console.WriteLine(res);


                return _mapper.Map<List<PermisoDto>>(res);

            }
            catch (Exception ex)
            {
                return new List<PermisoDto>();
            }
        }
    }




}
