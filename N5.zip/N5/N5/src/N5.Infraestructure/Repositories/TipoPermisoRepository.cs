﻿using N5.Domain.Models;
using N5.Domain.Repositories;
using N5.Infraestructure.Persistence;

namespace N5.Infraestructure.Repositories
{
    class TipoPermisoRepository : GenericRepository<TipoPermiso>, ITipoPermisoRepository
    {
        public TipoPermisoRepository(GenericDBContext context) : base(context) { }
    }
}
