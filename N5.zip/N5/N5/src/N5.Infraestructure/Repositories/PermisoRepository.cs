﻿using Microsoft.EntityFrameworkCore;
using N5.Domain.Models;
using N5.Domain.Repositories;
using N5.Infraestructure.Persistence;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace N5.Infraestructure.Repositories
{
    class PermisoRepository : GenericRepository<Permiso>, IPermisoRepository
    {
        private readonly GenericDBContext _context;
        public PermisoRepository(GenericDBContext context) : base(context) 
        { 
            _context = context;
           
        }


        public async Task<Permiso> GetById(int id)
        {
            return await _context.Set<Permiso>()
                                 .Include(c => c.TipoPermiso)
                                 .FirstOrDefaultAsync(c => c.Id == id);       
        }


        public async Task<IEnumerable<Permiso>> GetAll()
        {
            return await _context.Set<Permiso>()
                                  .Include(c => c.TipoPermiso)
                                  .ToListAsync();
        }

    }
}
