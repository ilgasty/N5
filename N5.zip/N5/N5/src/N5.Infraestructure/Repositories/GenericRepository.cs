﻿using Microsoft.EntityFrameworkCore;
using N5.Domain.Repositories;
using N5.Infraestructure.Persistence;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace N5.Infraestructure.Repositories
{
    public class GenericRepository<T> : IGenericRepository<T> where T : class
    {
        private readonly GenericDBContext _dbContext;
        public GenericRepository(GenericDBContext dbContext)
        {
                this._dbContext = dbContext;
        }
        public async void Add(T entity)
        {
            await _dbContext.Set<T>().AddAsync(entity);
        }

        public async Task<T> GetById(int id)
        {
            return await _dbContext.Set<T>().FindAsync(id);
        }

        public async Task<IEnumerable<T>> GetAll()
        {
            return await _dbContext.Set<T>().ToListAsync();
        }


        public async void Update (T entity)
        {
            _dbContext.Set<T>().Update(entity);
        }

        public void AddRange(IEnumerable<T> entities)
        {
            throw new NotImplementedException();
        }

        public Task<IEnumerable<T>> Find(Expression<Func<T, bool>> expression)
        {
            throw new NotImplementedException();
        }

        
        public void Remove(T entity)
        {
            throw new NotImplementedException();
        }

        public void RemoveRange(IEnumerable<T> entities)
        {
            throw new NotImplementedException();
        }

    }
}
