﻿using N5.Domain.Contracts;
using N5.Domain.Repositories;
using N5.Infraestructure.Repositories;


namespace N5.Infraestructure.Persistence
{
    public class UnitOfWork : IUnitOfWork
    {
        private readonly GenericDBContext _dbContext;

        public UnitOfWork(GenericDBContext dbContext)
        {
            _dbContext = dbContext;
            PermisoRepository = new PermisoRepository(_dbContext);
            TipoPermisoRepository = new TipoPermisoRepository(_dbContext);
        }
        public IPermisoRepository PermisoRepository { get; private set; }

        public ITipoPermisoRepository TipoPermisoRepository { get; private set; }

        public void Dispose()
        {
            _dbContext.Dispose();
        }

        public async Task<int> Save()
        {
            return await _dbContext.SaveChangesAsync();
        }
    }
}
