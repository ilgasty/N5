﻿using Microsoft.EntityFrameworkCore;
using N5.Domain.Models;
using System.Net;
using System;
using System.Security.Principal;
using N5.Domain.Entities;

namespace N5.Infraestructure.Persistence
{
    public class GenericDBContext : DbContext , IGenericDBContext
    {
        public GenericDBContext(DbContextOptions<GenericDBContext> options) : base(options)
        {
            
        }
        
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Permiso>().ToTable("Permisos");
            modelBuilder.Entity<TipoPermiso>().ToTable("TipoPermisos");


        }
        public override Task<int> SaveChangesAsync(CancellationToken cancellationToken = default(CancellationToken))
        {
            foreach (var item in ChangeTracker.Entries<BaseEntitity>().AsEnumerable())
            {
                //Auto Timestamp
                
            }
            return base.SaveChangesAsync(cancellationToken);
        }

        DbSet<Permiso> Permisos { get; set; }
        DbSet<TipoPermiso> TipoPermisos { get; set; }


    }
}
