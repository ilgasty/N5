﻿using FluentValidation;
using N5.Domain.Features.Queries;

namespace N5.Infraestructure.Validators
{
    public class PermisoByIdValidator : AbstractValidator<PermisoByIdQuery>
    {

        public PermisoByIdValidator()
        {
            RuleLevelCascadeMode = CascadeMode.Stop;
            ClassLevelCascadeMode = CascadeMode.Stop;
            RuleFor(t => t.id)
                .NotNull()
                .NotEmpty()
                .GreaterThan(0)
                .WithMessage("EL Id no debe ser nulo");
        }
    }

}
