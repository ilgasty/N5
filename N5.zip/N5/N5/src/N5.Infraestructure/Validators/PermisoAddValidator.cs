﻿using FluentValidation;
using N5.Domain.Features.Commands;

namespace N5.Infraestructure.Validators
{
   
        public class PermisoAddValidator : AbstractValidator<PermisoAddCommand>
        {

            public PermisoAddValidator()
            {
                RuleLevelCascadeMode = CascadeMode.Stop;
                ClassLevelCascadeMode = CascadeMode.Stop;
                RuleFor(t => t.nombre_empleado)
                    .NotNull()
                    .NotEmpty()
                    .WithMessage("El nombre no debe ser nulo y/o vacio")
                    .Length(1, 50)
                    .WithMessage("El largo no puede ser mayor a 50 caracteres")
                    .Matches(@"^[a-zA-Z 0-9]*$")
                    .WithMessage("El nombre no puede contener carateres especiales");

                RuleFor(t => t.apellido_empleado)
                    .NotNull()
                    .NotEmpty()
                    .WithMessage("El apellido no debe ser nulo y/o vacio")
                    .Length(1, 50)
                    .WithMessage("El largo no puede ser mayor a 50 caracteres")
                    .Matches(@"^[a-zA-Z 0-9]*$")
                    .WithMessage("El apellido no puede contener carateres especiales");

              	RuleFor(t => t.fecha_permiso )
		            .NotNull()
	                .WithMessage("La fecha no debe ser nulo y/o vacio")
                    .Matches(@"^((?:\d){4}-(?:\d{2})-(?:\d{2}))$") //yyyy-mm-dd
	                .WithMessage("La fehca debe ser del formtao 'yyyy-MM-dd'")
                    .Must(m => DateTime.TryParseExact(m, "yyyy-MM-dd", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out _))
	                .WithMessage("La fecha ingresada es inválida");

                RuleFor(t => t.tipo_permiso)
                    .NotNull()
                    .NotEmpty()
                    .GreaterThan(0)
                    .WithMessage("EL Id no debe ser nulo");

            }
        }

   
}
