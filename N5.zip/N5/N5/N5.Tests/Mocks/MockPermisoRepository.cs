﻿using Moq;
using N5.Domain.Contracts;
using N5.Domain.Models;
using N5.Domain.Repositories;
using N5.Infraestructure.Persistence;


namespace N5.Tests.Mocks
{
    public class MockPermisoRepository
    {
        public static Mock<IPermisoRepository> GetMockPermisoRepository()
        {
            var permisoById = new Permiso
            {
                Id = 1,
                ApellidoEmpleado = "Apellido empleado 2",
                NombreEmpleado = "Nombre empleado 2",
                FechaPermiso = DateTime.Now,
                TipoPermisoId = 1,
                TipoPermiso = new TipoPermiso { Id = 1, Descripcion="mock"}
            };

            var mockRepo = new Mock<IPermisoRepository>();

            mockRepo.Setup(r => r.GetById(It.IsAny<int>())).ReturnsAsync(permisoById);

            mockRepo.Setup(r => r.Add(It.IsAny<Permiso>()));



            return mockRepo;
        }
    


        public static Mock<IUnitOfWork> MockUnitOfWor()
        {

            var mockPermiso = GetMockPermisoRepository();

            var mockGenericDBCOntext = new Mock<IGenericDBContext>();

            var mockUoW = new Mock<IUnitOfWork>();

            mockUoW.SetupGet(r => r.PermisoRepository).Returns(mockPermiso.Object);

            mockUoW.Setup(r => r.Save()).ReturnsAsync(1);


            return mockUoW;
        }


    }
}
