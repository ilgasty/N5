﻿using AutoMapper;
using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Moq;
using N5.API.Controllers;
using N5.Domain.Contracts;
using N5.Domain.DTOs;
using N5.Domain.Features.Queries;
using N5.Infraestructure.Handlers.Queries;
using N5.Infraestructure.Profiles;
using N5.Tests.Mocks;
using Shouldly;

namespace N5.Tests.Features.Permiso.Queries
{
    public class PermisoByIdHandlerTest
    {
        private readonly Mock<IUnitOfWork> _mockUoW;
        private IMapper _mapper;

        public PermisoByIdHandlerTest()
        {
            _mockUoW = MockPermisoRepository.MockUnitOfWor();
            var mapperConfig = new MapperConfiguration(c =>
                                {
                                    c.AddProfile<MappingProfile>();
                                });

            _mapper = mapperConfig.CreateMapper();
        }


        [Fact]
        public async Task GetMethodPermisoById()
        {
            
            var qryCmd = new PermisoByIdQuery{ id = 1 };

            var Handler = new PermisoByIdHandler(_mockUoW.Object, _mapper);

            var resHandler = await Handler.Handle(qryCmd, CancellationToken.None);

            resHandler.ShouldBeOfType<PermisoDto>();
                 
        }

        [Fact]
        public async Task GetMethodPermisoAll()
        {

            var qryCmd = new PermisoAllQuery { };

            var Handler = new PermisoAllHandler(_mockUoW.Object, _mapper);

            var resHandler = await Handler.Handle(qryCmd, CancellationToken.None);

            resHandler.ShouldBeOfType<List<PermisoDto>>();

        }
    }
}
