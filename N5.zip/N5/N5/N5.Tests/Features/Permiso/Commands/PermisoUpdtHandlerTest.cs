﻿using AutoMapper;
using Moq;
using N5.Domain.Contracts;
using N5.Domain.Features.Commands;
using N5.Infraestructure.Handlers.Commands;
using N5.Infraestructure.Profiles;
using N5.Tests.Mocks;
using Shouldly;


namespace N5.Tests.Features.Permiso.Commands
{
    public class PermisoUpdtHandlerTest
    {
        private readonly Mock<IUnitOfWork> _mockUoW;
        private IMapper _mapper;

        public PermisoUpdtHandlerTest()
        {
            _mockUoW = MockPermisoRepository.MockUnitOfWor();
            var mapperConfig = new MapperConfiguration(c =>
            {
                c.AddProfile<MappingProfile>();
            });

            _mapper = mapperConfig.CreateMapper();
        }

        [Fact]
        public async Task PutMethodPermisoAdd()
        {

            var qryCmd = new PermisoUpdtCommand
            {
                empleado_id = 1,
                tipo_permiso = 2,
                apellido_empleado = "Apellido Insert Mock",
                nombre_empleado = "Nombre Insert Mock",
                fecha_permiso = "2023-08-17"
                
            };

            var Handler = new PermisoUpdtHandler(_mockUoW.Object, _mapper);

            var resHandler = await Handler.Handle(qryCmd, CancellationToken.None);

            resHandler.ShouldBeOfType<int>();
            resHandler.ShouldBeLessThanOrEqualTo(1);
        }

        [Fact]
        public async Task PostMethodPermisoAddKO()
        {


            var qryCmd = new PermisoUpdtCommand
            {
                empleado_id = -1,
                tipo_permiso = 2,
                apellido_empleado = "Apellido Insert Mock",
                nombre_empleado = "Nombre Insert Mock",
                fecha_permiso = "2023-08-17"

            };

            var Handler = new PermisoUpdtHandler(_mockUoW.Object, _mapper);

            var resHandler = await Handler.Handle(qryCmd, CancellationToken.None);

            resHandler.ShouldBeOfType<int>();
            resHandler.ShouldBeLessThanOrEqualTo(-1);
        }
    }
}
