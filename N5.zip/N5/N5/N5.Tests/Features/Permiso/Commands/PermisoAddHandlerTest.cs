﻿using AutoMapper;
using Moq;
using N5.Domain.Contracts;
using N5.Domain.Features.Commands;
using N5.Infraestructure.Handlers.Commands;
using N5.Infraestructure.Profiles;
using N5.Tests.Mocks;
using Shouldly;


namespace N5.Tests.Features.Permiso.Commands
{
    public class PermisoAddHandlerTest
    {

        private readonly Mock<IUnitOfWork> _mockUoW;
        private IMapper _mapper;

        public PermisoAddHandlerTest()
        {
            _mockUoW = MockPermisoRepository.MockUnitOfWor();
            var mapperConfig = new MapperConfiguration(c =>
            {
                c.AddProfile<MappingProfile>();
            });

            _mapper = mapperConfig.CreateMapper();
        }

        [Fact]
        public async Task PostMethodPermisoAdd()
        {

            var qryCmd = new PermisoAddCommand { tipo_permiso= 2,
                                                 apellido_empleado="Apellido Insert Mock",
                                                 nombre_empleado="Nombre Insert Mock",
                                                 fecha_permiso="2023-08-17"
                                                };

            var Handler = new PermisoAddHandler(_mockUoW.Object, _mapper);

            var resHandler = await Handler.Handle(qryCmd, CancellationToken.None);

            resHandler.ShouldBeOfType<int>();
            resHandler.ShouldBeLessThanOrEqualTo(1);
        }

        [Fact]
        public async Task PostMethodPermisoAddKO()
        {

            var qryCmd = new PermisoAddCommand
            {
                tipo_permiso = 2,
                apellido_empleado = "Apellido Insert Mock",
                nombre_empleado = "Nombre Insert Mock",
                fecha_permiso = "2023-8-17"
            };

            var Handler = new PermisoAddHandler(_mockUoW.Object, _mapper);

            var resHandler = await Handler.Handle(qryCmd, CancellationToken.None);

            resHandler.ShouldBeOfType<int>();
            resHandler.ShouldBeLessThanOrEqualTo(-1);
        }
    }
}
