import { MuiThemeProvider } from '@material-ui/core';
import React from 'react';
import { Provider } from 'react-redux';

import { AppRouter } from './routers/AppRouter';
import { store } from './store/store';
import { theme } from './theme/theme';

export default function OdontonetArApp() {
    return (
        <Provider store= { store }> 
            <MuiThemeProvider theme={ theme }>
                <AppRouter />
  
            </MuiThemeProvider>
        </Provider>
    )
}
