﻿import React, { useState, useEffect } from "react";
import style from '../../types/tool/Style';
import {
  Container,
  Typography,
  Grid,
  TextField,
  Avatar,
  Badge,
} from "@material-ui/core";
// import {
//   obtenerUsuarioActual,
//   actualziarUsuario,
// } from "../../actions/UsuarioAction";
// import { useStateValue } from "../../contexto/store";
import { useDispatch , useSelector } from 'react-redux';

import fotodefault from "../../logo.svg";
import { v4 as uuidv4 } from "uuid";
import ImageUploader from "react-images-upload";
import { obtenerImagen } from "../../actions/imagenAction";
// import { useForm } from "../../hooks/useForm/useForm";
import validator from 'validator';
import { actualizarUsuario, startChecking } from "../../actions/authAction";
import { BotonGrabarCancelar } from "../ui/BotonGrabarCancelar";
import CreateIcon from '@material-ui/icons/Create';




const PerfilUsuario = ({history}) => {


  const dispatch = useDispatch();

  const [erroresCarga, setErroresCarga] = useState( {
    errorMail: false,
    errorPass: false,
    errorNyA: false,
    errorConfPass: false,
    errorUsrName:false,
    errmesg: null
  });

  const { usuario } = useSelector(state => state.auth);
 
 
  let usuarioMem={};

  if (usuario){
    usuarioMem={
      ...usuario, 
      password:"",
      confirmarPassword:"",
      fotoPerfilUrl: usuario.imagenPerfil || null 
      ,imagenPerfil:null
    };
  };
    
  const [usuarioState, setUsuario]=useState(usuarioMem)

  //const [formValues, handleInputChange]= useForm(usuarioMem);

  // const { nombreCompleto,
  //         email,
  //         password,
  //         confirmarPassword,
  //         userName,
  //         imagenPerfil, //la propiedad en el controlles es imagenPerfil
  //         fotoPerfilUrl}= formValues;

  //setUsuario(formValues);
  
 

  
  const handleInputChange = (e) => {
    //Indico que guardo los datos del componente(casilla texto) name y value en variable locales
    const { name, value } = e.target;
    //ahora seteo las variables del json (useSate) y gaurdo las anteriores para no perderlea porque solol cambio d a 1 por el eventoo onchanged
    setUsuario((anterior) => ({
      ...anterior,
      [name]: value,
    }));
  };
  
  const guardarUsuario = (e) => {
    e.preventDefault();
    
    console.log(usuarioState);

    if( !validator.isEmail(usuarioState.email)) {
      setErroresCarga({
          errorMail: true,
          errorPass:false,
          errorNyA: false,
          errorConfPass: false,
          errorUsrName:false,
          errmesg: 'Debe ingresar un mail válido'
      })
      return;
    } else if (validator.isEmpty(usuarioState.password)) {
      setErroresCarga({
          errorPass: true,  
          errorMail:false,
          errorNyA: false,
          errorConfPass: false,
          errorUsrName:false,
          errmesg: 'Debe ingresar una Clave'
      })
      return;
    } else if (validator.isEmpty(usuarioState.confirmarPassword)) {
      setErroresCarga({
          errorConfPass: true,
          errorPass: false,  
          errorMail:false,
          errorNyA: false,
          errorUsrName:false,
          errmesg: 'Debe ingresar la Confirmación de la Clave'
      })
      return;
    } else if (validator.isEmpty(usuarioState.nombreCompleto)) {
      setErroresCarga({
          errorNyA: true,
          errorConfPass: false,
          errorPass: false,  
          errorMail:false,
          errorUsrName:false,
          errmesg: 'Debe ingresar Nombre y Apellido'
      })
      return;
    } else if (validator.isEmpty(usuarioState.userName)) {
      setErroresCarga({
          errorUsrName:true,
          errorConfPass: false,
          errorPass: false,  
          errorMail:false,
          errorNyA: false,
          errmesg: 'Debe ingresar el UserName'
      })
      return;
    } else if (usuarioState.confirmarPassword !== usuarioState.password)
    {
      setErroresCarga({
        errorConfPass: true,
        errorPass: false,  
        errorMail:false,
        errorNyA: false,
        errorUsrName:false,
        errmesg: 'No coincide la Clave con la  Confirmación de la Clave'
      })

      return ;

    } else {
      setErroresCarga({
          errorMail: false,
          errorPass: false,
          errmesg: null
      })
      const resDispa=dispatch ( actualizarUsuario(usuarioState ));
      console.log(resDispa);
      dispatch(startChecking());

      // if (history.lenght <= 2 ){
        history.push('/');
      // } 
      // else { 
      //     history.goBack();
      // }
       
    }

  };

  const cancelarGuardarusuario = (e) => {
    e.preventDefault();
    if (history.lenght <= 2 ){
      history.push('/');
      } 
      else { 
          history.goBack();
      }
  };
  ///funcion para subir la foto}
  ///imagenes es el arreglo de fotos(siempre es un arreglo)que seleccione en el ejemplo solo habilitamos la seleccion de 1 foto
  const  subirfoto = (imagenes) => {
    const foto = imagenes[0];
    const fotoUrl = URL.createObjectURL(foto);

    obtenerImagen(foto).then((respuesta) => {
      // console.log("respuesta ", respuesta);
      //setUsuario(formValues);
      setUsuario((anterior) => ({
        ...anterior, //mantengo los valores que ya tiene
        imagenPerfil: respuesta, ///respuesta es un Json con el formato de imagenPerifl{data:..,nombre:...,expension:...}
        fotoPerfilUrl: fotoUrl, ///archivo en formato url
      }));
    }).catch(err => {
      // setUsuario(formValues);
    });
    //actualizo el objeto usuario
  };

  ///funcion que genera la key para la foto
  const fotokey = uuidv4();

  return (
    <Container component="main" maxWidth="md" justify="center" >
      <div style={style.paper}>

      <Badge
                                        //overlap="circular"
                                        anchorOrigin={{
                                        vertical: 'bottom',
                                        horizontal: 'right',
                                        }}
                                        //variant="dot"
                                        badgeContent={<CreateIcon color="secondary" fontSize="small"/>}
                                        
                                        
                                    
                                    >
       
            <Avatar
                style={style.avatar}
                src={usuarioState.fotoPerfilUrl || fotodefault}
            />
      </Badge>
         
          <Typography component="h1" variant="h5">
          Perfil de Usuario
          </Typography>

        <form style={style.form}>
          <Grid container spacing={2}>
            <Grid item xs={12} md={12}>
              <TextField
                name="nombreCompleto"
                value={usuarioState.nombreCompleto}
                onChange={handleInputChange}
                variant="outlined"
                fullWidth
                label="Ingrese el Nombre y Apellidos"
                error={erroresCarga.errorNyA}
                helperText={ erroresCarga.errorNyA ? erroresCarga.errmesg : null}
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <TextField
                name="userName"
                value={usuarioState.userName}
                onChange={handleInputChange}
                variant="outlined"
                fullWidth
                label="Ingrese el userName"
                error={erroresCarga.errorUsrName}
                helperText={ erroresCarga.errorUsrName ? erroresCarga.errmesg : null}
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <TextField
                name="email"
                value={usuarioState.email}
                onChange={handleInputChange}
                variant="outlined"
                fullWidth
                label="Ingrese el email"
                error={erroresCarga.errorMail}
                helperText={ erroresCarga.errorMail ? erroresCarga.errmesg : null}
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <TextField
                name="password"
                value={usuarioState.password}
                onChange={handleInputChange}
                type="password"
                variant="outlined"
                fullWidth
                label="Ingrese el password"
                error={erroresCarga.errorPass}
                helperText={ erroresCarga.errorPass ? erroresCarga.errmesg : null}
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <TextField
                name="confirmarPassword"
                value={usuarioState.confirmarPassword}
                onChange={handleInputChange}
                type="password"
                variant="outlined"
                fullWidth
                label="Confirme el password"
                error={erroresCarga.errorConfPass}
                helperText={ erroresCarga.errorConfPass ? erroresCarga.errmesg : null}
              />
            </Grid>
            <Grid item xs={12} md={12}>
              <ImageUploader
                withIcon={false}
                label="Tamaño max. 5Mb | Extensiones válidas: .jpg|.png|.gif|.jpeg"
                key={fotokey}
                singleImage={true}
                buttonText="Selecciona una foto de perfil"
                onChange={subirfoto}
                imgExtension={[".jpg", ".png", ".gif", ".jpeg"]}
                maxFileSize={5242880}
              />
            </Grid>
          </Grid>

          <Grid container justify="center">
            <Grid item xs={12} md={12} align="right">
              <BotonGrabarCancelar grabarFuncion={guardarUsuario} cancelarFuncion={cancelarGuardarusuario} />
              {/* <Button
                  type="submit"
                  onClick={guardarUsuario}
                  
                  variant="contained"
                  color="primary"
                  size="large"
                  style={style.submit}
                >
                  Guardar Datos
                </Button>
                <Button
                  type="submit"
                  onClick={guardarUsuario}
                  
                  variant="outlined"
                  color="secondary"
                  size="large"
                  style={style.submit}
                >
                  Cancelar
                </Button> */}
            </Grid>
          </Grid>
        </form>
      </div>
    </Container>
  );
};

export default PerfilUsuario;
