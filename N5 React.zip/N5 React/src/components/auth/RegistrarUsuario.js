﻿
import React from 'react';
import { Container, Typography, Grid, TextField, Button, InputAdornment } from '@material-ui/core';
import style from '../../types/tool/Style';
import { useState } from 'react';
import { registrarusuario } from '../../actions/UsuarioAction';
import { AccountCircle } from '@material-ui/icons';
import validator from 'validator';
///esta es otra forma de desarrollar funciones en javascript

///<Typography y el resto son componentes de material ui, en este caso es para titulos (H1) y para que detefte solo el tipo de dispositivo
/// pongo variant para indicar cual es el minimo (H5 es para los celulares>
const RegistrarUsuario = ({history}) => {
    const [usuario, setusuario] = useState({
        NombreCompleto: '',
        Email: '',
        Password: '',
        ConfirmarPassword: '',
        UserName: ''
    });
    const [erroresCarga, setErroresCarga] = useState( {
        errorMail: false,
        errorPass: false,
        errmesg: null
    })

    const ingresoValoresMemoria = e => {
        //Indico que guardo los datos del componente(casilla texto) name y value en variable locales
        const { name, value } = e.target;

        //ahora seteo las variables del json (useSate) y gaurdo las anteriores para no perderlea porque solol cambio d a 1 por el eventoo onchanged
        setusuario(anterior => ({
            ...anterior,
            [name]: value
            ///NombreCompleto:Silvio Molina

        }))


    };

    const registrarusuarioBoton = (e) => {
        e.preventDefault();  ///hace que no refresque la pagina
        //console.log('IMpprime los valores en memoria', usuario);
        if( !validator.isEmail(usuario.Email)) {
            setErroresCarga({
                errorPass:false,
                errorMail: true,
                errmesg: 'Debe ingresar un mail válido'
            })
            return;
        } 
        console.log("Reg",usuario)
       const a= registrarusuario(usuario)
       a().then(response => {
            history.push('/auth/login')
            //console.log('Se registro exitosamente el usuario', response);

            //almaceno el token en el storage del navegador
            //window.localStorage.setItem('token_seguridad', response.data.token);
        

        }).catch(err=>{
            console.log(err)
            console.log(err.response.data)
            console.log('Se registro exitosamente el usuario', err);
            //return err
        });
    };


    return (
        <Container component="main" maxWidth="md" justify="center" >
            <div style={style.paper}> 
                <Typography component="h1" variant="h5" >
                    Registro de Usuario
                </Typography>
                <form style={style.form}>
                    <Grid container spacing={2}>
                        <Grid item xs={12} md={12}>
                            <TextField name="Nombre" 
                            value={usuario.Nombre} 
                            onChange={ingresoValoresMemoria}  
                            variant="outlined" fullWidth label="Ingrese su Nombre" 
                            InputProps={{
                                startAdornment: (
                                  <InputAdornment position="start">
                                    <AccountCircle />
                                  </InputAdornment>
                                ),
                              }}
                            />
                        </Grid>
                        <Grid item xs={12} md={12}>
                            <TextField name="Apellidos" 
                            value={usuario.Apellidos} 
                            onChange={ingresoValoresMemoria}  
                            variant="outlined" fullWidth label="Ingrese su Apellidos" />
                        </Grid>

                        <Grid item xs={12} md={6}>
                            <TextField name="Email" 
                            value={usuario.Email} 
                            onChange={ingresoValoresMemoria}  
                            variant="outlined" 
                            fullWidth label="Ingrese su email" 
                            error={erroresCarga.errorMail}
                            helperText={ erroresCarga.errorMail ? erroresCarga.errmesg : null}/>
                        </Grid>
                        <Grid item xs={12} md={6}>
                            <TextField name="UserName" value={usuario.UserName} onChange={ingresoValoresMemoria}  variant="outlined" fullWidth label="Ingrese su UserName" />
                        </Grid>
                        <Grid item xs={12} md={6}>
                            <TextField name="Password" value={usuario.Password} onChange={ingresoValoresMemoria}  type="password" variant="outlined" fullWidth label="Ingrese su password" />
                        </Grid>
                        <Grid item xs={12} md={6}>
                            <TextField name="ConfirmarPassword" value={usuario.ConfirmarPassword} onChange={ingresoValoresMemoria}  type="password" variant="outlined" fullWidth label="Confirme su password" />
                        </Grid>
                    </Grid>
                    <Grid container justify="center">
                        <Grid item xs={12} md={6}>
                            <Button type="submit" onClick={registrarusuarioBoton} fullWidth variant="contained" color="primary" size="large" style={style.submit} >
                                Enviar
                            </Button>
                        </Grid> 

                    </Grid>
                </form>
            </div>

        </Container>

        
    );

}


export default RegistrarUsuario;

/*
 esta la forma standar}
 function RegistrarUsuario(){

}
 
 
 */



