import React ,{ useState }from 'react'
import { useDispatch , useSelector } from 'react-redux';
import Container from '@material-ui/core/Container'
import Typography from '@material-ui/core/Typography'
import { Avatar, Button, Grid, Hidden, InputAdornment, ListItem, ListItemText, makeStyles, TextField } from '@material-ui/core';
import { useForm } from '../../hooks/useForm/useForm';
import LockOpenIcon from '@material-ui/icons/LockOpen';
import { AccountCircle } from '@material-ui/icons';
import VisibilityOffIcon from '@material-ui/icons/VisibilityOff';
import {starLoginEmailPassword } from '../../actions/authAction'
import validator from 'validator';
import { Link } from 'react-router-dom';

const estilos= makeStyles(theme => ({
    root: {
        display: 'flex',
        alignItems:'center'
    },
    toolbar: theme.mixins.toolbar,  //obtiene el alto de la barra
    content: {
        display: "flex",
        padding: theme.spacing(1),
        alignItems: "center",
        flexDirection:"column"
    },
    avatar:{
        width:theme.spacing(7),
        height: theme.spacing(7),
        backgroundColor: theme.palette.primary.main,
        margin: theme.spacing(1)
    },
    texto :{
        margin: theme.spacing(1),
        padding: theme.spacing(1),
    },
    boton:{
        margin: theme.spacing(1),
        padding:theme.spacing(1),
    }

}));

export const LoginScreen = () => {
    const classes= estilos();

    const dispatch= useDispatch();
    const { loading } = useSelector(state => state.ui)

    const [erroresCarga, setErroresCarga] = useState( {
        errorMail: false,
        errorPass: false,
        errmesg: null
    })

    const [formValues, handleInputChange]= useForm({ email:'', password:''});

    const {email, password}= formValues;


    const handleLogin = (e) => {
        e.preventDefault();
        // console.log( email, password);

        if( !validator.isEmail(email)) {
            setErroresCarga({
                errorPass:false,
                errorMail: true,
                errmesg: 'Debe ingresar un mail válido'
            })
            return;
        } else if (validator.isEmpty(password)) {
            setErroresCarga({
                errorMail:false,
                errorPass: true,
                errmesg: 'Debe ingresar una Clave'
            })
            return;
        } else {
            setErroresCarga({
                errorMail: false,
                errorPass: false,
                errmesg: null
            })
            const resDispa=dispatch ( starLoginEmailPassword(email, password));
            
        }
    }
    return (
        <Container component="div" maxWidth="lg"  className={ classes.root}>
             <Hidden mdDown>
                <Grid container justify="flex-start">
                
                        <Typography variant="h3" color="secondary">
                            
                            <img width={500}
                            src='https://yt3.googleusercontent.com/ytc/AOPolaTJC7kioPJswgjHpqnvfemqDBKwzBo3CSVyKc56=s900-c-k-c0x00ffffff-no-rj'/>
                        </Typography>
                

                </Grid>
            </Hidden>

            <Grid className={ classes.content}  container  justify="flex-end"> 
                <Grid item >
                    <Avatar className={ classes.avatar }>
                        <LockOpenIcon fontSize="large"/>
                    </Avatar>
                </Grid>
                <Grid item >
                    <Typography  component="h1" variant="h5" color="primary" >
                        Login
                    </Typography>
                </Grid>

                <form onSubmit= { handleLogin }>
                    <Grid container  >
                        <Grid item xs={12} >
                            <TextField className={ classes.texto}
                            
                            name="email"
                            label="Ingrese su email"
                            variant="outlined"
                            size="small"
                            autoComplete="off"
                            fullWidth
                            value={ email }
                            onChange={ handleInputChange }
                            InputProps={{
                                startAdornment: (
                                  <InputAdornment position="start">
                                    <AccountCircle />
                                  </InputAdornment>
                                ),
                              }}
                            error={erroresCarga.errorMail}
                            helperText={ erroresCarga.errorMail ? erroresCarga.errmesg : null}
                            />
                        </Grid>
                        <Grid item xs={12} >
                            <TextField className={ classes.texto}
                                type="password" 
                                name="password" 
                                label="Ingrese su password"
                                variant="outlined"
                                size="small"
                                fullWidth
                                value={password} 
                                onChange={ handleInputChange }
                                InputProps={{
                                    startAdornment: (
                                      <InputAdornment position="start">
                                        <VisibilityOffIcon />
                                      </InputAdornment>
                                    ),
                                  }}
                                error={erroresCarga.errorPass}
                                helperText={ erroresCarga.errorPass ? erroresCarga.errmesg : null}
                            />
                        </Grid>       
                    </Grid>
                    <Grid container >
                        <Grid item  xs={12}>
                            <Button
                                type="submit"
                                variant="contained"
                                size="large"
                                color="primary"
                                className={ classes.boton }
                                fullWidth
                                disabled={ loading }

                            >Ingresar</Button>
                        </Grid>

                    </Grid>
                </form>
                <ListItem component = {Link} button to="/auth/register"  > 
                        <ListItemText classes={{primary: classes.listitemtext}} primary="Registrar Usuario"/>
            </ListItem>
            </Grid>
            
        </Container>
            
        
    )
}
