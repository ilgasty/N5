﻿import React, { useState} from "react";
import style from '../../types/tool/Style';
import {
  Container,
  Typography,
  Grid,
  TextField,

  Avatar,
  
} from "@material-ui/core";
import { useDispatch , useSelector } from 'react-redux';
import fotodefault from "../../logo.svg";
import validator from 'validator';
import { actualizarUsuarioParcial, startChecking } from "../../actions/authAction";
import { BotonGrabarCancelar } from "../ui/BotonGrabarCancelar";


export const PerfilUsuarioParcial = ({history}) => {

  const dispatch = useDispatch();

  const [erroresCarga, setErroresCarga] = useState( {
    errorMail: false,
    errorPass: false,
    errorNyA: false,
    errorConfPass: false,
    errorUsrName:false,
    errmesg: null
  });

  const { usuario } = useSelector(state => state.auth);
 
 
  let usuarioMem={};

  if (usuario){
    usuarioMem={
      ...usuario, 
      password:"",
      confirmarPassword:"",
      fotoPerfilUrl: usuario.imagenPerfil || null 
      ,imagenPerfil:null
    };
  };
    
  const [usuarioState, setUsuario]=useState(usuarioMem)

 
  const handleInputChange = (e) => {
    //Indico que guardo los datos del componente(casilla texto) name y value en variable locales
    const { name, value } = e.target;
    //ahora seteo las variables del json (useSate) y gaurdo las anteriores para no perderlea porque solol cambio d a 1 por el eventoo onchanged
    setUsuario((anterior) => ({
      ...anterior,
      [name]: value,
    }));
  };
  
  const guardarUsuario = (e) => {
    e.preventDefault();
    
    console.log(usuarioState);

    if( !validator.isEmail(usuarioState.email)) {
      setErroresCarga({
          errorMail: true,
          errorPass:false,
          errorNyA: false,
          errorConfPass: false,
          errorUsrName:false,
          errmesg: 'Debe ingresar un mail válido'
      })
      return;
    } else if (validator.isEmpty(usuarioState.nombreCompleto)) {
      setErroresCarga({
          errorNyA: true,
          errorConfPass: false,
          errorPass: false,  
          errorMail:false,
          errorUsrName:false,
          errmesg: 'Debe ingresar Nombre y Apellido'
      })
      return;
    } else if (validator.isEmpty(usuarioState.userName)) {
      setErroresCarga({
          errorUsrName:true,
          errorConfPass: false,
          errorPass: false,  
          errorMail:false,
          errorNyA: false,
          errmesg: 'Debe ingresar el UserName'
      })
      return;
    } else {
      setErroresCarga({
          errorMail: false,
          errorPass: false,
          errmesg: null
      })
      const resDispa=dispatch ( actualizarUsuarioParcial(usuarioState ));
      console.log(resDispa);
      dispatch(startChecking());

      // if (history.lenght <= 2 ){
        history.push('/');
      // } 
      // else { 
      //     history.goBack();
      // }
       
    }

  };

  const cancelarGuardarusuario = (e) => {
    e.preventDefault();
    if (history.lenght <= 2 ){
      history.push('/');
      } 
      else { 
          history.goBack();
      }
  };
  
  return (
    <Container component="main" maxWidth="md" justify="center" >
      <div style={style.paper}>
     
            <Avatar
                style={style.avatar}
                src={usuarioState.fotoPerfilUrl || fotodefault}
            />

          <Typography component="h1" variant="h5">
          Perfil de Usuario 
          </Typography>
          <Typography component="h2" >
          Datos Personales
          </Typography>

        <form style={style.form}>
          <Grid container spacing={2}>
            <Grid item xs={12} md={12}>
              <TextField
                name="nombreCompleto"
                value={usuarioState.nombreCompleto}
                onChange={handleInputChange}
                variant="outlined"
                fullWidth
                label="Ingrese el Nombre y Apellidos"
                error={erroresCarga.errorNyA}
                helperText={ erroresCarga.errorNyA ? erroresCarga.errmesg : null}
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <TextField
                name="userName"
                value={usuarioState.userName}
                onChange={handleInputChange}
                variant="outlined"
                fullWidth
                label="Ingrese el userName"
                error={erroresCarga.errorUsrName}
                helperText={ erroresCarga.errorUsrName ? erroresCarga.errmesg : null}
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <TextField
                name="email"
                value={usuarioState.email}
                onChange={handleInputChange}
                variant="outlined"
                fullWidth
                label="Ingrese el email"
                error={erroresCarga.errorMail}
                helperText={ erroresCarga.errorMail ? erroresCarga.errmesg : null}
              />
            </Grid>
           
          </Grid>

          <Grid container justify="center">
            <Grid item xs={12} md={12} align="right">
              <BotonGrabarCancelar grabarFuncion={guardarUsuario} cancelarFuncion={cancelarGuardarusuario} />
            </Grid>
          </Grid>
        </form>
      </div>
    </Container>
  );
};

// export default PerfilUsuario;
