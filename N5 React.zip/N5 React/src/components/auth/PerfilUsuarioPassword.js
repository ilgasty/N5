﻿import React, { useState } from "react";
import style from '../../types/tool/Style';
import {
  Container,
  Typography,
  Grid,
  TextField,
  Avatar
} from "@material-ui/core";

import { useDispatch , useSelector } from 'react-redux';

import fotodefault from "../../logo.svg";

import validator from 'validator';
import { actualizarUsuarioPass, startChecking } from "../../actions/authAction";
import { BotonGrabarCancelar } from "../ui/BotonGrabarCancelar";





export const PerfilUsuarioPassword = ({history}) => {


  const dispatch = useDispatch();

  const [erroresCarga, setErroresCarga] = useState( {
    errorMail: false,
    errorPass: false,
    errorNyA: false,
    errorConfPass: false,
    errorUsrName:false,
    errmesg: null
  });

  const { usuario } = useSelector(state => state.auth);
 
 
  let usuarioMem={};

  if (usuario){
    usuarioMem={
      ...usuario, 
      password:"",
      confirmarPassword:"",
      fotoPerfilUrl: usuario.imagenPerfil || null 
      ,imagenPerfil:null
    };
  };
    
  const [usuarioState, setUsuario]=useState(usuarioMem)

  //const [formValues, handleInputChange]= useForm(usuarioMem);

  // const { nombreCompleto,
  //         email,
  //         password,
  //         confirmarPassword,
  //         userName,
  //         imagenPerfil, //la propiedad en el controlles es imagenPerfil
  //         fotoPerfilUrl}= formValues;

  //setUsuario(formValues);
  
 
  const handleInputChange = (e) => {
    //Indico que guardo los datos del componente(casilla texto) name y value en variable locales
    const { name, value } = e.target;
    //ahora seteo las variables del json (useSate) y gaurdo las anteriores para no perderlea porque solol cambio d a 1 por el eventoo onchanged
    setUsuario((anterior) => ({
      ...anterior,
      [name]: value,
    }));
  };
  
  const guardarUsuario = (e) => {
    e.preventDefault();
    
    console.log(usuarioState);

    if (validator.isEmpty(usuarioState.password)) {
      setErroresCarga({
          errorPass: true,  
          errorMail:false,
          errorNyA: false,
          errorConfPass: false,
          errorUsrName:false,
          errmesg: 'Debe ingresar una Clave'
      })
      return;
    } else if (validator.isEmpty(usuarioState.confirmarPassword)) {
      setErroresCarga({
          errorConfPass: true,
          errorPass: false,  
          errorMail:false,
          errorNyA: false,
          errorUsrName:false,
          errmesg: 'Debe ingresar la Confirmación de la Clave'
      })
      return;
    } else if (usuarioState.confirmarPassword !== usuarioState.password)
    {
      setErroresCarga({
        errorConfPass: true,
        errorPass: false,  
        errorMail:false,
        errorNyA: false,
        errorUsrName:false,
        errmesg: 'No coincide la Clave con la  Confirmación de la Clave'
      })

      return ;

    } else {
      setErroresCarga({
          errorMail: false,
          errorPass: false,
          errmesg: null
      })
      const resDispa=dispatch ( actualizarUsuarioPass(usuarioState ));
      console.log(resDispa);
      dispatch(startChecking());
      // if (history.lenght <= 2 ){
        history.push('/');
      // } 
      // else { 
      //     history.goBack();
      // }
    }

  };

  const cancelarGuardarusuario = (e) => {
    e.preventDefault();
    if (history.lenght <= 2 ){
      history.push('/');
      } 
      else { 
          history.goBack();
      }
  };
 

  return (

    <Container component="main" maxWidth="md" justify="center" >
      <div style={style.paper}>
            <Avatar
                style={style.avatar}
                src={usuarioState.fotoPerfilUrl || fotodefault}
            />
          <Typography component="h1" variant="h5">
          Perfil de Usuario
          </Typography>
          <Typography component="h2" >
          Cambio PassWord
          </Typography>

        <form style={style.form}>
          <Grid container spacing={2}>
            <Grid item xs={12} md={6}>
              <TextField
                name="password"
                value={usuarioState.password}
                onChange={handleInputChange}
                type="password"
                variant="outlined"
                fullWidth
                label="Ingrese el password"
                error={erroresCarga.errorPass}
                helperText={ erroresCarga.errorPass ? erroresCarga.errmesg : null}
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <TextField
                name="confirmarPassword"
                value={usuarioState.confirmarPassword}
                onChange={handleInputChange}
                type="password"
                variant="outlined"
                fullWidth
                label="Confirme el password"
                error={erroresCarga.errorConfPass}
                helperText={ erroresCarga.errorConfPass ? erroresCarga.errmesg : null}
              />
            </Grid>
 
            <Grid container justify="center">
              <Grid item xs={12} md={12} align="right">
                <BotonGrabarCancelar grabarFuncion={guardarUsuario} cancelarFuncion={cancelarGuardarusuario} />
              </Grid>
            </Grid>
          </Grid>
        </form>
      </div>
    </Container>
  );
};

