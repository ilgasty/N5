import React from 'react'
import RegistrarUsuario from './RegistrarUsuario'

export const RegisterScreen = () => {
    return (
        <div>
            <h1>Register Screen</h1>
            <RegistrarUsuario/>
        </div>
    )
}
