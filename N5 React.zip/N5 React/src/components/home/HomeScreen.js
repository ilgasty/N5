import React from 'react';
import { ListadoHome } from '../ui/N5/ListadoHome';

export const HomeScreen = () => {
    return (
         <>
         <img width={50}
         src='https://yt3.googleusercontent.com/ytc/AOPolaTJC7kioPJswgjHpqnvfemqDBKwzBo3CSVyKc56=s900-c-k-c0x00ffffff-no-rj'>
         
         </img>
         <h1></h1>
         <ListadoHome/>
         {/* <ListadoHome/> */}
          {/* Halogena:'btnhal',
            TratConduc:'btnTC',
            Corona:'btnC',
            Extraccion:'btnExt',
            Implante:'btnImplante' */}

        {/* Previo: 'green',
        Realizado: 'red',
        ARealizar: 'blue         */}
            
         </>
        // <AppBar position="static">
        //     <BarSesion />
        // </AppBar>
    )
}
