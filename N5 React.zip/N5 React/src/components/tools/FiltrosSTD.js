import React, { useEffect, useState } from 'react';
import { Grid, Paper, Typography, TextField } from '@material-ui/core';
import { StylesGrales } from '../../types/tool/StylesGrales';
import { useDispatch, useSelector } from 'react-redux';
import { getFiltros } from '../../actions/filtros';
import { ComponenteFiltro } from './ComponenteFiltro';
import { BotonFiltro } from './BotonFiltro';



export const FiltrosSTD = ({entidadFiltro}) => {
    const classes = StylesGrales();

    //console.log(entidadFiltro);
    //const [resFiltros, setresFiltros] = useState([]);

    const dispatch = useDispatch(); 
    const {checkingFiltros,filtros} = useSelector( state => state.filtros)

    

    useEffect(() => {
       dispatch ( getFiltros(entidadFiltro));
    }, [dispatch])



      //Aca veo si ya cerifico al usuario (token, etc)
      ///caso contrario muestra uel mensaje pero se porir auponer una rueba de lolading
    if (checkingFiltros) {
        return (

            <h5>Espere cargando filtros....</h5>
        )
    }
    return (
        <div>
            {/* <Paper className={ classes.paper} elevation={0} >
                <Paper className={classes.paperItems} elevation={2}> Filtros  */}
                    <form className={classes.form} autoComplete="off">
                        <Grid container spacing={2}>

                            {
                                filtros.map( filtroItem =>(
                                    <Grid key={filtroItem.orden}item xs={12} md={2}>
                                        <ComponenteFiltro filtroItem= {filtroItem} />
                                            {/* <TextField
                                                name={filtroItem.name}
                                                // value={convDatos.codigoConvenio}
                                                // onChange={handleConvenioDatos}
                                                variant="outlined"
                                                fullWidth
                                                size="small" 
                                                label={ filtroItem.label }
                                                placeholder={ filtroItem.label }
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                                
                                                //inputRef={input => input && input.focus()}
                                                // error={erroresCarga.errorNyA}
                                                // helperText={ erroresCarga.errorNyA ? erroresCarga.errmesg : null}
                                            />
                                    */}
                                    </Grid>
                                ))
                            }

                        </Grid>

                    </form>
                {/* </Paper>
            </Paper> */}
        </div>
    )
}
