import { FormControl, InputLabel, MenuItem, Select, TextField } from '@material-ui/core'
import { LensOutlined } from '@material-ui/icons';
import React, { useEffect, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux';
import { resetFiltro, setValueFiltroComponent } from '../../actions/filtros';
import { useForm } from '../../hooks/useForm/useForm';

export const ComponenteFiltro = ({filtroItem}) => {

    const dispatch = useDispatch(); 
    const {resetfiltro} = useSelector( state => state.filtros);

    const [formValues, handleInputChange, reset]= useForm({ [filtroItem.name]:(filtroItem.valor===null ? '': filtroItem.valor)});

    filtroItem.valor = Object.values(formValues)[0];

    // {valorPropiedad}=formValues;

    console.log(filtroItem.valor, formValues, filtroItem);

    useEffect(() => {
        dispatch(setValueFiltroComponent(filtroItem));
    }, [filtroItem])

    useEffect(() => {
      if (resetfiltro) {
        reset();
        dispatch(resetFiltro());
      }
    }, [resetfiltro])


//   const [age, setAge] =useState(10);

//   const handleChange = (event) => {
//     setAge(event.target.value);
//     valorPropiedad=event.target.value;
    
//   };
//   console.log(filtroItem);
    return (
        <>
        
        {(() => {
  
            switch (filtroItem.tipo) {
                case 'TextBox':
                    return (
                        
                        <TextField
                            name={filtroItem.name}
                            value={filtroItem.valor}
                            onChange={handleInputChange}
                            variant="standard"
                            fullWidth
                            size="small" 
                            label={ filtroItem.label }
                            placeholder={ filtroItem.label }
                            InputLabelProps={{
                                shrink: true,
                            }}
                            
                            //inputRef={input => input && input.focus()}
                            // error={erroresCarga.errorNyA}
                            // helperText={ erroresCarga.errorNyA ? erroresCarga.errmesg : null}
                        />
                    )
                case 'OptActivo':
                    return (
                        <FormControl   fullWidth  size="small"  variant="standard" >
                            <InputLabel id="demo-simple-select-helper-label" >{filtroItem.label}</InputLabel>
                            <Select
                            labelId="demo-simple-select-helper-label"
                            id="demo-simple-select-helper"
                            name={filtroItem.name}
                            value={filtroItem.valor}
                            onChange={handleInputChange}
                            >
                            <MenuItem value={10}>Todos</MenuItem>
                            <MenuItem value={20}>Si</MenuItem>
                            <MenuItem value={30}>No</MenuItem>
                            </Select>
                    
                        </FormControl>
                    )
                default:
                    return (
                        <TextField
                            name={filtroItem.name}
                            // value={convDatos.codigoConvenio}
                            // onChange={handleConvenioDatos}
                            variant="outlined"
                            fullWidth
                            size="small" 
                            // label={ filtroItem.label }
                            label='sdfdfdsf'
                            placeholder={ filtroItem.label }
                            InputLabelProps={{
                                shrink: true,
                            }}
                            
                            //inputRef={input => input && input.focus()}
                            // error={erroresCarga.errorNyA}
                            // helperText={ erroresCarga.errorNyA ? erroresCarga.errmesg : null}
                        />
                    )
            }

            })()}
                                   
        </>
    )
}
