import { Button, makeStyles } from '@material-ui/core';
import React from 'react';
import PropTypes from 'prop-types';

import SaveIcon  from '@material-ui/icons/Save';
import CancelIcon from '@material-ui/icons/Cancel'


const estilos= makeStyles(theme => ({
    root: {
        marginTop: theme.spacing(3),
    },
    button: {
        margin: theme.spacing(1),
      },
}));


export const BotonFiltro = ({aplicarFiltroFunc, limpiarFiltroFunc}) => {

    const classes= estilos();

    return (
        <div className={classes.root}>
            <Button 
                className={classes.button}
                onClick={aplicarFiltroFunc}
                type="submit"
                variant="contained"
                color="primary"
                size="small"
                startIcon={<SaveIcon />}
                  
                >
                Filtrar
            </Button>

            <Button 
                className={classes.button}
                onClick={limpiarFiltroFunc}
                type="submit"
                variant="outlined"
                color="secondary"
                size="small"
                startIcon={<CancelIcon/>}
                  
                >
                Limpiar
            </Button>

        </div>
    )
}


BotonFiltro.propTypes = {
    aplicarFiltroFunc: PropTypes.func.isRequired,
    limpiarFiltroFunc: PropTypes.func.isRequired
}