import { Avatar, TableCell, TableRow } from '@mui/material'
import React from 'react'

export const TablaDatosCelda = ({row}) => {



    return (
        <>
                {   Object.keys(row).map((e) => {
                            
                        if(e==="id"){
                            return (null)
                        } 
                        else {
                                return (
                                    //  console.log(e, row[e])
                            
                                    (
                                        <TableCell component="th" scope="row">
                                            {row[e]}
                                        </TableCell> 
                                    )
                                )}
                        }
                            
                            )  


                        }
                

        </>
    )
}
