import React from 'react'
import { Button, Card, CardActions, CardContent, CardMedia, makeStyles, Typography } from '@material-ui/core'

const useStyles = makeStyles(theme => ({
	CardContent:{
		overflow:'hidden',
		position: 'relative',
		
	},	
	CardActions:{
		position: "absolute",
		top:200,
		marginTop: theme.spacing(8),
		display: 'flex',
		flexDirection: 'column',
		alignItems: 'center',
		
	},
	CardMedia:{
		
		"&:hover": {
			
			transform: "scale(1.01)",
			transition: "all 0.3s ease-in-out",
			backgroundColor: "#333",
		  },
		 
	}
	  
}));
export const Imagen = ({imagen}) => {
	const classes = useStyles()
  return (
	<div >
	<CardContent className={classes.CardContent}>
		<CardMedia className={classes.CardMedia}
			component="img"
		
			image={`data:image/;base64, ${imagen.data}`}
		alt="green iguana"
		
		/>
		<CardActions className={classes.CardActions}>
		<Button size="small">Learn More</Button>
		</CardActions> 
    </CardContent>
    
	</div>
  )
}
