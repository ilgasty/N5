import { Button, makeStyles } from '@material-ui/core';
import React from 'react';
import PropTypes from 'prop-types';

import SaveIcon  from '@material-ui/icons/Save';
import CancelIcon from '@material-ui/icons/Cancel'


const estilos= makeStyles(theme => ({
    root: {
        marginTop: theme.spacing(3),
    },
    button: {
        margin: theme.spacing(1),
      },
}));





export const BotonGrabarCancelar = ({grabarFuncion, cancelarFuncion}) => {

    const classes= estilos();

    return (
        <div className={classes.root}>
            <Button 
                className={classes.button}
                onClick={grabarFuncion}
                type="submit"
                variant="contained"
                color="primary"
                size="large"
                startIcon={<SaveIcon />}
                  
                >
                Guardar
            </Button>

            <Button 
                className={classes.button}
                onClick={cancelarFuncion}
                type="submit"
                variant="outlined"
                color="secondary"
                size="large"
                startIcon={<CancelIcon/>}
                  
                >
                Cancelar
            </Button>

        </div>
    )
}


BotonGrabarCancelar.propTypes = {
    grabarFuncion: PropTypes.func.isRequired,
    cancelarFuncion: PropTypes.func.isRequired
}