﻿import React from 'react';
import { Toolbar, IconButton, Typography, Button, Avatar, Drawer,  Tooltip,  Popover, } from '@material-ui/core';
import { makeStyles } from '@material-ui/core/styles';
import { useDispatch , useSelector } from 'react-redux';
import MenuIcon from '@material-ui/icons/Menu';
import AccountCircleIcon from '@material-ui/icons/AccountCircle';
import FotoUsuarioTemp from '../../../logo.svg';
import { useState } from 'react';
import { MenuIzquierda } from './menuIzquierda';
import { startLogout } from '../../../actions/authAction';
import { TarjetaUsuario } from './TarjetaUsuario';

import clsx from 'clsx';
import { useTheme } from '@material-ui/core/styles';
import AppBar from '@material-ui/core/AppBar';

import { StylesGrales } from '../../../types/tool/StylesGrales';


const drawerWidth = 240;

const useStyles = makeStyles((theme) => ({
  root: {
    display: 'flex',
  },
  appBar: {
    zIndex: theme.zIndex.drawer + 1,
    transition: theme.transitions.create(['width', 'margin'], {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.leavingScreen,
    }),
  },
  appBarShift: {
    marginLeft: drawerWidth,
    width: `calc(100% - ${drawerWidth}px)`,
    transition: theme.transitions.create(['width', 'margin'], {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.enteringScreen,
    }),
  },
//   menuButton: {
//     marginRight: 36,
//   },
  hide: {
    display: 'none',
  },
  drawer: {
    width: drawerWidth,
    flexShrink: 0,
    whiteSpace: 'nowrap',
  },
  drawerOpen: {
    width: drawerWidth,
    transition: theme.transitions.create('width', {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.enteringScreen,
    }),
  },
  drawerClose: {
    transition: theme.transitions.create('width', {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.leavingScreen,
    }),
    overflowX: 'hidden',
    width: theme.spacing(6) + 1,
    [theme.breakpoints.up('sm')]: {
      width: theme.spacing(7) + 1,
    },
  },
  toolbar: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'flex-end',
    padding: theme.spacing(0, 1),
    // necessary for content to be below app bar
    ...theme.mixins.toolbar,
  },
  content: {
    flexGrow: 1,
    padding: theme.spacing(3),
    transition: theme.transitions.create('margin', {
        easing: theme.transitions.easing.sharp,
        duration: theme.transitions.duration.leavingScreen,
      }),
    marginLeft: -drawerWidth,
  },
  contentShift: {
    transition: theme.transitions.create('margin', {
      easing: theme.transitions.easing.easeOut,
      duration: theme.transitions.duration.enteringScreen,
    }),
    marginLeft: 0,
  },

  /////////styles,mios
    seccionDesktop: {
        display: "none",
        [theme.breakpoints.up("md")]: {
            display:"flex"
        }
      
    },
    seccionMobile: {
        display: "flex",
        [theme.breakpoints.up("md")]: {
            display:"none"
        }
    },
    grow: {
        flexGrow:1
    },
    avatarSize: {
        width: 40,
        height: 40
    },
    list: {
        width:240
    },
    listitemtext: {
        fontSize:"14px",
        fontWeight: "600",
        paddingLeft:"17px"
    },
    menuButton: {
        marginRight: 35,
        "&:focus, &.mui-focusVisible": {
            outline: "0px"
        }
    },
    usuCaption :{
        marginTop:"7px"
    },
    cards: {
        maxWidth: 240,
    }

}));
///esta constante continene la logica para detectar si es escritori/tablet o n¿mibile
/// en base a eso va a desplegar algunas opciones de memnu(nombre, foto) o boton para desplegar esas opciones (solo en mobile)

// const useStyles = makeStyles((theme) => ({
//     seccionDesktop: {
//         display: "none",
//         [theme.breakpoints.up("md")]: {
//             display:"flex"
//         }
      
//     },
//     seccionMobile: {
//         display: "flex",
//         [theme.breakpoints.up("md")]: {
//             display:"none"
//         }
//     },
//     grow: {
//         flexGrow:1
//     },
//     avatarSize: {
//         width: 40,
//         height: 40
//     },
//     list: {
//         width:250
//     },
//     listitemtext: {
//         fontSize:"14px",
//         fontWeight: "600",
//         paddingLeft:"15px"
//     },
//     menuButton: {
//         "&:focus, &.mui-focusVisible": {
//             outline: "0px"
//         }
//     },
//     usuCaption :{
//         marginTop:"7px"
//     }

    
// }))


///este componente va a ser el toolbar que se encontrara dentro de la la barra que siempre sera visible (AppNavbar)
export const BarSesionFix = () => {
    // const classes = useStyles();  ///defino en una variable el json de los estilos

    const classes = StylesGrales();

    const dispatch = useDispatch();

    //declaro a la variable global {usuario}
    //const [{ usuario= usuario }] = useStateValue();

    const {  usuario } = useSelector(state => state.auth)

    const salirSesionApp = () => {

        dispatch( startLogout());
        console.log('paso por aca');
    
    }
    
    //porpover
    const [anchorEl, setAnchorEl] = useState(null);
    const [ open, setOpen]=useState(false);
    
    const id = open ? 'simple-popover' : undefined;

    const handleClick = (event) => {
        setAnchorEl(event.currentTarget );
        setOpen(true);
      };
    
      const handleClose = () => {
        setOpen(false);
        setAnchorEl(null);
      };
      const [openMenu, setOpenMenu] = useState(false);

      const handleDrawerOpen = () => {
        setOpenMenu(true);
      };
    
      const handleDrawerClose = () => {
        setOpenMenu(false);
      };
    

    return (
        <div className={classes.root}>  
            <AppBar
                position="static" //"fixed"
                className={clsx(classes.appBar, {
                [classes.appBarShift]: openMenu,
                })}
            >
                <Toolbar>
                    {/* <IconButton className={classes.menuButton}  edge="start" 
                                aria-label="menu" border={0} color="inherit" 
                                onClick={abrirMenuIzquierdaAction} >
                        <MenuIcon/>
                    </IconButton> */}

                    <IconButton
                        color="inherit"
                        aria-label="open drawer"
                        onClick={handleDrawerOpen}
                        edge="start"
                        className={clsx(classes.menuButton, {
                        [classes.hide]: openMenu,
                        })}
                    >
                        <MenuIcon />
                    </IconButton>

                    <Typography variant="h6">OdontoNetAr</Typography>  

                    <div className={classes.grow}></div>

                    <div className={classes.seccionDesktop }>
                        <Button className={classes.menuButton}  color="inherit" border={0} onClick={handleClick}>
                            {usuario ? usuario.nombreCompleto:""}
                        </Button>
                        <Tooltip title={usuario ? usuario.nombreCompleto:""} >
                            {/* {isLoggedIn ? <button>Logout</button> : <button>Login</button>}      */}
                            {usuario.imagenPerfil ? 
                                <Avatar 
                                    src={usuario.imagenPerfil || FotoUsuarioTemp}> 
                                </Avatar>
                                :
                                    <Avatar  >    
                                        <AccountCircleIcon/>
                                    </Avatar>
                            }
                        </Tooltip>
                        
                    </div>
                    <div className={classes.seccionMobile}>
                        <IconButton color="inherit" 
                                // onClick={abrirMenuDerechaAction}
                        >
                            <i className="material-icons">more_vert</i>
                        </IconButton>
                    </div>

                </Toolbar>
            </AppBar>
            <Drawer
                variant="permanent"
                className={clsx(classes.drawer, {
                    [classes.drawerOpen]: openMenu,
                    [classes.drawerClose]: !openMenu,
                    })}
                classes={{
                    paper: clsx({
                        [classes.drawerOpen]: openMenu,
                        [classes.drawerClose]: !openMenu,
                    }),
                    }}
                    
            >
                {/* <div 
                    // onKeyDown={cerrarMenuIzquierda} onClick={ cerrarMenuIzquierda}
                > */}
                    <MenuIzquierda
                        classes={classes}
                        handleDrawerClose={handleDrawerClose}
                    />
                {/* </div> */}

            </Drawer>

            {/* <Drawer
                open={abrirMenuDerecha}
                onClose={cerrarMenuDerecha}
                anchor="right"
            >
                <div className={classes.list} onKeyDown={cerrarMenuDerecha} onClick={cerrarMenuDerecha}>
                    <MenuDerecha
                        classes={classes}
                        salirSesion={salirSesionApp}
                        usuario={usuario ? usuario : null}
                    />
                </div>

            </Drawer> */}
            <div onKeyDown={handleClose} onClick={handleClose}>
                <Popover
                    variant="content"
                    id={id}
                    open={open}
                    anchorEl={anchorEl}
                    onClose={handleClose}
                    anchorOrigin={{
                    vertical: 'bottom',
                    horizontal: 'center',
                    }}
                    transformOrigin={{
                    vertical: 'top',
                    horizontal: 'center',
                    }}
                >
                    {/* <Typography className={classes.typography}>The content of the Popover.</Typography> */}
                    <TarjetaUsuario classes={classes}  salirSesion={salirSesionApp}/>
                </Popover>
            </div>
        </div>
    )
}

///export default withRouter(BarSesion);

////para que las propiedades de los componentes React se puedan utilizar, tengo que exportar la funcion con withRouter del react-router-dom (da la navegacion entre componentes)