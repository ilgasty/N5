﻿import React from 'react';
import { List, ListItem, Avatar, ListItemText } from '@material-ui/core';
import { Link } from 'react-router-dom';
import FotoUsuarioTemp from '../../../logo.svg';
import AccountCircleIcon from '@material-ui/icons/AccountCircle';


export const MenuDerecha = ({ classes, usuario, salirSesion }) => (

    <div className={classes.list }>

        <List>
            {/* <ListItem button component={Link}> */}
            <ListItem>
                {/* <Avatar src={usuario.imagenPerfil || FotoUsuarioTemp} /> */}
                 {usuario.imagenPerfil ? 
                            <Avatar 
                                src={usuario.imagenPerfil || FotoUsuarioTemp}  
                            > 
                            </Avatar>
                            :
                                <Avatar >    
                                    <AccountCircleIcon/>
                                </Avatar>
                        }


                <ListItemText classes={{ primary: classes.listitemtext }} primary={usuario ? usuario.nombreCompleto: ""}  />
            </ListItem>
            <ListItem component = {Link} button to="/cfgusr/perfilusuario" >
                        <ListItemText classes={{primary: classes.listitemtext}} primary="Perfil Usuario"/>
            </ListItem>
            <ListItem button onClick={salirSesion} >
                <ListItemText classes={{primary: classes.listitemtext}} primary="Salir" />
            </ListItem>
        </List>

    </div>
);