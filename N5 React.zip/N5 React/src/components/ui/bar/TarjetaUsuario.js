import React from 'react'

import { Typography, Avatar, Card, CardContent,  CardHeader, List, ListItem, ListItemText, Divider, Badge } from '@material-ui/core';
import { useSelector } from 'react-redux';
import AccountCircleIcon from '@material-ui/icons/AccountCircle';
import { Link } from 'react-router-dom';
import FotoUsuarioTemp from '../../../logo.svg';

import style from '../../../types/tool/Style';





export const TarjetaUsuario = ({classes, salirSesion}) => {

    // const classes = useStyles();  ///defino en una variable el json de los estilos

    const {  usuario } = useSelector(state => state.auth)

    return (
        <>
            <Card >
                    <CardHeader style={{backgroundColor: "lightgray"}}
                       avatar= {usuario.imagenPerfil ? 
                                    <Avatar 
                                        style={style.avatar}
                                        //className={ classes.avatar}
                                        src={usuario.imagenPerfil || FotoUsuarioTemp}  
                                        
                                        > 
                                    </Avatar>  
                                :
                                    <Avatar >    
                                        <AccountCircleIcon/>
                                    </Avatar>
                        }
                        title={
                                <Typography variant="h6" align="center" color="textPrimary" gutterBottom >
                                    {usuario ? usuario.nombreCompleto:""} 
                                </Typography>}
                        subheader= {
                            <Typography variant="subtitle2" align="center" style={{ color: "gray" }} gutterBottom >
                                    {usuario ? usuario.email:""} 
                                </Typography>
                        }
                    />
                    <CardContent justify="center" >

                        <List >
                            <ListItem component={Link} button to='/cfgusr/prflusrpass'>   
                            
                                <i className="material-icons">vpn_key</i>
                                <ListItemText classes={{ primary: classes.listitemtext }} primary="Cambio Contraseña" />                                
                            </ListItem>
                            </List>

                            <Divider />
                            <List>
                                <ListItem component={Link} button to='/cfgusr/perfilusuario'>                                
                                    <i className="material-icons">account_box</i>
                                    <ListItemText classes={{ primary: classes.listitemtext }} primary="Perfil Completo" color="secundary"/>
                                </ListItem>
                                <ListItem component={Link} button to='/cfgusr/prflusrpartial'>
                                    <i className="material-icons">menu_book</i>
                                    <ListItemText classes={{ primary: classes.listitemtext }} primary="Cambios Datos Personales" />
                                </ListItem>
                        </List>
                        <Divider />
                        <List>

                                <ListItem button onClick={salirSesion} >
                                <i className="material-icons">exit_to_app</i>
                                    <ListItemText classes={{ primary: classes.listitemtext }} primary="Cerrar Sesión" />
                                </ListItem>
                                {/* <ListItem component={Link} button to='/instructor/nuevo'>
                                    <ListItemText primary="La puta madre!"/>
                                    <ListItemText 
                                    primary={
                                        <Typography variant="h6" style={{ color: "gray" }}>
                                        User
                                        </Typography>
                                    }
                                    secondary={
                                        <Typography style={{ color: "red" }}>hello</Typography>
                                    }
                                    />
                                </ListItem> */}
                        </List>

                    </CardContent>
                    {/* <CardActions align="right">
                        <Button size="small" color="primary" onClick={setprueba}>Salir</Button>
                        <Button size="small" color="primary" onClick={setprueba}>Salir2</Button>
                    </CardActions> */}
                </Card>
        </>
    )
}
