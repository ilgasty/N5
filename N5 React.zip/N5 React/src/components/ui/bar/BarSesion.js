﻿import React from 'react';
import { Toolbar, IconButton, Typography, Button, Avatar, Drawer, List, ListItem, ListItemText, Tooltip, Chip, Popover, Card, CardContent, CardActions, CardMedia } from '@material-ui/core';
import { makeStyles } from '@material-ui/core/styles';
import { useDispatch , useSelector } from 'react-redux';
import MenuIcon from '@material-ui/icons/Menu';
import AccountCircleIcon from '@material-ui/icons/AccountCircle';

import theme from '../../../theme/theme';
import FotoUsuarioTemp from '../../../logo.svg';
import { useState } from 'react';
import { MenuIzquierda } from './menuIzquierda';
import { MenuDerecha } from './menuDerecha';
import { startLogout } from '../../../actions/authAction';
import { TarjetaUsuario } from './TarjetaUsuario';

///esta constante continene la logica para detectar si es escritori/tablet o n¿mibile
/// en base a eso va a desplegar algunas opciones de memnu(nombre, foto) o boton para desplegar esas opciones (solo en mobile)

const useStyles = makeStyles((theme) => ({
    seccionDesktop: {
        display: "none",
        [theme.breakpoints.up("md")]: {
            display:"flex"
        }
      
    },
    seccionMobile: {
        display: "flex",
        [theme.breakpoints.up("md")]: {
            display:"none"
        }
    },
    grow: {
        flexGrow:1
    },
    avatarSize: {
        width: 40,
        height: 40
    },
    list: {
        width:250
    },
    listitemtext: {
        fontSize:"14px",
        fontWeight: "600",
        paddingLeft:"15px"
    },
    menuButton: {
        "&:focus, &.mui-focusVisible": {
            outline: "0px"
        }
    },
    usuCaption :{
        marginTop:"7px"
    }

    
}))


///este componente va a ser el toolbar que se encontrara dentro de la la barra que siempre sera visible (AppNavbar)
export const BarSesion = () => {
    const classes = useStyles();  ///defino en una variable el json de los estilos

    const dispatch = useDispatch();

   //declaro a la variable global {usuario}
    //const [{ usuario= usuario }] = useStateValue();

    const {  usuario } = useSelector(state => state.auth)

    const [abrirMenuIzquierda, setabrirMenuIzquierda] = useState(false);
    const [abrirMenuDerecha, setAbrirMenuDerecha] = useState(false);


    const cerrarMenuIzquierda = () => {
        setabrirMenuIzquierda(false);

    }

    const abrirMenuIzquierdaAction = () => {
        setabrirMenuIzquierda(true);
    }

    const cerrarMenuDerecha = () => {

        setAbrirMenuDerecha(false);
    }
    const abrirMenuDerechaAction = () => {
        setAbrirMenuDerecha(true);
    }
    const salirSesionApp = () => {
        ///borro el token en el storage del navegador
        // localStorage.removeItem("token_seguridad");

        // dispatch({
        //     type:"SALIR_SESION",
        //     nuevousuario:null,
        //     autenticado:false
        // });
        // ///redirigo a la pagina al login, para eso tengo que pasar por parametros  las propiedades del componente React en BarSesion
        // props.history.push('/auth/login');
        
        dispatch( startLogout());
        
        console.log('paso por aca');
        // props.history.push('/auth/login');
    
    }
    
    //porpover
    const [anchorEl, setAnchorEl] = useState(null);
    const [ open, setOpen]=useState(false);
    
    const id = open ? 'simple-popover' : undefined;

    const handleClick = (event) => {
        setAnchorEl(event.currentTarget );
        setOpen(true);
      };
    
      const handleClose = () => {
        setOpen(false);
        setAnchorEl(null);
      };

    return (

        <>
            
            <Toolbar>
                <IconButton className={classes.menuButton}  edge="start" 
                            aria-label="menu" border={0} color="inherit" 
                            onClick={abrirMenuIzquierdaAction} >
                    {/* <i className="material-icons">menu</i> */}
                    <MenuIcon/>
                </IconButton>

                <Typography variant="h6">NX Brand </Typography>  
                {/* {`OdontoNetAr ${prueba} `} */}

                <div className={classes.grow}></div>

                <div className={classes.seccionDesktop }>
                    {/* <Button color="inherit" onClick={salirSesionApp}>Salir Sesion </Button> */}

                    <Button className={classes.menuButton}  color="inherit" border={0} onClick={handleClick}>
                        {usuario ? usuario.nombreCompleto:""}
                    </Button>

                    {/* <Chip 
                        color="primary" 
                        size="large"
                        label= {usuario ? usuario.nombreCompleto:""} 
                        clickable
                        onClick={abrirMenuDerechaAction}   
                        avatar={<Avatar src= {usuario.imagenPerfil || FotoUsuarioTemp} />} 
                    /> subtitle1*/}
                    {/* <Typography className={classes.usuCaption}   variant="button"  >{usuario ? usuario.nombreCompleto:""}</Typography> */}
                   
                   
                    <Tooltip title={usuario ? usuario.nombreCompleto:""} >
                        {/* {isLoggedIn ? <button>Logout</button> : <button>Login</button>}      */}
                        {usuario.imagenPerfil ? 
                            <Avatar 
                                src={usuario.imagenPerfil || FotoUsuarioTemp}  
                                
                                onClick={abrirMenuDerechaAction}> 
                            </Avatar>
                            :
                                <Avatar onClick={abrirMenuDerechaAction} >    
                                    <AccountCircleIcon/>
                                </Avatar>
                        }

                        
                        

                    </Tooltip>
                    

                </div>
                <div className={classes.seccionMobile}>
                    <IconButton color="inherit" onClick={abrirMenuDerechaAction}>
                        <i className="material-icons">more_vert</i>
                    </IconButton>
                </div>

            </Toolbar>
            <Drawer
                open={abrirMenuIzquierda}
                onClose={cerrarMenuIzquierda}
                anchor="left"

            >
                <div className={classes.list} onKeyDown={cerrarMenuIzquierda} onClick={ cerrarMenuIzquierda}>
                    <MenuIzquierda
                        classes={classes}
                    />
                </div>

            </Drawer>

            <Drawer
                open={abrirMenuDerecha}
                onClose={cerrarMenuDerecha}
                anchor="right"
            >
                <div className={classes.list} onKeyDown={cerrarMenuDerecha} onClick={cerrarMenuDerecha}>
                    <MenuDerecha
                        classes={classes}
                        salirSesion={salirSesionApp}
                        usuario={usuario ? usuario : null}
                    />
                </div>

            </Drawer>

            <div onKeyDown={handleClose} onClick={handleClose}>
                <Popover
                
                    variant="content"
                    id={id}
                    open={open}
                    anchorEl={anchorEl}
                    onClose={handleClose}
                    anchorOrigin={{
                    vertical: 'bottom',
                    horizontal: 'center',
                    }}
                    transformOrigin={{
                    vertical: 'top',
                    horizontal: 'center',
                    }}
                >
                    {/* <Typography className={classes.typography}>The content of the Popover.</Typography> */}
                    <TarjetaUsuario classes={classes} abrirMenuDerechaAction={abrirMenuDerechaAction} salirSesion={salirSesionApp} />
                </Popover>
            </div>
        </>
    )
}

///export default withRouter(BarSesion);

////para que las propiedades de los componentes React se puedan utilizar, tengo que exportar la funcion con withRouter del react-router-dom (da la navegacion entre componentes)