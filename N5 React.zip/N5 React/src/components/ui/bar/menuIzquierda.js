﻿import React from 'react';
import { List, ListItem, ListItemText, Divider, useTheme, IconButton } from '@material-ui/core';
import { Link } from 'react-router-dom';

import ChevronLeftIcon from '@material-ui/icons/ChevronLeft';
import ChevronRightIcon from '@material-ui/icons/ChevronRight';

const opcionesMenu=[ 
    {
        label:"Categoria", 
        link:"/categoria",
        icono:"account_box"
    },
    {
        label:"Productos", 
        link:"/producto",
        icono:"menu_book"
    },
    {
        label:"New Product", 
        link:"/productos",
        icono:"people"
    },
    {
        label:"Venta", 
        link:"/ventas",
        icono:"point_of_sale"
    },
    {
        label:"reporte", 
        link:"/reporte",
        icono:"people"
    },
    {
        label:"Caja", 
        link:"/Caja",
        icono:"menu_book"
    }
    
    ]

///classes son los estilos que paso por parametros
export const MenuIzquierda = ({ classes, handleDrawerClose }) => {
    const theme=useTheme();

    return (
            <div >
                {/* className={classes.list} */}
                <div className={classes.toolbar}>
                <IconButton onClick={handleDrawerClose}>
                    {theme.direction === 'rtl' ? <ChevronRightIcon /> : <ChevronLeftIcon />}
                </IconButton>
                </div>
                <Divider />
                <List>
                {
                    opcionesMenu.map(mnuopcion => (
                        <ListItem component={Link} button to={mnuopcion.link}>
                            <i className="material-icons">{mnuopcion.icono}</i>
                            <ListItemText classes={{ primary: classes.listitemtext }} primary={mnuopcion.label} />
                        </ListItem>

                    ))
                }
                </List>
                <Divider/>
                <List>
                    <ListItem component={Link} button to='/auth/perfil'>
                        <i className="material-icons">account_box</i>
                        <ListItemText classes={{ primary: classes.listitemtext }} primary="Perfil" />
                    </ListItem>
                </List>

                <Divider />
                <List>
                    <ListItem component={Link} button to='/curso/nuevo'>
                        <i className="material-icons">add_box</i>
                        <ListItemText classes={{ primary: classes.listitemtext }} primary="Nuevo Curso" />
                    </ListItem>
                    <ListItem component={Link} button to='/curso/paginador'>
                        <i className="material-icons">menu_book</i>
                        <ListItemText classes={{ primary: classes.listitemtext }} primary="Lista Cursos" />
                    </ListItem>
                </List>
                <Divider />
                <List>
                    <ListItem component={Link} button to='/instructor/nuevo'>
                        <i className="material-icons">person_add</i>
                        <ListItemText classes={{ primary: classes.listitemtext }} primary="Nuevo Instructor" />
                    </ListItem>
                    <ListItem component={Link} button to='/instructor/lista'>
                        <i className="material-icons">people</i>
                        <ListItemText classes={{ primary: classes.listitemtext }} primary="Lista Instructores" />
                    </ListItem>
                </List>


            </div>
    )
};






