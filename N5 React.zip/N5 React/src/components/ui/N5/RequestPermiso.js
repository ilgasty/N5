import { Button, Container, FormControl, Grid, InputLabel, MenuItem, Select, TextField, Typography } from '@mui/material'
import React, { useEffect, useState }  from 'react';
import validator from 'validator';
import { useForm } from '../../../hooks/useForm/useForm';
import { getAllDatos, posDatos, putDatos } from '../../../actions/urlAction';
import moment from 'moment';
import Swal from 'sweetalert2';

const diaHoy= moment().format('YYYY-MM-DD');

export const RequestPermiso = ({item,handleOpenClose}) => {


	const [formvalue,setFormvalue,reset]=useForm({nombre_empleado:'',apellido_empleado:'',tipo_permiso:0});
	const [erroresCarga, setErroresCarga] = useState( {
        nombre_empleado: false,
		apellido_empleado:false,
        errmesg: null
    })
	
	
	const handleSubmit= (e)=>{
	
		 if (validator.isEmpty(formvalue.nombre_empleado)) {
			setErroresCarga({
				nombre_empleado: true,
				apellido_empleado:false,
				errmesg: 'Debe ingresar una Nombre Empleado'
			})
		 	return;
		 }
		 if (validator.isEmpty(formvalue.apellido_empleado)) {
			setErroresCarga({
				nombre_empleado: false,
				apellido_empleado:true,
				errmesg: 'Debe ingresar una Apellido Empleado'
			})
		 	return;
		 }
		 formvalue.fecha_permiso=diaHoy;
		 console.log(formvalue)

		 let results;
		 if (item!=null)
		{
			results=putDatos('Permiso',formvalue)
		}else{
			results=posDatos('Permiso',formvalue)
		}
		results().then(data => { 
			handleOpenClose()
			if(data===1)
			{
				Swal.fire('OK',"Se grabo con exito",'success');
				window.location.replace('/n5');	

			}else{

				Swal.fire('Error','Error No se grabor el registro','error');
				
			}

				
			return data; })


		
	}
	const [TipoPermiso, setTipoPermiso] = useState()
	useEffect(() => {
		if (item!=null)
		{
			reset({empleado_id:item.id,nombre_empleado:item.nombreEmpleado,
				apellido_empleado:item.apellidoEmpleado,tipo_permiso:item.tipoPermiso.id})
			
		}
		const results=getAllDatos('TipoPermiso')
		results().then(data => { setTipoPermiso(data)
			 })
			
		.catch(err => {
			 /*...handle the error...*/
			 
			});
		
		
		
	}, [])
  return (
	<Container component="main" maxWidth="md" justify="center" >
		<Typography component="h1" variant="h5">
		<h1>Request</h1>
		</Typography>
		<form  >
          <Grid container spacing={2}>
            <Grid item xs={12} md={12}>
              <TextField
			  autoComplete="off"
                name="nombre_empleado"
                value={formvalue.nombre_empleado}
                onChange={setFormvalue}
                variant="outlined"
                fullWidth
                label="Ingrese una Nombre Empleado"
                error={erroresCarga.nombre_empleado}
                helperText={ erroresCarga.nombre_empleado ? erroresCarga.errmesg : null}
              />
            </Grid>
			<Grid item xs={12} md={12}>
              <TextField
			  autoComplete="off"
                name="apellido_empleado"
                value={formvalue.apellido_empleado}
                onChange={setFormvalue}
                variant="outlined"
                fullWidth
                label="Ingrese una Apellido Empleado"
                error={erroresCarga.apellido_empleado}
                helperText={ erroresCarga.apellido_empleado ? erroresCarga.errmesg : null}
              />
            </Grid>
			<Grid item sx={12} md={12} fullWidth>
			
				<InputLabel >Tipo</InputLabel>
				<Select fullWidth
					labelId="tipopermiso-label"
					id="tipopermiso"
					name='tipo_permiso'
					value={setFormvalue.tipo_permiso}
					label="Tipo"
					onChange={setFormvalue}
					
				>
					{TipoPermiso?.map((prod,index) => {
			 
			 		const { id, descripcion} = prod;
			 		return (
						<MenuItem value={id}>{descripcion}</MenuItem>
			
			   
						);
					})}
					
				
				</Select>
			
			</Grid>
			</Grid>
			<Grid container justify="center" spacing={2}>
            <Grid item xs={12} md={12} align="right">
			<Button 
                
                onClick={handleSubmit}
                
                variant="contained"
                color="primary"
                size="large"
                
                  
                >
                Guardar
            </Button>
             
            </Grid>
			</Grid>
			</form>
	</Container>
  )
}
