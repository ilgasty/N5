import React, { useEffect, useState } from 'react'
import Carousel from 'react-material-ui-carousel'
import { Imagen } from '../../tools/Imagen'
import { Box, Button, CardActions, CardContent, CardMedia, Modal, Paper, Table, TableBody, 
	TableCell, TableContainer, TableRow, Typography } from '@mui/material'
import { getAllDatos } from '../../../actions/urlAction'
import { TablaPermiso } from './tools/TablaPermiso'
import { Link } from 'react-router-dom'
import { RequestPermiso } from './RequestPermiso'
function Item(props)
	{
	
		return (
			<>
			<CardContent >
				<CardMedia  
					component="img"
					
					image={`${props.item.img}`}
					alt="green iguana"
					sx={{  height: 200 }}
				/>
				<CardActions sx={{position: "absolute",
				top:'50%',left:'50%',
				display: 'flex',
				flexDirection: 'column',
				alignItems: 'center',}}>
				<Button size="small">{props.item.descripcion}</Button>
				</CardActions> 
			</CardContent >

			</>
		)
	}

export const ListadoHome = () => {
	const [values, setvalues] = useState()
	const [Permiso, setPermiso] = useState()
	const [TipoPermiso, setTipoPermiso] = useState()
	
	useEffect(() => {
		const results=getAllDatos('TipoPermiso')
		results().then(data => { setTipoPermiso(data)
			 })
			
		.catch(err => {
			 /*...handle the error...*/
			 
			});
		setvalues([
			{descripcion:"Explore",
			img:"https://media.ambito.com/p/30441d6fa1488544105ac7fdd8fa1eb6/adjuntos/239/imagenes/039/120/0039120317/1200x675/smart/n5-premio-microsoft.jpeg"},
			{descripcion:"CRM",
			img:"https://assets.iproup.com/assets/jpg/2021/06/19998.jpg?7.0.2"}
			
		])
		
		
	}, [])
	const handleGetClick = () => {
		const results=getAllDatos('Permiso')
		results().then(data => { setPermiso(data)
 	
			return data; })
			
		.catch(err => {
			 /*...handle the error...*/
			 
			});

	  };
  return (
	<>
	
	
	<Carousel>
            {
                values?.map( (item, i) => <Item key={i} item={item} /> )
            }
        </Carousel>
		<h1>Challange

	</h1>
		<TableContainer component={Paper}>

      <Table sx={{ minWidth: 650 }} aria-label="simple table">
       
        
		<TableBody>
		<TableRow  className="h-72 cursor-pointer" hover role="checkbox"  >
        	 
			 <TableCell component="th" scope="row">
			 	
				 <Link to="/request">
				 	<Button size="small">Request</Button>
      			</Link>                           
            </TableCell>
		
			<TableCell component="th" scope="row">
			 	<Button size="small" onClick={() => handleGetClick()} >Get</Button>
                                           
            </TableCell>
			
			   </TableRow>
		   {/* {TipoPermiso?.map((prod,index) => {
			 //console.log(pieza)
			 const {  descripcion} = prod;
			 return (
			 
			
			   
			 );
		   })} */}
		 </TableBody>
		 </Table>
		 </TableContainer>
		 <TablaPermiso Permiso={Permiso}/>
		
		</>
  )
}
