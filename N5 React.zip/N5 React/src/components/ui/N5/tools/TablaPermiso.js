import { Box, Button, Modal, Paper, Table, TableBody, TableCell, TableContainer, TableRow, Typography } from '@mui/material'
import React, { useEffect, useState } from 'react'
import { getAllDatos } from '../../../../actions/urlAction'
import { makeStyles } from '@material-ui/core'
import { RequestPermiso } from '../RequestPermiso';
const useStyles = makeStyles(theme => ({
	bgmodal:{
		backgroundColor: 'rgba(0,0,0,0.75)',
		transition: "all 0.3s ease-in-out",
	},
	
	modal : {
		position: 'absolute',
		top: '50%',
  		left: '50%',
		overflow: 'auto',
		width: '90%',
		height:'100%',
		alignContent:'center',
		backgroundColor:'White',
		bgcolor: 'background.paper',
		border: '2px solid #000',
		transform: 'translate(-50%, -50%)',
		transition: "all 0.3s ease-in-out",
		"&:hover":{
			boxShadow: '0px 7px 8px -4px rgb(0 0 0 / 20%), 0px 12px 17px 2px rgb(0 0 0 / 14%), 0px 5px 22px 4px rgb(0 0 0 / 12%)',
			transition: "all 0.3s ease-in-out",
		}
		
	  },
	
	  
}));

export const TablaPermiso = ({Permiso}) => {
	
	const classes = useStyles()
	const [open, setOpen] = useState(false);
	const [item, setItem] = useState();
	const handleOpenClose = (it) => {
		
		setItem(it)
    	setOpen(!open);
  	};
  return (
	<>
	<TableContainer component={Paper}>
      <Table sx={{ minWidth: 650 }} aria-label="simple table">
       
        
		<TableBody>
		
        	 
			
			{Permiso?.map((prod,index) => {
			 
			 const { nombreEmpleado,apellidoEmpleado} = prod;
			 return (<>
			 <TableRow  className="h-72 cursor-pointer" hover role="checkbox"  >
				<TableCell component="th" scope="row">
					{nombreEmpleado}										  
		   		</TableCell>
				<TableCell component="th" scope="row">
						{apellidoEmpleado}
												
				</TableCell>	
				<TableCell component="th" scope="row">
					<Button variant="contained"
                color="primary" size="small" onClick={() => handleOpenClose(prod)}> Modify</Button>										  
		   		</TableCell>
				   </TableRow>
		   </>
			   
			 );
		   })}
			   
		   
		 </TableBody>
		 </Table>
		 </TableContainer>
		 <Modal
			className={classes.bgmodal}
			hideBackdrop
			open={open}
			onClose={handleOpenClose}
			aria-labelledby="child-modal-title"
			aria-describedby="child-modal-description"
      	>
         <Box aling='center' className={classes.modal}>
		<Typography variant="h5"  align="right" >
		 	<Button onClick={handleOpenClose} >close</Button>
	  
    	</Typography>
			
			<RequestPermiso item={item} handleOpenClose={handleOpenClose}/>
		 </Box>
		
          
       
      </Modal>
	</>
	
  )
}
