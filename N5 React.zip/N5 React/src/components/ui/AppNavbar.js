﻿import React from 'react';
import { AppBar } from '@material-ui/core';

import { useSelector } from 'react-redux';
import { BarSesion } from './bar/BarSesion';
import { BarSesionFix } from './bar/BarSesionFix';
//import { useStateValue } from '../../contexto/store';

const AppNavbar = () => {
    const {autenticado} = useSelector(state => state.auth)
    

    return autenticado ? (
                            autenticado===true ? (
                                //<BarSesionFix />
                                <AppBar position="static">
                                    <BarSesion />
                                    
                                </AppBar>
                            ) : null
            ) : null;

}

export default AppNavbar;