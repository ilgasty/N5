import { applyMiddleware, combineReducers, createStore, compose} from "redux";
import thunk from 'redux-thunk';

import { authReducer } from "../reducers/authReducer";

import { uiReducer } from "../reducers/uiReducer";


//aca agrego todos los reducers que va a tener mi store
const reducers=combineReducers({
    auth: authReducer,
    ui: uiReducer,
   

});

//para trabajar con peticiones asincronas
const composeEnhancers = ( typeof window !== 'undefined' && window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__ ) || compose;



export const store=createStore(
    reducers,
    composeEnhancers(
        applyMiddleware( thunk )   ////para poder trabajar en RedUx con peticiones asincronas
    )
     );  ///Simil Context
