import { types } from "../types/types";
// Fomato del state
// {   uid: 'jfrjthrthrjkhtkrjt',
//     name: 'Silvio'
// }
// state:{
// // usuario: {
// //     nombreCompleto: '',
// //     email: '',
// //     userName: '',
// //     foto:''

// // },
// // autenticado:false
// }
const initialState={
    checking:true
}

export const authReducer = (state=initialState, action ) => {
     
    switch (action.type) {
        case types.authLogin:
            
            return {
                usuario: action.payload.usuario,
                autenticado: action.payload.autenticado,
                checking: false
            }

        case types.authLogout:
            return {
                checking: false
            }

        case types.authChekingFinish:
            return {
                ...state,
                autenticado:false,
                checking: false
            }
        default:
            return state
    }
}
