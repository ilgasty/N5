import React from 'react';
import PropTypes from 'prop-types';
import { Navigate, Redirect, Route } from 'react-router-dom';

export const PublicRoute = ({ 
    isAutenticado,
    component: Component,
    ...rest
}) => {
    return (
        <Route {...rest }  //aca le paso el history, etc
        component={ (props) => (
            (!isAutenticado)
                ? <Component { ...props } />
                : <Navigate to="/" /> //<Redirect to="/" />

        )}
    />
    )
}

PublicRoute.propTypes= {
    isAutenticado: PropTypes.bool.isRequired,
    component: PropTypes.func.isRequired
}