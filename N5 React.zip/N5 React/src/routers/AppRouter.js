import React , {useState, useEffect } from 'react';
import { Navigate, Redirect, Route, BrowserRouter as Router, Routes, Switch } from 'react-router-dom';

import { PrivateRoute } from './PrivateRoute';

import { useSelector, useDispatch} from 'react-redux'

import AppNavbar from '../components/ui/AppNavbar';
import { startChecking } from '../actions/authAction';


import { HomeScreen } from '../components/home/HomeScreen';

import { LoginScreen } from '../components/auth/LoginScreen';
import { RequestPermiso } from '../components/ui/N5/RequestPermiso';

export const AppRouter = () => {
    
     //este state lo voy a usarpara saber si esta logueado o no (para las rutas seguras del reouter)
     const [isLoggedIn, setIsLoggedIn] = useState(false);

    const {autenticado, checking} = useSelector(state => state.auth)


    const dispatch = useDispatch();
    useEffect(() => {
        dispatch( startChecking());
      }, [dispatch]);


    useEffect(() => {
        if (autenticado) {
            setIsLoggedIn(true);
        }else {
            setIsLoggedIn(false);
        }
    }, [autenticado])


  
      //Aca veo si ya cerifico al usuario (token, etc)
      ///caso contrario muestra uel mensaje pero se porir auponer una rueba de lolading
      if (checking) {
          return (
  
              <h5>Espere .....</h5>
          )
      }

    
    return (
        <Router >
            <div>
                {/* <NavBar /> */}
                <AppNavbar />
                <Routes>
                <Route path="/n5" 
                        element={<HomeScreen/>} />
                <Route path="/Request" 
                        element={<RequestPermiso/>} />
 
                    <Route path="/auth" 
                        element={ !autenticado ? <LoginScreen/>: <Navigate to="/" />} />
                </Routes>
            </div>
        </Router>
    )
}
