import React from 'react';
import PropTypes from 'prop-types';
import { Navigate, Redirect, Route, Routes } from 'react-router-dom';
import { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { startChecking } from '../actions/authAction';
import { useState } from 'react';

export const PrivateRoute = ( {
   
    children
}
   //en ...rest viaja por ejempl el path que viene desde donde llamo al componente PrivateRoute
) => {
    
    const {autenticado, checking} = useSelector(state => state.auth)
    const dispatch = useDispatch();
    useEffect(() => {
        dispatch( startChecking());
      }, [dispatch]);


    
    //localStorage.setItem('lastpath',rest.location.pathname); 
    ///CA GRABO EL PARH AL CUAL QUIERO INGRESOSA EN EL LOCAL STORAGE, PARA LUEGO CUANDO ME LOGUEO VAYA A ESTE PATH


    return autenticado ? <> {children} </> : <Navigate to="/auth"/>
}

PrivateRoute.propTypes = {
    isAutenticado: PropTypes.bool.isRequired,
    component: PropTypes.func.isRequired
}
