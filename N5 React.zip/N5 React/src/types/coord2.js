
export function writeMessage(canvas, message,mousePos) {
 		//var context = canvas.getContext('2d');
 		context.clearRect(0, 0, canvas.width, canvas.height);
 		
		
		context.globalAlpha = 1;
		/****** Dibujo trazo y Implante *****/
		for (var i in odon){
			//alert(odon[i].fig.x1);
			context.beginPath();
			context.strokeStyle = "black";
			context.globalAlpha = 0.5;
			context.rect(odon[i].fig.x1, odon[i].fig.y1, odon[i].fig.x2, odon[i].fig.y2);	
			if (context.isPointInPath(mousePos.x, mousePos.y)) {
				rectrazo=odon[i].Pieza;

				context.stroke();
				if(sbtn===EnumBtn.Implante){
					
					var dimplan=vimplan.find(elemento => elemento.Pieza.slice(0,2)===odon[i].Pieza)
					var img = new Image();
					if (dimplan.Pieza.slice(0,2)>28){
      					img.src = 'Imagenes/Implante-2-Bis.png';
      				}else{
      					img.src = 'Imagenes/Implante-2-Bis180.png';	
      				}
      				context.beginPath();
      				context.globalAlpha = 1;
      				context.drawImage(img, dimplan.fig.x1, dimplan.fig.y1,dimplan.fig.x2,dimplan.fig.y2);
      				context.closePath();	
				}
			}
			context.closePath();
		}
		CargaDatos();
		Area2(mousePos);
	
        context.font = '18pt Calibri';
        context.fillStyle = 'black';
        context.fillText(message, 10, 25);
}
export function getMousePos(canvas, evt) {
        var rect = canvas.getBoundingClientRect();
        return {
          x: evt.clientX - rect.left,
          y: evt.clientY - rect.top
        };
      }
      var canvasE = document.getElementById('myCanvas');
      var context = canvasE.getContext('2d');
      var ck=false;
 	  canvasE.addEventListener('click', function(evt) {
	  	ck=true;
	  	var mousePosCLOCK = getMousePos(canvasE, evt);
	  	//alert(mousePosCLOCK.x +""+ mousePosCLOCK.y);
	  	Areanpm Click(mousePosCLOCK);
  	});
      canvasE.addEventListener('mousemove', function(evt) {
        var mousePos = getMousePos(canvasE, evt);
        var message = '';//'Mouse position: ' + mousePos.x + ',' + mousePos.y  ;
        writeMessage(canvasE, message,mousePos);
      }, false);
export  function Area2 (mousePos){
		
		for (var i in trazo){
			var scara=trazo[i].Pieza.slice(2,3);
			var cextr=odontoPantalla.find(elemento => elemento.Pieza==trazo[i].Pieza.slice(0,2));
			var cimp=odontoPantalla.find(elemento => elemento.Pieza==trazo[i].Pieza.slice(0,2)+"I");
			if(sbtn == EnumBtn.Halogena && scara!="T" && scara!="C" && cextr==null && cimp==null)
			{	
				pintarArea2(trazo[i],mousePos);
			}
			if(sbtn == EnumBtn.TratConduc && scara=="T" && cextr==null && cimp==null) pintarArea2(trazo[i],mousePos);
			if(sbtn == EnumBtn.Corona && scara=="C" && cextr==null) pintarArea2(trazo[i],mousePos);
			if(sbtn == EnumBtn.Extraccion) AExtraccion(mousePos);
		};
		ck=false;
       context.strokeStyle = "black";
	}
	export	 function AreaClick (mousePos){
	 	ck=true;
		
		for (var i in trazo){
			var scara=trazo[i].Pieza.slice(2,3);
			var cextr=odontoPantalla.find(elemento => elemento.Pieza==trazo[i].Pieza.slice(0,2));
			/********agrego trazo*******/
			context.beginPath();
			context.moveTo(trazo[i].IniTrazo.x,trazo[i].IniTrazo.y);

			for (var j in trazo[i].lCurva){
				context.bezierCurveTo(trazo[i].lCurva[j].x1, trazo[i].lCurva[j].y1, trazo[i].lCurva[j].x2, trazo[i].lCurva[j].y2, trazo[i].lCurva[j].x3, trazo[i].lCurva[j].y3);
			};
			//var ext=Extrac.find(elemento => elemento.Pieza.slice(0,2)==trazo[i].Pieza.slice(0,2));
			//var cextr=odontoPantalla.find(elemento => elemento.Pieza==ext.Pieza);
			if((sbtn === EnumBtn.Corona && scara=="C" )|| (sbtn === EnumBtn.TratConduc && scara==="T" ))
			{	
				pintarSinPintar(trazo[i],mousePos);
				
			}
			

			if(sbtn == EnumBtn.Halogena && scara!="T" && scara!="C" && cextr==null)
			{	
				pintarSinPintar(trazo[i],mousePos);
			}
		};
		if(sbtn === EnumBtn.Implante){

			for (var i in odon){
			//alert(odon[i].fig.x1);
				context.beginPath();
				context.strokeStyle = "black";
				context.globalAlpha = 0.5;
				context.rect(odon[i].fig.x1, odon[i].fig.y1, odon[i].fig.x2, odon[i].fig.y2);	
				if (context.isPointInPath(mousePos.x, mousePos.y)) {
					var dimplan=vimplan.find(elemento => elemento.Pieza.slice(0,2)==odon[i].Pieza)
					//var cextr=odontoPantalla.find(elemento => elemento.Pieza==ext.Pieza);
					//if(cextr == null) odontoPantalla.push({Pieza:ext.Pieza,Cara:ext.Cara});
				var cextr=odontoPantalla.find(elemento => elemento.Pieza==dimplan.Pieza);
					if(cextr == null) {
						//var borrarpieza=odontoPantalla.find(elemento => elemento.Pieza.slice(0,2)==odon[i].Pieza);
						odontoPantalla.push({Pieza:dimplan.Pieza,Cara:"transparent",});
					}
				
				}
				context.closePath();
			}
				//var cextr=odontoPantalla.find(elemento => elemento.Pieza==ext.Pieza);
		}
		/*for (var h in odontoPantalla){	
					 alert(odontoPantalla[h].Pieza);
						//odontoPantalla.splice(odontoPantalla.findIndex(v => v.Pieza === borrarpieza.Pieza), 1);
					}*/
	}
	export	function CargaDatos(){
		
		//var cextr=odontoPantalla.find(elemento => elemento.Pieza=="17");
		//if(cextr==null) odontoPantalla.push({Pieza:"17",Cara:"red"},);
		//if(sbtn!=EnumBtn.Halogena && sbtn!=EnumBtn.TratConduc && sbtn!=EnumBtn.Corona) return;
		for (var i in odontoPantalla){	
			
			/**** verifico si la variable odontologia tiene extracciones          ****/
			var cextr=Extrac.find(elemento => elemento.Pieza==odontoPantalla[i].Pieza);
			var imp2=odontoPantalla.find(elemento => elemento.Pieza==odontoPantalla[i].Pieza.slice(0,2)+"I");
			if(cextr!=null && imp2==null){ 
				
			for ( var j in cextr.lCurva){
				context.beginPath();
				context.moveTo(cextr.lCurva[j].x1,cextr.lCurva[j].y1);	
				context.lineTo(cextr.lCurva[j].x2, cextr.lCurva[j].y2);
				context.strokeStyle = odontoPantalla[i].Cara;
				context.globalAlpha = 1;
				context.lineWidth = 5;
    			context.stroke();
    			context.closePath();
    			context.lineWidth = 1;

			
			}	
		}
		var cimp=vimplan.find(elemento => elemento.Pieza==odontoPantalla[i].Pieza);
			if (cimp!=null){
			var img = new Image();
					if (cimp.Pieza.slice(0,2)>28){
      					img.src = 'Imagenes/Implante-2-Bis.png';
      				}else{
      					img.src = 'Imagenes/Implante-2-Bis180.png';	
      				}
      				context.beginPath();
      				context.globalAlpha = 1;
      				context.drawImage(img, cimp.fig.x1, cimp.fig.y1,cimp.fig.x2,cimp.fig.y2);
      				context.closePath();	
			}
		
		}
		for (var i in trazo){
			//var ext=Extrac.find(elemento => elemento.Pieza.slice(0,2)==trazo[i].Pieza.slice(0,2));
			//var cextr=odontoPantalla.find(elemento => elemento.Pieza==ext.Pieza);
			var extr=odontoPantalla.find(elemento => elemento.Pieza==trazo[i].Pieza.slice(0,2));
			var scara=trazo[i].Pieza.slice(2,3);
			var imp=odontoPantalla.find(elemento => elemento.Pieza==trazo[i].Pieza.slice(0,2)+"I");
			if (extr==null){	
				if( rectrazo!=trazo[i].Pieza.slice(0,2)) {
					if (imp==null){
						CargaTrazo(trazo[i]);
					}
				}else{ 
					if(sbtn!=EnumBtn.Implante && sbtn!=EnumBtn.Extraccion )
						if (imp==null){
						CargaTrazo(trazo[i]);
					}
				}
			}else{
				if(imp!=null && scara=="C" && sbtn==EnumBtn.Corona){
					CargaTrazo(trazo[i]);
				}
			}
			

		};
	}

	export	function pintarSinPintar(prueba,mousePos){
		//alert(prueba.Pieza);
		context.beginPath();
		context.moveTo(prueba.IniTrazo.x,prueba.IniTrazo.y);
		for ( var j in prueba.lCurva){
				context.bezierCurveTo(prueba.lCurva[j].x1, prueba.lCurva[j].y1, prueba.lCurva[j].x2, prueba.lCurva[j].y2, prueba.lCurva[j].x3, prueba.lCurva[j].y3);
			};
		if(estadopieza!==""){
				if (context.isPointInPath(mousePos.x, mousePos.y)) {
					if (ck===true){
						prueba.Cara=estadopieza;
						ck=false;
						var cextr=odontoPantalla.find(elemento => elemento.Pieza==ext.Pieza);
							if(cextr == null) odontoPantalla.push({Pieza:ext.Pieza,Cara:ext.Cara});
							ck=false;
							if(cextr!=null) cextr.Cara=ext.Cara;
					}
				}
		}
		context.globalAlpha = 0.5;
        context.closePath();

	}
	export	function CargaTrazo(prueba){
		//alert(prueba.Pieza);
		context.beginPath();
		context.moveTo(prueba.IniTrazo.x,prueba.IniTrazo.y);
		for ( var j in prueba.lCurva){
					context.bezierCurveTo(prueba.lCurva[j].x1, prueba.lCurva[j].y1, prueba.lCurva[j].x2, prueba.lCurva[j].y2, prueba.lCurva[j].x3, prueba.lCurva[j].y3);
			};
		context.fillStyle = prueba.Cara;
		if(prueba.Cara=="transparent"){
				context.strokeStyle = trazo[i].Cara;
				//context.strokeStyle = "black"
			}else{context.strokeStyle = "black";}
		context.stroke();
		context.fillStyle = prueba.Cara;
		
		context.globalAlpha = 0.5;
        context.fill();
        context.closePath();
        //context.globalAlpha = 1;
	}
	export	function pintarArea2(prueba,mousePos){
		//alert(prueba.Pieza);
		context.beginPath();
		context.moveTo(prueba.IniTrazo.x,prueba.IniTrazo.y);
		for ( var j in prueba.lCurva){
				
					context.bezierCurveTo(prueba.lCurva[j].x1, prueba.lCurva[j].y1, prueba.lCurva[j].x2, prueba.lCurva[j].y2, prueba.lCurva[j].x3, prueba.lCurva[j].y3);

			};
		context.fillStyle = prueba.Cara;
		if(prueba.Cara=="transparent"){
				context.strokeStyle = trazo[i].Cara;
				context.strokeStyle = "black"
			}else{context.strokeStyle = "black";}
		context.stroke();
		context.fillStyle = prueba.Cara;
		if(estadopieza!=""){
				if (context.isPointInPath(mousePos.x, mousePos.y)) {

					context.fillStyle = estadopieza;
					/*if (ck==true){
						prueba.Cara=estadopieza;
						ck=false;
						var cextr=odontoPantalla.find(elemento => elemento.Pieza==ext.Pieza);
							if(cextr == null) odontoPantalla.push({Pieza:ext.Pieza,Cara:ext.Cara});
							ck=false;
							if(cextr!=null) cextr.Cara=ext.Cara;
						

					}*/
				}
				
			}
		context.globalAlpha = 0.5;
        context.fill();
        context.closePath();
        //context.globalAlpha = 1;
	}
	
   
	export	function AExtraccion(mousePos){
		for (var i in odon){
			//alert(odon[i].fig.x1);
			context.beginPath();
			context.strokeStyle = "black";
			context.globalAlpha = 0.5;
			
			
			context.rect(odon[i].fig.x1, odon[i].fig.y1, odon[i].fig.x2, odon[i].fig.y2);	
			if (context.isPointInPath(mousePos.x, mousePos.y)) {
				context.stroke();
				if(sbtn==EnumBtn.Extraccion  ){
					//Extrac.find(elemento => elemento.Pieza == trazo[i].Pieza.slice(0,2));
					var ext=Extrac.find(elemento => elemento.Pieza.slice(0,2)==odon[i].Pieza);
					
					for ( var j in ext.lCurva){
						context.beginPath();
						context.moveTo(ext.lCurva[j].x1,ext.lCurva[j].y1);	
						context.lineTo(ext.lCurva[j].x2, ext.lCurva[j].y2);
						context.strokeStyle = estadopieza;
						if (ck==true){
							ext.Cara=estadopieza;
							var cextr=odontoPantalla.find(elemento => elemento.Pieza==ext.Pieza);
							if(cextr == null) odontoPantalla.push({Pieza:ext.Pieza,Cara:ext.Cara});
							ck=false;
							if(cextr!=null) cextr.Cara=ext.Cara;
						}
						
						context.globalAlpha = 1;
						context.lineWidth = 5;
    					context.stroke();
    					context.closePath();
					}
				}
			}
			context.closePath();
			context.lineWidth = 1;
		}	
		
			
	}
	

var btnContainer = document.getElementById("myDIV");
var btnContainer2 = document.getElementById("myDIV2");
var btns = btnContainer.getElementsByClassName("btn");
const EnumEstado = {
    Previo: 'green',
    Realizado: 'red',
    ARealizar: 'blue'
}
const EnumBtn={
	Halogena:'btnhal',
	TratConduc:'btnTC',
	Corona:'btnC',
	Extraccion:'btnExt',
	Implante:'btnImplante'
}
var sbtn = ""; 
var rectrazo="";
var odontoPantalla =[];
var trazo =[{Pieza:"18V",IniTrazo:{x:33,y:190},Cara:"transparent",
					lCurva:[{x1:33,y1:213,x2:33,y2:213,x3:33,y3:213},
							{x1:33,y1:213,x2:24,y2:212,x3:20,y3:220},
							{x1:20,y1:220,x2:16,y2:225,x3:7,y3:210},
							{x1:7,y1:210,x2:10,y2:195,x3:33,y3:190},
							]},
					{Pieza:"18I",IniTrazo:{x:33,y:190},Cara:"transparent",
					lCurva:[{x1:33,y1:213,x2:33,y2:213,x3:33,y3:213},
							{x1:33,y1:213,x2:45,y2:214,x3:56,y3:224},
							{x1:56,y1:224,x2:65,y2:175,x3:33,y3:190},
							
							]},
					{Pieza:"18O",IniTrazo:{x:33,y:213},Cara:"transparent",
					lCurva:[{x1:33,y1:213,x2:24,y2:212,x3:20,y3:220},
							{x1:20,y1:220,x2:19,y2:224,x3:30,y3:234},
							{x1:30,y1:234,x2:40,y2:227,x3:42,y3:216},
							{x1:42,y1:216,x2:40,y2:212,x3:33,y3:213},
							]},
					{Pieza:"18M",IniTrazo:{x:7,y:210},Cara:"transparent",
					lCurva:[{x1:7,y1:210,x2:16,y2:225,x3:20,y3:220},
							{x1:20,y1:220,x2:19,y2:224,x3:30,y3:234},
							{x1:30,y1:234,x2:30,y2:253,x3:30,y3:253},
							{x1:30,y1:253,x2:6,y2:250,x3:7,y3:210},
							]},
					{Pieza:"18P",IniTrazo:{x:30,y:234},Cara:"transparent",
					lCurva:[{x1:30,y1:234,x2:30,y2:253,x3:30,y3:253},
							{x1:30,y1:253,x2:50,y2:253,x3:56,y3:224},
							{x1:56,y1:224,x2:45,y2:214,x3:42,y3:216},
							{x1:42,y1:216,x2:40,y2:227,x3:30,y3:234},
							]},
					{Pieza:"17V",IniTrazo:{x:61,y:200},Cara:"transparent",
					lCurva:[{x1:61,y1:200,x2:64,y2:188,x3:85,y3:187},
							{x1:85,y1:187,x2:111,y2:180,x3:114,y3:200},
							{x1:114,y1:200,x2:100,y2:210,x3:86,y3:207},
							{x1:86,y1:207,x2:73,y2:206,x3:61,y3:200},
							]},
					{Pieza:"17P",IniTrazo:{x:64,y:241},Cara:"transparent",
					lCurva:[{x1:64,y1:241,x2:64,y2:220,x3:100,y3:230},
							{x1:100,y1:230,x2:108,y2:235,x3:100,y3:253},
							{x1:100,y1:253,x2:80,y2:260,x3:64,y3:241},
							//{x1:86,y1:207,x2:73,y2:206,x3:61,y3:200},
							]},
					{Pieza:"17D",IniTrazo:{x:61,y:200},Cara:"transparent",
					lCurva:[{x1:61,y1:200,x2:71,y2:207,x3:76,y3:205},
							{x1:76,y1:205,x2:82,y2:215,x3:76,y3:229},
							{x1:76,y1:229,x2:67,y2:227,x3:64,y3:241},
							{x1:64,y1:241,x2:55,y2:225,x3:61,y3:200},
							]},
					{Pieza:"17M",IniTrazo:{x:114,y:200},Cara:"transparent",
					lCurva:[{x1:114,y1:200,x2:107,y2:206,x3:102,y3:205},
							{x1:102,y1:206,x2:95,y2:215,x3:100,y3:230},
							{x1:100,y1:230,x2:108,y2:235,x3:100,y3:253},
							{x1:100,y1:253,x2:115,y2:235,x3:114,y3:200},
							]},
					{Pieza:"17O",IniTrazo:{x:76,y:205},Cara:"transparent",
					lCurva:[{x1:76,y1:205,x2:82,y2:215,x3:76,y3:229},
							{x1:76,y1:229,x2:80,y2:226,x3:100,y3:230},
							{x1:100,y1:230,x2:95,y2:215,x3:102,y3:206},
							{x1:102,y1:206,x2:90,y2:210,x3:76,y3:205},
							]},
					{Pieza:"16V",IniTrazo:{x:115,y:200},Cara:"transparent",
					lCurva:[{x1:115,y1:200,x2:124,y2:180,x3:145,y3:185},
							{x1:145,y1:185,x2:170,y2:180,x3:174,y3:200},
							{x1:174,y1:200,x2:160,y2:210,x3:146,y3:207},
							{x1:146,y1:207,x2:133,y2:206,x3:115,y3:200},
							]},
					{Pieza:"16P",IniTrazo:{x:116,y:241},Cara:"transparent",
					lCurva:[{x1:116,y1:241,x2:124,y2:220,x3:160,y3:230},
							{x1:160,y1:230,x2:168,y2:235,x3:160,y3:253},
							{x1:160,y1:253,x2:140,y2:265,x3:116,y3:241},
							//{x1:86,y1:207,x2:73,y2:206,x3:61,y3:200},
							]},
					{Pieza:"16D",IniTrazo:{x:115,y:200},Cara:"transparent",
					lCurva:[{x1:115,y1:200,x2:131,y2:207,x3:130,y3:204},
							{x1:130,y1:204,x2:142,y2:215,x3:130,y3:229},
							{x1:130,y1:229,x2:125,y2:227,x3:116,y3:241},
							{x1:116,y1:241,x2:112,y2:225,x3:115,y3:200},
							]},
					{Pieza:"16M",IniTrazo:{x:174,y:200},Cara:"transparent",
					lCurva:[{x1:174,y1:200,x2:167,y2:206,x3:162,y3:205},
							{x1:162,y1:206,x2:155,y2:215,x3:160,y3:230},
							{x1:160,y1:230,x2:168,y2:235,x3:160,y3:253},
							{x1:160,y1:253,x2:180,y2:245,x3:174,y3:200},
							]},
					{Pieza:"16O",IniTrazo:{x:130,y:204},Cara:"transparent",
					lCurva:[{x1:130,y1:204,x2:142,y2:215,x3:130,y3:229},
							{x1:130,y1:229,x2:140,y2:226,x3:160,y3:230},
							{x1:160,y1:230,x2:155,y2:215,x3:162,y3:206},
							{x1:162,y1:206,x2:150,y2:210,x3:136,y3:205},
							]},
					{Pieza:"15V",IniTrazo:{x:179,y:200},Cara:"transparent",
					lCurva:[{x1:176,y1:200,x2:180,y2:190,x3:195,y3:187},
							{x1:195,y1:187,x2:211,y2:190,x3:215,y3:200},
							{x1:215,y1:200,x2:193,y2:205,x3:179,y3:200},
							//{x1:146,y1:207,x2:133,y2:206,x3:115,y3:200},
							]},
					{Pieza:"15D",IniTrazo:{x:178,y:200},Cara:"transparent",
					lCurva:[{x1:178,y1:200,x2:195,y2:212,x3:178,y3:230},
							{x1:178,y1:230,x2:174,y2:212,x3:178,y3:200},
							//{x1:130,y1:229,x2:125,y2:227,x3:116,y3:241},
							//{x1:116,y1:241,x2:112,y2:225,x3:115,y3:200},
							]},
					{Pieza:"15M",IniTrazo:{x:215,y:200},Cara:"transparent",
					lCurva:[{x1:215,y1:200,x2:195,y2:212,x3:215,y3:230},
							{x1:215,y1:230,x2:220,y2:212,x3:215,y3:200},
							//{x1:130,y1:229,x2:125,y2:227,x3:116,y3:241},
							//{x1:116,y1:241,x2:112,y2:225,x3:115,y3:200},
							]},
					{Pieza:"15P",IniTrazo:{x:178,y:230},Cara:"transparent",
					lCurva:[{x1:178,y1:230,x2:195,y2:212,x3:215,y3:230},
							{x1:215,y1:230,x2:196,y2:270,x3:178,y3:230},
							//{x1:130,y1:229,x2:125,y2:227,x3:116,y3:241},
							//{x1:116,y1:241,x2:112,y2:225,x3:115,y3:200},
							]},
					{Pieza:"15O",IniTrazo:{x:178,y:230},Cara:"transparent",
					lCurva:[{x1:178,y1:230,x2:195,y2:212,x3:215,y3:230},
							{x1:215,y1:230,x2:195,y2:212,x3:215,y3:200},
							{x1:215,y1:200,x2:193,y2:205,x3:178,y3:200},
							{x1:178,y1:200,x2:195,y2:212,x3:178,y3:230},
							]},
					{Pieza:"14V",IniTrazo:{x:220,y:200},Cara:"transparent",
					lCurva:[{x1:220,y1:200,x2:220,y2:195,x3:236,y3:187},
							{x1:236,y1:187,x2:252,y2:190,x3:256,y3:200},
							{x1:256,y1:200,x2:234,y2:205,x3:220,y3:200},
							]},
					{Pieza:"14D",IniTrazo:{x:220,y:200},Cara:"transparent",
					lCurva:[{x1:220,y1:200,x2:237,y2:212,x3:220,y3:230},
							{x1:220,y1:230,x2:216,y2:212,x3:220,y3:200},
							]},
					{Pieza:"14M",IniTrazo:{x:257,y:200},Cara:"transparent",
					lCurva:[{x1:257,y1:200,x2:237,y2:212,x3:257,y3:230},
							{x1:257,y1:230,x2:262,y2:212,x3:257,y3:200},
							]},
					{Pieza:"14P",IniTrazo:{x:220,y:230},Cara:"transparent",
					lCurva:[{x1:220,y1:230,x2:237,y2:212,x3:257,y3:230},
							{x1:257,y1:230,x2:238,y2:270,x3:220,y3:230},
							]},
					{Pieza:"14O",IniTrazo:{x:220,y:230},Cara:"transparent",
					lCurva:[{x1:220,y1:230,x2:237,y2:212,x3:257,y3:230},
							{x1:257,y1:230,x2:237,y2:212,x3:257,y3:200},
							{x1:257,y1:200,x2:235,y2:205,x3:220,y3:200},
							{x1:220,y1:200,x2:237,y2:212,x3:220,y3:230},
							]},
					{Pieza:"13D",IniTrazo:{x:266,y:200},Cara:"transparent",
					lCurva:[{x1:266,y1:200,x2:283,y2:212,x3:271,y3:238},
							{x1:271,y1:238,x2:254,y2:210,x3:266,y3:200},
							]},
					{Pieza:"13P",IniTrazo:{x:271,y:238},Cara:"transparent",
					lCurva:[{x1:271,y1:238,x2:285,y2:225,x3:297,y3:238},
							{x1:297,y1:238,x2:285,y2:250,x3:271,y3:238},
							]},
					{Pieza:"13M",IniTrazo:{x:297,y:238},Cara:"transparent",
					lCurva:[{x1:297,y1:238,x2:315,y2:212,x3:300,y3:200},
							{x1:300,y1:200,x2:285,y2:212,x3:297,y3:238},
							]},
					{Pieza:"13V",IniTrazo:{x:266,y:200},Cara:"transparent",
					lCurva:[{x1:266,y1:200,x2:275,y2:207,x3:275,y3:214},
							{x1:275,y1:214,x2:285,y2:219,x3:293,y3:214},
							{x1:293,y1:214,x2:295,y2:204,x3:300,y3:200},
							{x1:300,y1:200,x2:284,y2:188,x3:266,y3:200},
							]},
					{Pieza:"13O",IniTrazo:{x:271,y:238},Cara:"transparent",
					lCurva:[{x1:271,y1:238,x2:285,y2:225,x3:297,y3:238},
							{x1:297,y1:238,x2:290,y2:219,x3:293,y3:214},
							{x1:293,y1:214,x2:285,y2:219,x3:275,y3:214},
							{x1:275,y1:214,x2:278,y2:220,x3:271,y3:238},
							]},
					{Pieza:"12D",IniTrazo:{x:313,y:205},Cara:"transparent",
					lCurva:[{x1:313,y1:205,x2:325,y2:219,x3:314,y3:229},
							{x1:314,y1:229,x2:300,y2:211,x3:313,y3:205},
							]},
					{Pieza:"12P",IniTrazo:{x:314,y:229},Cara:"transparent",
					lCurva:[{x1:314,y1:229,x2:327,y2:225,x3:342,y3:229},
							{x1:342,y1:229,x2:327,y2:250,x3:314,y3:229},
							]},
					{Pieza:"12M",IniTrazo:{x:342,y:229},Cara:"transparent",
					lCurva:[{x1:342,y1:229,x2:334,y2:219,x3:340,y3:205},
							{x1:340,y1:205,x2:355,y2:207,x3:342,y3:229},
							]},
					{Pieza:"12V",IniTrazo:{x:313,y:205},Cara:"transparent",
					lCurva:[{x1:313,y1:205,x2:317,y2:210,x3:319,y3:214},
							{x1:319,y1:214,x2:327,y2:216,x3:338,y3:214},
							{x1:338,y1:214,x2:338,y2:210,x3:340,y3:205},
							{x1:340,y1:205,x2:327,y2:204,x3:313,y3:205},
							]},
					{Pieza:"12O",IniTrazo:{x:319,y:214},Cara:"transparent",
					lCurva:[{x1:319,y1:214,x2:327,y2:216,x3:338,y3:214},
							{x1:338,y1:214,x2:334,y2:219,x3:342,y3:229},
							{x1:342,y1:229,x2:327,y2:225,x3:314,y3:229},
							{x1:314,y1:229,x2:320,y2:220,x3:319,y3:214},
							]},
					{Pieza:"11D",IniTrazo:{x:358,y:198},Cara:"transparent",
					lCurva:[{x1:358,y1:198,x2:365,y2:205,x3:358,y3:216},
							{x1:358,y1:216,x2:360,y2:220,x3:363,y3:232},
							{x1:363,y1:232,x2:360,y2:230,x3:358,y3:235},
							{x1:358,y1:235,x2:337,y2:200,x3:358,y3:198},
							]},
					{Pieza:"11V",IniTrazo:{x:358,y:198},Cara:"transparent",
					lCurva:[{x1:358,y1:198,x2:365,y2:205,x3:358,y3:216},
							{x1:358,y1:216,x2:373,y2:216,x3:388,y3:216},
							{x1:388,y1:216,x2:387,y2:205,x3:390,y3:198},
							{x1:390,y1:198,x2:373,y2:193,x3:358,y3:198},
							]},
					{Pieza:"11M",IniTrazo:{x:388,y:216},Cara:"transparent",
					lCurva:[{x1:388,y1:216,x2:387,y2:205,x3:390,y3:198},
							{x1:390,y1:198,x2:412,y2:193,x3:388,y3:238},
							{x1:388,y1:238,x2:387,y2:235,x3:383,y3:236},
							{x1:383,y1:236,x2:386,y2:225,x3:388,y3:216},
							//{x1:358,y1:198,x2:386,y2:225,x3:388,y3:216},
							]},
					{Pieza:"11P",IniTrazo:{x:358,y:235},Cara:"transparent",
					lCurva:[{x1:358,y1:235,x2:360,y2:230,x3:363,y3:232},
							{x1:363,y1:232,x2:375,y2:230,x3:383,y3:236},
							{x1:383,y1:236,x2:387,y2:235,x3:388,y3:238},
							{x1:388,y1:238,x2:374,y2:255,x3:358,y3:235},
							]},
					{Pieza:"11O",IniTrazo:{x:363,y:232},Cara:"transparent",
					lCurva:[{x1:363,y1:232,x2:360,y2:220,x3:358,y3:216},
							{x1:358,y1:216,x2:373,y2:216,x3:388,y3:216},
							{x1:388,y1:216,x2:386,y2:225,x3:383,y3:236},
							{x1:383,y1:236,x2:375,y2:230,x3:363,y3:232},
							]},
					{Pieza:"21P",IniTrazo:{x:411,y:236},Cara:"transparent",
					lCurva:[{x1:411,y1:236,x2:413,y2:230,x3:416,y3:234},
							{x1:416,y1:234,x2:426,y2:228,x3:436,y3:237},//PO
							{x1:436,y1:236,x2:438,y2:232,x3:440,y3:239},
							{x1:440,y1:239,x2:426,y2:250,x3:411,y3:236},
							]},
					{Pieza:"21D",IniTrazo:{x:416,y:234},Cara:"transparent",
					lCurva:[{x1:416,y1:234,x2:402,y2:206,x3:413,y3:210},//VO
							{x1:413,y1:210,x2:400,y2:180,x3:400,y3:213},
							{x1:400,y1:213,x2:399,y2:216,x3:411,y3:236},
							{x1:411,y1:236,x2:413,y2:230,x3:416,y3:234},
							]},
					{Pieza:"21M",IniTrazo:{x:436,y:236},Cara:"transparent",
					lCurva:[{x1:436,y1:236,x2:449,y2:206,x3:436,y3:210},//MO
							{x1:436,y1:210,x2:450,y2:185,x3:450,y3:213},
							{x1:450,y1:213,x2:447,y2:227,x3:440,y3:239},
							{x1:440,y1:239,x2:438,y2:232,x3:436,y3:236},
							]},
					{Pieza:"21V",IniTrazo:{x:413,y:210},Cara:"transparent",
					lCurva:[{x1:413,y1:210,x2:420,y2:210,x3:436,y3:210},//VO
							{x1:436,y1:210,x2:443,y2:200,x3:445,y3:198},
							{x1:445,y1:198,x2:436,y2:198,x3:428,y3:196},
							{x1:428,y1:196,x2:418,y2:198,x3:404,y3:197},
							{x1:407,y1:197,x2:410,y2:203,x3:413,y3:210},
							]},
					{Pieza:"21O",IniTrazo:{x:413,y:210},Cara:"transparent",
					lCurva:[{x1:413,y1:210,x2:420,y2:210,x3:436,y3:210},
							{x1:436,y1:210,x2:449,y2:206,x3:436,y3:236},
							{x1:436,y1:236,x2:426,y2:228,x3:416,y3:234},
							{x1:416,y1:234,x2:402,y2:206,x3:413,y3:210},
							]},
					{Pieza:"22D",IniTrazo:{x:458,y:215},Cara:"transparent",
					lCurva:[{x1:458,y1:215,x2:457,y2:205,x3:452,y3:205},
							{x1:452,y1:205,x2:449,y2:206,x3:459,y3:232},
							{x1:459,y1:232,x2:461,y2:228,x3:465,y3:230},
							{x1:465,y1:230,x2:455,y2:213,x3:458,y3:215},
							]},
					{Pieza:"22M",IniTrazo:{x:485,y:215},Cara:"transparent",
					lCurva:[{x1:485,y1:215,x2:481,y2:209,x3:490,y3:207},
							{x1:490,y1:207,x2:497,y2:217,x3:484,y3:231},
							{x1:484,y1:231,x2:484,y2:228,x3:478,y3:228},
							{x1:478,y1:228,x2:488,y2:213,x3:485,y3:215},
							]},
					{Pieza:"22V",IniTrazo:{x:485,y:215},Cara:"transparent",
					lCurva:[{x1:485,y1:215,x2:481,y2:209,x3:490,y3:207},
							{x1:490,y1:207,x2:470,y2:200,x3:452,y3:205},
							{x1:452,y1:205,x2:457,y2:205,x3:458,y3:215},
							{x1:458,y1:215,x2:480,y2:211,x3:485,y3:215},
							]},
					{Pieza:"22P",IniTrazo:{x:484,y:231},Cara:"transparent",
					lCurva:[{x1:484,y1:231,x2:484,y2:228,x3:478,y3:228},
							{x1:478,y1:228,x2:474,y2:226,x3:471,y3:233},
							{x1:471,y1:233,x2:468,y2:229,x3:465,y3:230},//igual oclusal
							{x1:465,y1:230,x2:461,y2:228,x3:459,y3:232},//igual oclusal
							{x1:459,y1:232,x2:475,y2:250,x3:484,y3:231},
							]},
					{Pieza:"22O",IniTrazo:{x:478,y:228},Cara:"transparent",
					lCurva:[{x1:478,y1:228,x2:474,y2:226,x3:471,y3:233},//igual oclusal
							{x1:471,y1:233,x2:468,y2:229,x3:465,y3:230},//igual oclusal
							{x1:465,y1:230,x2:455,y2:213,x3:458,y3:215},
							{x1:458,y1:215,x2:480,y2:211,x3:485,y3:215},
							{x1:485,y1:215,x2:488,y2:213,x3:478,y3:228},
							]},
					{Pieza:"23D",IniTrazo:{x:494,y:205},Cara:"transparent",
					lCurva:[{x1:494,y1:205,x2:505,y2:212,x3:502,y3:224},
							{x1:502,y1:224,x2:505,y2:227,x3:506,y3:231},//oc
							{x1:506,y1:231,x2:502,y2:232,x3:500,y3:236},
							{x1:500,y1:236,x2:488,y2:205,x3:494,y3:205},
							]},
					{Pieza:"23M",IniTrazo:{x:536,y:205},Cara:"transparent",
					lCurva:[{x1:536,y1:205,x2:526,y2:208,x3:527,y3:214},
							{x1:527,y1:214,x2:530,y2:222,x3:527,y3:228},
							{x1:527,y1:228,x2:528,y2:232,x3:531,y3:236},
							{x1:531,y1:236,x2:541,y2:213,x3:536,y3:205},
							]},
					{Pieza:"23V",IniTrazo:{x:494,y:205},Cara:"transparent",
					lCurva:[{x1:494,y1:205,x2:500,y2:191,x3:531,y3:198},
							{x1:531,y1:198,x2:534,y2:200,x3:536,y3:205},
							{x1:536,y1:205,x2:526,y2:208,x3:527,y3:214},
							{x1:527,y1:214,x2:519,y2:209,x3:518,y3:213},//oc
							{x1:518,y1:213,x2:512,y2:214,x3:510,y3:211},//oc
							{x1:510,y1:211,x2:505,y2:210,x3:502,y3:213},//oc
							{x1:502,y1:213,x2:499,y2:208,x3:494,y3:205},
							]},
					{Pieza:"23P",IniTrazo:{x:506,y:231},Cara:"transparent",
					lCurva:[{x1:506,y1:231,x2:502,y2:232,x3:500,y3:236},//oc
							{x1:500,y1:236,x2:515,y2:250,x3:531,y3:236},
							{x1:531,y1:236,x2:528,y2:232,x3:527,y3:228},
							{x1:527,y1:228,x2:523,y2:227,x3:518,y3:233},//oc
							{x1:518,y1:233,x2:511,y2:232,x3:506,y3:231},//oc

							]},
					{Pieza:"23O",IniTrazo:{x:527,y:228},Cara:"transparent",
					lCurva:[{x1:527,y1:228,x2:523,y2:227,x3:518,y3:233},//oc
							{x1:518,y1:233,x2:511,y2:232,x3:506,y3:231},//oc
							{x1:506,y1:231,x2:505,y2:227,x3:502,y3:224},//oc
							{x1:502,y1:224,x2:503,y2:218,x3:502,y3:213},
							{x1:502,y1:213,x2:505,y2:210,x3:510,y3:211},//oc
							{x1:510,y1:211,x2:512,y2:214,x3:518,y3:213},//oc
							{x1:518,y1:213,x2:519,y2:209,x3:527,y3:214},//oc
							{x1:527,y1:214,x2:530,y2:222,x3:527,y3:228},
							]},
					{Pieza:"24M",IniTrazo:{x:541,y:201},Cara:"transparent",
					lCurva:[{x1:541,y1:201,x2:551,y2:207,x3:549,y3:212},
							{x1:549,y1:212,x2:547,y2:214,x3:548,y3:216},//oc
							{x1:548,y1:216,x2:545,y2:217,x3:546,y3:239},
							{x1:546,y1:239,x2:530,y2:216,x3:541,y3:201},
							]},
					{Pieza:"24O",IniTrazo:{x:549,y:212},Cara:"transparent",
					lCurva:[{x1:549,y1:212,x2:547,y2:214,x3:548,y3:216},//oc
							{x1:548,y1:216,x2:550,y2:220,x3:558,y3:220},
							{x1:558,y1:220,x2:560,y2:217,x3:570,y3:218},
							{x1:570,y1:218,x2:565,y2:213,x3:570,y3:211},
							{x1:570,y1:211,x2:570,y2:208,x3:572,y3:206},
							{x1:572,y1:206,x2:568,y2:202,x3:561,y3:204},
							{x1:561,y1:204,x2:554,y2:208,x3:549,y3:207},
							{x1:549,y1:207,x2:550,y2:210,x3:549,y3:212},
							]},
					{Pieza:"24P",IniTrazo:{x:548,y:216},Cara:"transparent",
					lCurva:[{x1:548,y1:216,x2:550,y2:220,x3:558,y3:220},
							{x1:558,y1:220,x2:560,y2:217,x3:570,y3:218},
							{x1:570,y1:218,x2:565,y2:220,x3:570,y3:230},
							{x1:570,y1:230,x2:575,y2:232,x3:573,y3:237},
							{x1:573,y1:237,x2:561,y2:255,x3:546,y3:239},
							{x1:546,y1:239,x2:545,y2:217,x3:548,y3:216},
							]},
					{Pieza:"24V",IniTrazo:{x:572,y:206},Cara:"transparent",
					lCurva:[{x1:572,y1:206,x2:568,y2:202,x3:561,y3:204},
							{x1:561,y1:204,x2:554,y2:208,x3:549,y3:207},
							{x1:549,y1:207,x2:550,y2:210,x3:549,y3:212},
							{x1:549,y1:212,x2:551,y2:207,x3:541,y3:201},
							{x1:541,y1:201,x2:557,y2:178,x3:576,y3:199},
							{x1:576,y1:199,x2:573,y2:201,x3:572,y3:206},
							]},
					{Pieza:"24D",IniTrazo:{x:576,y:199},Cara:"transparent",
					lCurva:[{x1:576,y1:199,x2:573,y2:201,x3:572,y3:206},
							{x1:572,y1:206,x2:570,y2:208,x3:570,y3:211},
							{x1:570,y1:211,x2:565,y2:213,x3:570,y3:218},
							{x1:570,y1:218,x2:565,y2:220,x3:570,y3:230},
							{x1:570,y1:230,x2:575,y2:232,x3:573,y3:237},
							{x1:573,y1:237,x2:588,y2:205,x3:576,y3:199},
							]},
					{Pieza:"25O",IniTrazo:{x:590,y:205},Cara:"transparent",
					lCurva:[{x1:590,y1:205,x2:594,y2:210,x3:593,y3:215},//m
							{x1:593,y1:215,x2:590,y2:217,x3:591,y3:223},//m
							{x1:591,y1:223,x2:595,y2:219,x3:602,y3:220},//p
							{x1:602,y1:220,x2:605,y2:218,x3:615,y3:220},//p
							{x1:615,y1:220,x2:609,y2:216,x3:612,y3:216},//d
							{x1:612,y1:216,x2:610,y2:213,x3:612,y3:208},//d
							{x1:612,y1:208,x2:609,y2:202,x3:602,y3:201},//v
							{x1:602,y1:201,x2:597,y2:206,x3:590,y3:205},//v
							]},
					{Pieza:"25M",IniTrazo:{x:584,y:199},Cara:"transparent",
					lCurva:[{x1:584,y1:199,x2:590,y2:200,x3:590,y3:205},
							{x1:590,y1:205,x2:594,y2:210,x3:593,y3:215},
							{x1:593,y1:215,x2:590,y2:217,x3:591,y3:223},
							{x1:591,y1:223,x2:590,y2:227,x3:593,y3:233},//p
							{x1:593,y1:233,x2:587,y2:234,x3:591,y3:243},//p
							{x1:591,y1:243,x2:575,y2:215,x3:584,y3:199},
							]},
					{Pieza:"25D",IniTrazo:{x:622,y:198},Cara:"transparent",
					lCurva:[{x1:622,y1:198,x2:614,y2:201,x3:612,y3:208},
							{x1:612,y1:208,x2:610,y2:213,x3:612,y3:216},
							{x1:612,y1:216,x2:609,y2:216,x3:615,y3:220},
							{x1:615,y1:220,x2:612,y2:227,x3:616,y3:233},//p
							{x1:616,y1:233,x2:617,y2:237,x3:615,y3:242},//p
							{x1:615,y1:242,x2:628,y2:213,x3:622,y3:198},
							]},
					{Pieza:"25P",IniTrazo:{x:591,y:223},Cara:"transparent",
					lCurva:[{x1:591,y1:223,x2:595,y2:219,x3:602,y3:220},//p
							{x1:602,y1:220,x2:605,y2:218,x3:615,y3:220},//p
							{x1:615,y1:220,x2:612,y2:227,x3:616,y3:233},//p
							{x1:616,y1:233,x2:617,y2:237,x3:615,y3:242},//p
							{x1:615,y1:242,x2:602,y2:248,x3:591,y3:243},
							{x1:591,y1:243,x2:587,y2:234,x3:593,y3:233},//p
							{x1:593,y1:233,x2:590,y2:227,x3:591,y3:223},//p
							]},
					{Pieza:"25V",IniTrazo:{x:612,y:208},Cara:"transparent",
					lCurva:[{x1:612,y1:208,x2:609,y2:202,x3:602,y3:201},//v
							{x1:602,y1:201,x2:597,y2:206,x3:590,y3:205},//v
							{x1:590,y1:205,x2:590,y2:200,x3:584,y3:199},
							{x1:584,y1:199,x2:601,y2:174,x3:622,y3:198},
							{x1:622,y1:198,x2:614,y2:201,x3:612,y3:208},
							]},
					{Pieza:"26O",IniTrazo:{x:636,y:205},Cara:"transparent",
					lCurva:[{x1:636,y1:205,x2:642,y2:205,x3:654,y3:203},//v
							{x1:654,y1:203,x2:664,y2:210,x3:670,y3:206},//v
							{x1:670,y1:206,x2:668,y2:213,x3:672,y3:216},//d
							{x1:672,y1:216,x2:672,y2:223,x3:665,y3:226},//d
							{x1:665,y1:226,x2:647,y2:224,x3:645,y3:220},//p
							{x1:645,y1:220,x2:637,y2:216,x3:631,y3:221},//p
							{x1:631,y1:222,x2:633,y2:210,x3:639,y3:212},//m
							{x1:639,y1:212,x2:641,y2:209,x3:636,y3:205},//m
							]},
					{Pieza:"26M",IniTrazo:{x:628,y:196},Cara:"transparent",
					lCurva:[{x1:628,y1:199,x2:636,y2:194,x3:636,y3:205},//v
							{x1:636,y1:205,x2:641,y2:209,x3:639,y3:212},//m
							{x1:639,y1:212,x2:633,y2:210,x3:631,y3:222},//m
							{x1:631,y1:222,x2:639,y2:226,x3:637,y3:233},//p
							{x1:637,y1:233,x2:630,y2:236,x3:634,y3:249},//p
							{x1:634,y1:249,x2:615,y2:229,x3:628,y3:196},
							]},
					{Pieza:"26D",IniTrazo:{x:682,y:196},Cara:"transparent",
					lCurva:[{x1:682,y1:196,x2:673,y2:194,x3:670,y3:206},//v
							{x1:670,y1:206,x2:668,y2:213,x3:672,y3:216},//d
							{x1:672,y1:216,x2:672,y2:223,x3:665,y3:226},//d
							{x1:665,y1:226,x2:664,y2:232,x3:673,y3:236},//p
							{x1:673,y1:236,x2:670,y2:240,x3:674,y3:251},//p
							{x1:674,y1:251,x2:692,y2:236,x3:682,y3:196},
							]},
					{Pieza:"26P",IniTrazo:{x:631,y:222},Cara:"transparent",
					lCurva:[{x1:631,y1:222,x2:639,y2:226,x3:637,y3:233},//p
							{x1:637,y1:233,x2:630,y2:236,x3:634,y3:249},//p
							{x1:634,y1:249,x2:650,y2:259,x3:674,y3:251},
							{x1:674,y1:251,x2:670,y2:240,x3:673,y3:236},//p
							{x1:673,y1:236,x2:664,y2:232,x3:665,y3:226},//p
							{x1:665,y1:226,x2:647,y2:224,x3:645,y3:220},//p
							{x1:645,y1:220,x2:637,y2:216,x3:631,y3:221},//p
							]},
					{Pieza:"26V",IniTrazo:{x:628,y:199},Cara:"transparent",
					lCurva:[{x1:628,y1:199,x2:636,y2:194,x3:636,y3:205},
							{x1:636,y1:205,x2:642,y2:205,x3:654,y3:203},//v
							{x1:654,y1:203,x2:664,y2:210,x3:670,y3:206},//v
							{x1:670,y1:206,x2:673,y2:194,x3:682,y3:196},
							{x1:682,y1:196,x2:687,y2:191,x3:655,y3:184},
							{x1:655,y1:184,x2:626,y2:180,x3:628,y3:199},
							]},
					{Pieza:"27O",IniTrazo:{x:697,y:198},Cara:"transparent",
					lCurva:[{x1:697,y1:198,x2:704,y2:200,x3:719,y3:203},//v
							{x1:719,y1:203,x2:721,y2:201,x3:730,y3:206},//v
							{x1:730,y1:206,x2:732,y2:212,x3:725,y3:211},//d
							{x1:725,y1:211,x2:728,y2:216,x3:727,y3:220},//D
							{x1:727,y1:220,x2:724,y2:229,x3:709,y3:220},//P
							{x1:709,y1:220,x2:706,y2:214,x3:699,y3:217},//P
							{x1:699,y1:217,x2:696,y2:209,x3:700,y3:208},//M
							{x1:700,y1:208,x2:701,y2:202,x3:697,y3:198},//M
							]},
					{Pieza:"27M",IniTrazo:{x:689,y:191},Cara:"transparent",
					lCurva:[{x1:689,y1:191,x2:704,y2:200,x3:697,y3:198},//v
							{x1:697,y1:198,x2:701,y2:202,x3:700,y3:208},//M
							{x1:700,y1:208,x2:696,y2:209,x3:699,y3:217},//M
							{x1:699,y1:217,x2:703,y2:223,x3:701,y3:230},//P
							{x1:701,y1:230,x2:692,y2:229,x3:694,y3:244},//P
							{x1:694,y1:244,x2:679,y2:216,x3:689,y3:191},
							]},
					{Pieza:"27D",IniTrazo:{x:738,y:198},Cara:"transparent",
					lCurva:[{x1:738,y1:198,x2:729,y2:199,x3:730,y3:206},//v
							{x1:730,y1:206,x2:732,y2:212,x3:725,y3:211},//d
							{x1:725,y1:211,x2:728,y2:216,x3:727,y3:220},//D
							{x1:727,y1:220,x2:727,y2:222,x3:722,y3:224},
							{x1:722,y1:224,x2:717,y2:230,x3:733,y3:246},//P
							{x1:733,y1:246,x2:746,y2:221,x3:738,y3:198},
							]},
					{Pieza:"27P",IniTrazo:{x:727,y:220},Cara:"transparent",
					lCurva:[{x1:727,y1:220,x2:724,y2:229,x3:709,y3:220},//P
							{x1:709,y1:220,x2:706,y2:214,x3:699,y3:217},//P
							{x1:699,y1:217,x2:703,y2:223,x3:701,y3:230},//P
							{x1:701,y1:230,x2:692,y2:229,x3:694,y3:244},//P
							{x1:694,y1:244,x2:729,y2:260,x3:733,y3:246},
							{x1:733,y1:246,x2:717,y2:230,x3:722,y3:224},//P
							{x1:722,y1:224,x2:727,y2:222,x3:727,y3:220},
							]},
					{Pieza:"27V",IniTrazo:{x:697,y:198},Cara:"transparent",
					lCurva:[{x1:697,y1:198,x2:704,y2:200,x3:719,y3:203},//v
							{x1:719,y1:203,x2:721,y2:201,x3:730,y3:206},//v
							{x1:730,y1:206,x2:729,y2:199,x3:738,y3:198},//v
							{x1:738,y1:198,x2:737,y2:185,x3:715,y3:186},//v
							{x1:715,y1:186,x2:696,y2:178,x3:689,y3:191},//v
							{x1:689,y1:191,x2:704,y2:200,x3:697,y3:198},//v
							]},
					{Pieza:"28O",IniTrazo:{x:753,y:204},Cara:"transparent",
					lCurva:[{x1:753,y1:204,x2:756,y2:205,x3:767,y3:202},//v
							{x1:767,y1:202,x2:777,y2:205,x3:781,y3:213},//v
							{x1:781,y1:213,x2:779,y2:210,x3:782,y3:220},//d
							{x1:782,y1:220,x2:780,y2:228,x3:775,y3:226},//D
							{x1:775,y1:226,x2:769,y2:222,x3:763,y3:224},//P
							{x1:763,y1:224,x2:756,y2:218,x3:750,y3:220},//P
							{x1:750,y1:220,x2:757,y2:217,x3:756,y3:211},//M
							{x1:756,y1:211,x2:752,y2:205,x3:753,y3:204},//M
							]},
					{Pieza:"28M",IniTrazo:{x:742,y:196},Cara:"transparent",
					lCurva:[{x1:742,y1:196,x2:750,y2:198,x3:753,y3:204},//v
							{x1:753,y1:204,x2:752,y2:205,x3:756,y3:211},//M
							{x1:756,y1:211,x2:757,y2:217,x3:750,y3:220},//M
							{x1:750,y1:220,x2:756,y2:226,x3:753,y3:236},//P
							{x1:753,y1:236,x2:748,y2:238,x3:752,y3:246},//P
							{x1:752,y1:246,x2:734,y2:217,x3:742,y3:196},
							]},
					{Pieza:"28D",IniTrazo:{x:789,y:202},Cara:"transparent",
					lCurva:[{x1:789,y1:202,x2:780,y2:206,x3:781,y3:213},//v
							{x1:781,y1:213,x2:779,y2:210,x3:782,y3:220},//d
							{x1:782,y1:220,x2:780,y2:228,x3:775,y3:226},//D
							{x1:775,y1:226,x2:767,y2:232,x3:775,y3:234},//P
							{x1:775,y1:234,x2:782,y2:237,x3:784,y3:244},//P
							{x1:784,y1:244,x2:798,y2:217,x3:789,y3:202}
							]},
					{Pieza:"28P",IniTrazo:{x:775,y:226},Cara:"transparent",
					lCurva:[{x1:775,y1:226,x2:769,y2:222,x3:763,y3:224},//P
							{x1:763,y1:224,x2:756,y2:218,x3:750,y3:220},//P
							{x1:750,y1:220,x2:756,y2:226,x3:753,y3:236},//P
							{x1:753,y1:236,x2:748,y2:238,x3:752,y3:246},//P
							{x1:752,y1:246,x2:781,y2:252,x3:784,y3:244},
							{x1:775,y1:234,x2:782,y2:237,x3:784,y3:244},//P
							{x1:784,y1:244,x2:782,y2:237,x3:775,y3:234},//P
							{x1:775,y1:234,x2:767,y2:232,x3:775,y3:226},//P
							]},
					{Pieza:"28P",IniTrazo:{x:753,y:204},Cara:"transparent",
					lCurva:[{x1:753,y1:204,x2:756,y2:205,x3:767,y3:202},//v
							{x1:767,y1:202,x2:777,y2:205,x3:781,y3:213},//v
							{x1:781,y1:213,x2:780,y2:206,x3:789,y3:202},//v
							{x1:789,y1:202,x2:779,y2:196,x3:769,y3:191},
							{x1:769,y1:191,x2:753,y2:181,x3:742,y3:196},
							{x1:742,y1:196,x2:750,y2:198,x3:753,y3:204},//v
							]},
					{Pieza:"48O",IniTrazo:{x:24,y:401},Cara:"transparent",
					lCurva:[{x1:24,y1:401,x2:33,y2:401,x3:35,y3:395},//p
							{x1:35,y1:395,x2:41,y2:392,x3:47,y3:403},//p
							{x1:47,y1:403,x2:60,y2:399,x3:68,y3:399},//p
							{x1:68,y1:399,x2:63,y2:402,x3:65,y3:409},//m
							{x1:65,y1:409,x2:63,y2:413,x3:68,y3:420},//m
							{x1:68,y1:420,x2:57,y2:414,x3:46,y3:412},//v
							{x1:46,y1:412,x2:44,y2:419,x3:38,y3:422},//v
							{x1:38,y1:422,x2:34,y2:412,x3:24,y3:413},//v
							{x1:24,y1:413,x2:28,y2:406,x3:24,y3:401},//d
							]},
					{Pieza:"48D",IniTrazo:{x:19,y:423},Cara:"transparent",
					lCurva:[{x1:19,y1:423,x2:28,y2:419,x3:24,y3:413},//v
							{x1:24,y1:413,x2:28,y2:406,x3:24,y3:401},//d
							{x1:24,y1:401,x2:21,y2:393,x3:28,y3:389},//p
							{x1:28,y1:389,x2:34,y2:382,x3:34,y3:368},//p
							{x1:34,y1:368,x2:6,y2:387,x3:19,y3:423},
							]},
					{Pieza:"48M",IniTrazo:{x:67,y:427},Cara:"transparent",
					lCurva:[{x1:67,y1:427,x2:68,y2:424,x3:68,y3:420},//v
							{x1:65,y1:409,x2:63,y2:413,x3:65,y3:409},//m
							{x1:65,y1:409,x2:63,y2:402,x3:68,y3:399},//m
							{x1:68,y1:399,x2:56,y2:389,x3:60,y3:383},//p
							{x1:60,y1:383,x2:60,y2:378,x3:63,y3:370},//p
							{x1:63,y1:370,x2:70,y2:385,x3:76,y3:393},
							{x1:76,y1:393,x2:79,y2:419,x3:67,y3:427},
							]},
					{Pieza:"48P",IniTrazo:{x:24,y:401},Cara:"transparent",
					lCurva:[{x1:24,y1:401,x2:33,y2:401,x3:35,y3:395},//p
							{x1:35,y1:395,x2:41,y2:392,x3:47,y3:403},//p
							{x1:47,y1:403,x2:60,y2:399,x3:68,y3:399},//p
							{x1:68,y1:399,x2:56,y2:389,x3:60,y3:383},//p
							{x1:60,y1:383,x2:60,y2:378,x3:63,y3:370},//p
							{x1:60,y1:383,x2:60,y2:378,x3:63,y3:370},//p
							{x1:63,y1:370,x2:50,y2:362,x3:34,y3:368},
							{x1:34,y1:368,x2:34,y2:382,x3:28,y3:389},//p
							{x1:28,y1:389,x2:21,y2:393,x3:24,y3:401},//p
							]},
					{Pieza:"48V",IniTrazo:{x:68,y:420},Cara:"transparent",
					lCurva:[{x1:68,y1:420,x2:57,y2:414,x3:46,y3:412},//v
							{x1:46,y1:412,x2:44,y2:419,x3:38,y3:422},//v
							{x1:38,y1:422,x2:34,y2:412,x3:24,y3:413},//v
							{x1:24,y1:413,x2:28,y2:419,x3:19,y3:423},//v
							{x1:19,y1:423,x2:28,y2:433,x3:43,y3:429},
							{x1:43,y1:429,x2:63,y2:436,x3:67,y3:427},
							{x1:67,y1:427,x2:68,y2:424,x3:68,y3:420},//v
							]},
					{Pieza:"47O",IniTrazo:{x:86,y:397},Cara:"transparent",
					lCurva:[{x1:86,y1:397,x2:93,y2:389,x3:106,y3:400},//p
							{x1:106,y1:400,x2:119,y2:403,x3:116,y3:400},//p
							{x1:116,y1:400,x2:124,y2:392,x3:133,y3:398},//p
							{x1:133,y1:398,x2:126,y2:400,x3:130,y3:409},//m
							{x1:130,y1:409,x2:126,y2:406,x3:130,y3:416},//m
							{x1:130,y1:416,x2:126,y2:428,x3:110,y3:414},//v
							{x1:110,y1:414,x2:95,y2:435,x3:84,y3:413},//v
							{x1:84,y1:413,x2:88,y2:406,x3:86,y3:397},//d
							]},
					{Pieza:"47D",IniTrazo:{x:80,y:422},Cara:"transparent",
					lCurva:[{x1:80,y1:422,x2:93,y2:389,x3:84,y3:413},//v
							{x1:84,y1:413,x2:88,y2:406,x3:86,y3:397},//
							{x1:86,y1:397,x2:98,y2:392,x3:95,y3:379},//p
							{x1:95,y1:379,x2:98,y2:373,x3:91,y3:372},//p
							{x1:91,y1:372,x2:68,y2:390,x3:80,y3:422},
							]},
					{Pieza:"47M",IniTrazo:{x:131,y:429},Cara:"transparent",
					lCurva:[{x1:131,y1:429,x2:133,y2:419,x3:130,y3:416},//v
							{x1:130,y1:416,x2:126,y2:406,x3:130,y3:409},//
							{x1:130,y1:409,x2:126,y2:400,x3:133,y3:398},//
							{x1:133,y1:398,x2:119,y2:389,x3:123,y3:379},//p
							{x1:123,y1:379,x2:122,y2:374,x3:134,y3:376},//p
							{x1:134,y1:376,x2:149,y2:414,x3:131,y3:429},//p
							]},
					{Pieza:"47P",IniTrazo:{x:86,y:397},Cara:"transparent",
					lCurva:[{x1:86,y1:397,x2:93,y2:389,x3:106,y3:400},//p
							{x1:106,y1:400,x2:119,y2:403,x3:116,y3:400},//p
							{x1:116,y1:400,x2:124,y2:392,x3:133,y3:398},//p
							{x1:133,y1:398,x2:119,y2:389,x3:123,y3:379},//p
							{x1:123,y1:379,x2:122,y2:374,x3:134,y3:376},//p
							{x1:134,y1:376,x2:108,y2:357,x3:91,y3:372},
							{x1:91,y1:372,x2:98,y2:373,x3:95,y3:379},//p
							{x1:95,y1:379,x2:98,y2:392,x3:86,y3:397},//p
							]},
					{Pieza:"47V",IniTrazo:{x:130,y:416},Cara:"transparent",
					lCurva:[{x1:130,y1:416,x2:126,y2:428,x3:110,y3:414},//v
							{x1:110,y1:414,x2:95,y2:435,x3:84,y3:413},//v
							{x1:84,y1:413,x2:93,y2:389,x3:80,y3:422},//v
							{x1:80,y1:422,x2:86,y2:433,x3:107,y3:430},
							{x1:107,y1:430,x2:123,y2:437,x3:131,y3:429},
							{x1:131,y1:429,x2:133,y2:419,x3:130,y3:416},
							]},
					{Pieza:"46O",IniTrazo:{x:155,y:398},Cara:"transparent",
					lCurva:[{x1:155,y1:398,x2:162,y2:391,x3:175,y3:402},//p
							{x1:175,y1:402,x2:184,y2:388,x3:189,y3:396},//p
							{x1:189,y1:396,x2:192,y2:401,x3:199,y3:398},//p
							{x1:199,y1:398,x2:192,y2:410,x3:199,y3:416},//m
							{x1:199,y1:416,x2:192,y2:414,x3:189,y3:422},//v
							{x1:189,y1:422,x2:177,y2:418,x3:177,y3:414},//v
							{x1:177,y1:414,x2:170,y2:415,x3:166,y3:421},//v
							{x1:166,y1:421,x2:151,y2:418,x3:157,y3:418},//v
							{x1:157,y1:418,x2:159,y2:406,x3:155,y3:398},//d
							]},
					{Pieza:"46D",IniTrazo:{x:154,y:424},Cara:"transparent",
					lCurva:[{x1:154,y1:424,x2:153,y2:418,x3:157,y3:418},//v
							{x1:157,y1:418,x2:159,y2:406,x3:155,y3:398},//d
							{x1:155,y1:398,x2:161,y2:391,x3:163,y3:381},//p
							{x1:163,y1:381,x2:162,y2:368,x3:148,y3:381},//p
							{x1:148,y1:381,x2:147,y2:391,x3:141,y3:396},
							{x1:141,y1:396,x2:136,y2:418,x3:154,y3:424},
							]},
					{Pieza:"46M",IniTrazo:{x:204,y:426},Cara:"transparent",
					lCurva:[{x1:204,y1:426,x2:200,y2:422,x3:199,y3:416},//v
							{x1:199,y1:416,x2:192,y2:410,x3:199,y3:398},//m
							{x1:199,y1:398,x2:187,y2:389,x3:192,y3:381},//p
							{x1:192,y1:381,x2:198,y2:376,x3:202,y3:383},//p
							{x1:202,y1:383,x2:213,y2:403,x3:204,y3:426},
							]},
					{Pieza:"46P",IniTrazo:{x:155,y:398},Cara:"transparent",
					lCurva:[{x1:155,y1:398,x2:162,y2:391,x3:175,y3:402},//p
							{x1:175,y1:402,x2:184,y2:388,x3:189,y3:396},//p
							{x1:189,y1:396,x2:192,y2:401,x3:199,y3:398},//p
							{x1:199,y1:398,x2:187,y2:389,x3:192,y3:381},//p
							{x1:192,y1:381,x2:198,y2:376,x3:202,y3:383},//p
							{x1:202,y1:383,x2:174,y2:351,x3:148,y3:381},
							{x1:148,y1:381,x2:162,y2:368,x3:163,y3:381},//p
							{x1:163,y1:381,x2:161,y2:391,x3:155,y3:398},//p
							]},
					{Pieza:"46V",IniTrazo:{x:204,y:426},Cara:"transparent",
					lCurva:[{x1:204,y1:426,x2:200,y2:422,x3:199,y3:416},//v
							{x1:199,y1:416,x2:192,y2:414,x3:189,y3:422},//v
							{x1:189,y1:422,x2:177,y2:418,x3:177,y3:414},//v
							{x1:177,y1:414,x2:170,y2:415,x3:166,y3:421},//v
							{x1:166,y1:421,x2:151,y2:418,x3:157,y3:418},//v
							{x1:157,y1:418,x2:153,y2:418,x3:154,y3:424},//v
							{x1:154,y1:424,x2:156,y2:436,x3:179,y3:431},
							{x1:179,y1:431,x2:197,y2:435,x3:204,y3:426},
							]},
					{Pieza:"45O",IniTrazo:{x:218,y:401},Cara:"transparent",
					lCurva:[{x1:218,y1:401,x2:226,y2:405,x3:230,y3:395},//p
							{x1:230,y1:395,x2:234,y2:406,x3:240,y3:404},//p
							{x1:240,y1:404,x2:239,y2:409,x3:239,y3:411},//m
							{x1:239,y1:411,x2:237,y2:418,x3:229,y3:414},//v
							{x1:229,y1:414,x2:220,y2:413,x3:217,y3:409},//v
							{x1:217,y1:409,x2:219,y2:406,x3:218,y3:401},//d
							]},
					{Pieza:"45D",IniTrazo:{x:214,y:420},Cara:"transparent",
					lCurva:[{x1:214,y1:420,x2:216,y2:410,x3:217,y3:409},//v
							{x1:217,y1:409,x2:219,y2:406,x3:218,y3:401},//d
							{x1:218,y1:401,x2:222,y2:393,x3:217,y3:385},//p
							{x1:217,y1:385,x2:204,y2:404,x3:214,y3:420},
							]},
					{Pieza:"45M",IniTrazo:{x:248,y:421},Cara:"transparent",
					lCurva:[{x1:248,y1:421,x2:242,y2:415,x3:239,y3:411},//v
							{x1:239,y1:411,x2:239,y2:409,x3:240,y3:404},//m
							{x1:240,y1:404,x2:229,y2:391,x3:244,y3:384},//p
							{x1:244,y1:384,x2:258,y2:405,x3:248,y3:421},
							]},
					{Pieza:"45P",IniTrazo:{x:218,y:401},Cara:"transparent",
					lCurva:[{x1:218,y1:401,x2:226,y2:405,x3:230,y3:395},//p
							{x1:230,y1:395,x2:234,y2:406,x3:240,y3:404},//p
							{x1:240,y1:404,x2:229,y2:391,x3:244,y3:384},//p
							{x1:244,y1:384,x2:227,y2:376,x3:217,y3:385},
							{x1:217,y1:385,x2:222,y2:393,x3:218,y3:401},//p
							]},
					{Pieza:"45V",IniTrazo:{x:239,y:411},Cara:"transparent",
					lCurva:[{x1:239,y1:411,x2:237,y2:418,x3:229,y3:414},//v
							{x1:229,y1:414,x2:220,y2:413,x3:217,y3:409},//v
							{x1:217,y1:409,x2:216,y2:410,x3:214,y3:420},//v
							{x1:214,y1:420,x2:220,y2:426,x3:232,y3:426},
							{x1:232,y1:426,x2:243,y2:425,x3:248,y3:421},
							{x1:248,y1:421,x2:242,y2:415,x3:239,y3:411},//v
							]},
					{Pieza:"44O",IniTrazo:{x:262,y:401},Cara:"transparent",
					lCurva:[{x1:262,y1:401,x2:261,y2:395,x3:273,y3:395},//p
							{x1:273,y1:395,x2:284,y2:395,x3:285,y3:400},//p
							{x1:285,y1:400,x2:278,y2:408,x3:283,y3:410},//m
							{x1:283,y1:410,x2:282,y2:415,x3:273,y3:415},//v
							{x1:273,y1:415,x2:267,y2:416,x3:261,y3:411},//v
							{x1:261,y1:411,x2:266,y2:405,x3:262,y3:401},//d
							]},
					{Pieza:"44D",IniTrazo:{x:257,y:419},Cara:"transparent",
					lCurva:[{x1:257,y1:419,x2:261,y2:416,x3:261,y3:411},//v
							{x1:261,y1:411,x2:266,y2:405,x3:262,y3:401},//d
							{x1:262,y1:401,x2:264,y2:392,x3:265,y3:389},//p
							{x1:265,y1:389,x2:266,y2:386,x3:260,y3:384},//p
							{x1:260,y1:384,x2:244,y2:403,x3:257,y3:419},
							]},
					{Pieza:"44M",IniTrazo:{x:290,y:420},Cara:"transparent",
					lCurva:[{x1:290,y1:420,x2:283,y2:417,x3:283,y3:411},//v
							{x1:283,y1:411,x2:278,y2:408,x3:285,y3:400},//m
							{x1:285,y1:400,x2:279,y2:388,x3:281,y3:385},//p
							{x1:281,y1:385,x2:282,y2:385,x3:287,y3:384},//p
							{x1:287,y1:384,x2:305,y2:400,x3:290,y3:420},
							]},
					{Pieza:"44P",IniTrazo:{x:262,y:401},Cara:"transparent",
					lCurva:[{x1:262,y1:401,x2:261,y2:395,x3:273,y3:395},//p
							{x1:273,y1:395,x2:284,y2:395,x3:285,y3:400},//p
							{x1:285,y1:400,x2:279,y2:388,x3:281,y3:385},//p
							{x1:281,y1:385,x2:282,y2:385,x3:287,y3:384},//p
							{x1:287,y1:384,x2:274,y2:377,x3:260,y3:384},
							{x1:260,y1:384,x2:266,y2:386,x3:265,y3:389},//p
							{x1:265,y1:389,x2:264,y2:392,x3:262,y3:401},//p
							]},
					{Pieza:"44V",IniTrazo:{x:290,y:420},Cara:"transparent",
					lCurva:[{x1:290,y1:420,x2:283,y2:417,x3:283,y3:411},//v
							{x1:283,y1:410,x2:282,y2:415,x3:273,y3:415},//v
							{x1:273,y1:415,x2:267,y2:416,x3:261,y3:411},//v
							{x1:261,y1:411,x2:261,y2:416,x3:257,y3:419},//v
							{x1:257,y1:419,x2:270,y2:432,x3:290,y3:420},
							]},
					{Pieza:"43O",IniTrazo:{x:308,y:390},Cara:"transparent",
					lCurva:[{x1:308,y1:390,x2:315,y2:393,x3:324,y3:388},//p
							{x1:324,y1:388,x2:317,y2:395,x3:324,y3:401},//m
							{x1:324,y1:401,x2:317,y2:399,x3:304,y3:401},//v
							{x1:304,y1:401,x2:317,y2:393,x3:308,y3:390},//d
							
							]},
					{Pieza:"43D",IniTrazo:{x:296,y:412},Cara:"transparent",
					lCurva:[{x1:296,y1:412,x2:300,y2:400,x3:304,y3:401},//v
							{x1:304,y1:401,x2:317,y2:393,x3:308,y3:390},//d
							{x1:308,y1:390,x2:310,y2:381,x3:304,y3:380},//p
							{x1:304,y1:380,x2:293,y2:403,x3:296,y3:412},
							]},
					{Pieza:"43M",IniTrazo:{x:336,y:418},Cara:"transparent",
					lCurva:[{x1:336,y1:418,x2:333,y2:406,x3:324,y3:401},//v
							{x1:324,y1:401,x2:317,y2:395,x3:324,y3:388},//m
							{x1:324,y1:388,x2:320,y2:382,x3:331,y3:383},//p
							{x1:331,y1:383,x2:343,y2:406,x3:336,y3:418},
							]},
					{Pieza:"43P",IniTrazo:{x:308,y:390},Cara:"transparent",
					lCurva:[{x1:308,y1:390,x2:315,y2:393,x3:324,y3:388},//p
							{x1:324,y1:388,x2:320,y2:382,x3:331,y3:383},//p
							{x1:331,y1:383,x2:320,y2:358,x3:304,y3:380},
							{x1:304,y1:380,x2:310,y2:381,x3:308,y3:390},//p
							]},
					{Pieza:"43V",IniTrazo:{x:336,y:418},Cara:"transparent",
					lCurva:[{x1:336,y1:418,x2:333,y2:406,x3:324,y3:401},//v
							{x1:324,y1:401,x2:317,y2:399,x3:304,y3:401},//v
							{x1:304,y1:401,x2:300,y2:400,x3:296,y3:412},//v
							{x1:296,y1:412,x2:300,y2:427,x3:336,y3:418},//v	
							]},
					{Pieza:"42O",IniTrazo:{x:348,y:392},Cara:"transparent",
					lCurva:[{x1:348,y1:392,x2:352,y2:398,x3:362,y3:392},//p
							{x1:362,y1:392,x2:352,y2:398,x3:362,y3:407},//m
							{x1:362,y1:407,x2:352,y2:398,x3:346,y3:407},//v
							{x1:346,y1:407,x2:352,y2:398,x3:348,y3:392},//d
							
							]},
					{Pieza:"42D",IniTrazo:{x:339,y:409},Cara:"transparent",
					lCurva:[{x1:339,y1:409,x2:342,y2:408,x3:346,y3:407},//v
							{x1:346,y1:407,x2:352,y2:398,x3:348,y3:392},//d
							{x1:348,y1:392,x2:352,y2:398,x3:345,y3:386},//p
							{x1:345,y1:386,x2:338,y2:407,x3:339,y3:409},
							
							]},
					{Pieza:"42M",IniTrazo:{x:368,y:411},Cara:"transparent",
					lCurva:[{x1:368,y1:411,x2:365,y2:406,x3:362,y3:407},//v
							{x1:362,y1:407,x2:352,y2:398,x3:362,y3:392},//m
							{x1:362,y1:392,x2:362,y2:384,x3:364,y3:385},//p
							{x1:364,y1:385,x2:363,y2:389,x3:368,y3:411},
							
							]},
					{Pieza:"42P",IniTrazo:{x:348,y:392},Cara:"transparent",
					lCurva:[{x1:348,y1:392,x2:352,y2:398,x3:362,y3:392},//p
							{x1:362,y1:392,x2:362,y2:384,x3:364,y3:385},//p
							{x1:364,y1:385,x2:354,y2:370,x3:345,y3:386},
							{x1:345,y1:386,x2:352,y2:398,x3:348,y3:392},//p
							]},
					{Pieza:"42V",IniTrazo:{x:362,y:407},Cara:"transparent",
					lCurva:[{x1:362,y1:407,x2:352,y2:398,x3:346,y3:407},//v
							{x1:346,y1:407,x2:342,y2:408,x3:339,y3:409},//v
							{x1:339,y1:409,x2:343,y2:420,x3:368,y3:411},//v
							{x1:368,y1:411,x2:365,y2:406,x3:362,y3:407},//v
							]},
					{Pieza:"41O",IniTrazo:{x:379,y:393},Cara:"transparent",
					lCurva:[{x1:379,y1:393,x2:385,y2:398,x3:393,y3:393},//p
							{x1:393,y1:393,x2:385,y2:398,x3:392,y3:407},//m
							{x1:392,y1:407,x2:385,y2:398,x3:375,y3:407},//v
							{x1:375,y1:407,x2:385,y2:398,x3:379,y3:393},//d
							]},
					{Pieza:"41D",IniTrazo:{x:369,y:411},Cara:"transparent",
					lCurva:[{x1:369,y1:411,x2:385,y2:398,x3:375,y3:407},//v
							{x1:375,y1:407,x2:385,y2:398,x3:379,y3:393},//d
							{x1:379,y1:393,x2:377,y2:387,x3:376,y3:382},//p
							{x1:376,y1:382,x2:371,y2:402,x3:369,y3:411},
							]},
					{Pieza:"41M",IniTrazo:{x:399,y:413},Cara:"transparent",
					lCurva:[{x1:399,y1:413,x2:395,y2:410,x3:392,y3:407},//v
							{x1:392,y1:407,x2:385,y2:398,x3:393,y3:393},//m
							{x1:393,y1:393,x2:391,y2:386,x3:394,y3:384},//p
							{x1:394,y1:384,x2:400,y2:407,x3:399,y3:413},
							]},
					{Pieza:"41P",IniTrazo:{x:379,y:393},Cara:"transparent",
					lCurva:[{x1:379,y1:393,x2:385,y2:398,x3:393,y3:393},//p
							{x1:393,y1:393,x2:391,y2:386,x3:394,y3:384},//p
							{x1:394,y1:384,x2:384,y2:369,x3:376,y3:382},//p
							{x1:376,y1:382,x2:377,y2:387,x3:379,y3:393},//p
							]},
					{Pieza:"41V",IniTrazo:{x:392,y:407},Cara:"transparent",
					lCurva:[{x1:392,y1:407,x2:385,y2:398,x3:375,y3:407},//v
							{x1:375,y1:407,x2:385,y2:398,x3:369,y3:411},//v
							{x1:369,y1:411,x2:385,y2:419,x3:399,y3:413},
							{x1:399,y1:413,x2:395,y2:410,x3:392,y3:407},//v
							]},
					{Pieza:"31O",IniTrazo:{x:409,y:394},Cara:"transparent",
					lCurva:[{x1:409,y1:394,x2:413,y2:398,x3:422,y3:394},//p
							{x1:422,y1:394,x2:413,y2:398,x3:422,y3:407},//d
							{x1:422,y1:407,x2:413,y2:398,x3:404,y3:407},//v
							{x1:404,y1:407,x2:413,y2:398,x3:409,y3:394},//m
							]},
					{Pieza:"31M",IniTrazo:{x:400,y:411},Cara:"transparent",
					lCurva:[{x1:400,y1:411,x2:413,y2:398,x3:404,y3:407},//v
							{x1:404,y1:407,x2:413,y2:398,x3:409,y3:394},//m
							{x1:409,y1:394,x2:413,y2:389,x3:407,y3:384},//p
							{x1:407,y1:384,x2:401,y2:405,x3:400,y3:411},
							]},
					{Pieza:"31D",IniTrazo:{x:430,y:411},Cara:"transparent",
					lCurva:[{x1:430,y1:411,x2:423,y2:410,x3:422,y3:407},//v
							{x1:422,y1:407,x2:413,y2:398,x3:422,y3:394},//d
							{x1:422,y1:394,x2:421,y2:384,x3:424,y3:384},//p
							{x1:424,y1:384,x2:432,y2:402,x3:430,y3:411},//d
							]},
					{Pieza:"31P",IniTrazo:{x:409,y:394},Cara:"transparent",
					lCurva:[{x1:409,y1:394,x2:413,y2:398,x3:422,y3:394},//p
							{x1:422,y1:394,x2:421,y2:384,x3:424,y3:384},//p
							{x1:424,y1:384,x2:416,y2:374,x3:407,y3:384},
							{x1:407,y1:384,x2:413,y2:389,x3:409,y3:394},//p
							]},
					{Pieza:"31V",IniTrazo:{x:430,y:411},Cara:"transparent",
					lCurva:[{x1:430,y1:411,x2:423,y2:410,x3:422,y3:407},//v
							{x1:422,y1:407,x2:413,y2:398,x3:404,y3:407},//v
							{x1:404,y1:407,x2:413,y2:398,x3:400,y3:411},//v
							{x1:400,y1:411,x2:420,y2:420,x3:430,y3:411},
							]},
					{Pieza:"32O",IniTrazo:{x:439,y:393},Cara:"transparent",
					lCurva:[{x1:439,y1:393,x2:444,y2:398,x3:451,y3:393},//p
							{x1:451,y1:393,x2:444,y2:398,x3:455,y3:405},//D
							{x1:455,y1:405,x2:444,y2:398,x3:438,y3:405},//V
							{x1:438,y1:405,x2:444,y2:398,x3:439,y3:393},//M
							]},
					{Pieza:"32M",IniTrazo:{x:431,y:412},Cara:"transparent",
					lCurva:[{x1:431,y1:412,x2:436,y2:409,x3:438,y3:405},//v
							{x1:438,y1:405,x2:444,y2:398,x3:439,y3:393},//M
							{x1:439,y1:393,x2:442,y2:385,x3:438,y3:380},//p
							{x1:438,y1:380,x2:433,y2:399,x3:431,y3:412},
							]},
					{Pieza:"32D",IniTrazo:{x:460,y:411},Cara:"transparent",
					lCurva:[{x1:460,y1:411,x2:458,y2:409,x3:455,y3:405},//v
							{x1:455,y1:405,x2:444,y2:398,x3:451,y3:393},//D
							{x1:451,y1:393,x2:451,y2:386,x3:455,y3:384},//p
							{x1:455,y1:384,x2:464,y2:405,x3:460,y3:411},
							]},
					{Pieza:"32D",IniTrazo:{x:439,y:393},Cara:"transparent",
					lCurva:[{x1:439,y1:393,x2:444,y2:398,x3:451,y3:393},//p
							{x1:451,y1:393,x2:451,y2:386,x3:455,y3:384},//p
							{x1:455,y1:384,x2:445,y2:373,x3:438,y3:380},
							{x1:438,y1:380,x2:442,y2:385,x3:439,y3:393},//p
							]},
					{Pieza:"32V",IniTrazo:{x:460,y:411},Cara:"transparent",
					lCurva:[{x1:460,y1:411,x2:458,y2:409,x3:455,y3:405},//v
							{x1:455,y1:405,x2:444,y2:398,x3:438,y3:405},//V
							{x1:438,y1:405,x2:436,y2:409,x3:431,y3:412},//v
							{x1:431,y1:412,x2:446,y2:420,x3:460,y3:411},//p
							]},
					{Pieza:"33O",IniTrazo:{x:473,y:386},Cara:"transparent",
					lCurva:[{x1:473,y1:386,x2:482,y2:395,x3:490,y3:386},//p
							{x1:490,y1:386,x2:482,y2:395,x3:495,y3:406},//D
							{x1:495,y1:406,x2:482,y2:395,x3:469,y3:405},//v
							{x1:469,y1:405,x2:482,y2:395,x3:473,y3:386},//M
							]},
					{Pieza:"33M",IniTrazo:{x:464,y:416},Cara:"transparent",
					lCurva:[{x1:464,y1:416,x2:468,y2:410,x3:469,y3:405},//V
							{x1:469,y1:405,x2:482,y2:395,x3:473,y3:386},//M
							{x1:473,y1:386,x2:473,y2:383,x3:470,y3:382},//P
							{x1:470,y1:382,x2:461,y2:402,x3:464,y3:416},
							]},
					{Pieza:"33D",IniTrazo:{x:504,y:414},Cara:"transparent",
					lCurva:[{x1:504,y1:414,x2:495,y2:410,x3:495,y3:406},//V
							{x1:495,y1:406,x2:482,y2:395,x3:490,y3:386},//D
							{x1:490,y1:386,x2:491,y2:377,x3:496,y3:379},//P
							{x1:496,y1:379,x2:509,y2:402,x3:504,y3:414},
							]},
					{Pieza:"33P",IniTrazo:{x:473,y:386},Cara:"transparent",
					lCurva:[{x1:473,y1:386,x2:482,y2:395,x3:490,y3:386},//p
							{x1:490,y1:386,x2:491,y2:377,x3:496,y3:379},//P
							{x1:496,y1:379,x2:482,y2:363,x3:470,y3:382},
							{x1:470,y1:382,x2:473,y2:383,x3:473,y3:386},//P
							]},
					{Pieza:"33V",IniTrazo:{x:504,y:414},Cara:"transparent",
					lCurva:[{x1:504,y1:414,x2:495,y2:410,x3:495,y3:406},//V
							{x1:495,y1:406,x2:482,y2:395,x3:469,y3:405},//v
							{x1:469,y1:405,x2:468,y2:410,x3:464,y3:416},//V
							{x1:464,y1:416,x2:484,y2:430,x3:504,y3:414},
							{x1:504,y1:414,x2:495,y2:410,x3:495,y3:406},//V
							]},
					{Pieza:"34O",IniTrazo:{x:516,y:399},Cara:"transparent",
					lCurva:[{x1:516,y1:399,x2:523,y2:391,x3:535,y3:397},//P
							{x1:535,y1:397,x2:541,y2:405,x3:535,y3:409},//D
							{x1:535,y1:409,x2:523,y2:418,x3:517,y3:410},//V
							{x1:517,y1:410,x2:509,y2:404,x3:516,y3:399},//M
							]},
					{Pieza:"34M",IniTrazo:{x:507,y:416},Cara:"transparent",
					lCurva:[{x1:507,y1:416,x2:514,y2:414,x3:517,y3:410},//V
							{x1:517,y1:410,x2:509,y2:404,x3:516,y3:399},//M
							{x1:516,y1:399,x2:518,y2:389,x3:513,y3:386},//P
							{x1:513,y1:386,x2:500,y2:399,x3:507,y3:416},
							]},
					{Pieza:"34D",IniTrazo:{x:541,y:389},Cara:"transparent",
					lCurva:[{x1:541,y1:389,x2:537,y2:391,x3:535,y3:397},//P
							{x1:535,y1:397,x2:541,y2:405,x3:535,y3:409},//D
							{x1:535,y1:409,x2:537,y2:415,x3:543,y3:417},//V
							{x1:543,y1:417,x2:550,y2:406,x3:541,y3:389},
							]},
					{Pieza:"34P",IniTrazo:{x:541,y:389},Cara:"transparent",
					lCurva:[{x1:541,y1:389,x2:537,y2:391,x3:535,y3:397},//P
							{x1:535,y1:397,x2:523,y2:391,x3:516,y3:399},//P
							{x1:516,y1:399,x2:518,y2:389,x3:513,y3:386},//P
							{x1:513,y1:386,x2:529,y2:376,x3:541,y3:389},
							]},
					{Pieza:"34V",IniTrazo:{x:507,y:416},Cara:"transparent",
					lCurva:[{x1:507,y1:416,x2:514,y2:414,x3:517,y3:410},//V
							{x1:517,y1:410,x2:523,y2:418,x3:535,y3:409},//V
							{x1:535,y1:409,x2:537,y2:415,x3:543,y3:417},//V
							{x1:543,y1:417,x2:527,y2:434,x3:507,y3:416},
							]},
					{Pieza:"35O",IniTrazo:{x:561,y:403},Cara:"transparent",
					lCurva:[{x1:561,y1:403,x2:568,y2:393,x3:577,y3:402},//P
							{x1:577,y1:402,x2:585,y2:407,x3:576,y3:411},//D
							{x1:576,y1:411,x2:566,y2:419,x3:562,y3:413},//V
							{x1:562,y1:413,x2:551,y2:411,x3:561,y3:403},//M
							]},
					{Pieza:"35M",IniTrazo:{x:551,y:417},Cara:"transparent",
					lCurva:[{x1:551,y1:417,x2:558,y2:417,x3:562,y3:413},//V
							{x1:562,y1:413,x2:551,y2:411,x3:561,y3:403},//M
							{x1:561,y1:403,x2:563,y2:390,x3:557,y3:383},//p
							{x1:557,y1:383,x2:542,y2:400,x3:551,y3:417},//M
							]},
					{Pieza:"35D",IniTrazo:{x:584,y:385},Cara:"transparent",
					lCurva:[{x1:584,y1:385,x2:577,y2:393,x3:577,y3:402},//P
							{x1:577,y1:402,x2:585,y2:407,x3:576,y3:411},//D
							{x1:576,y1:411,x2:577,y2:414,x3:584,y3:419},//V
							{x1:584,y1:419,x2:597,y2:415,x3:584,y3:385},
							]},
					{Pieza:"35P",IniTrazo:{x:584,y:385},Cara:"transparent",
					lCurva:[{x1:584,y1:385,x2:577,y2:393,x3:577,y3:402},//P
							{x1:577,y1:402,x2:568,y2:393,x3:561,y3:403},//P
							{x1:561,y1:403,x2:563,y2:390,x3:557,y3:383},//p
							{x1:557,y1:383,x2:573,y2:372,x3:584,y3:385},
							]},
					{Pieza:"35V",IniTrazo:{x:551,y:417},Cara:"transparent",
					lCurva:[{x1:551,y1:417,x2:558,y2:417,x3:562,y3:413},//V
							{x1:562,y1:413,x2:566,y2:419,x3:576,y3:411},//V
							{x1:576,y1:411,x2:577,y2:414,x3:584,y3:419},//V
							{x1:584,y1:419,x2:573,y2:437,x3:551,y3:417},
							]},
					{Pieza:"36O",IniTrazo:{x:605,y:396},Cara:"transparent",
					lCurva:[{x1:605,y1:396,x2:622,y2:405,x3:638,y3:396},//P
							{x1:638,y1:396,x2:652,y2:409,x3:640,y3:417},//D
							{x1:640,y1:417,x2:622,y2:409,x3:611,y3:417},//V
							{x1:611,y1:417,x2:597,y2:411,x3:605,y3:396},//M
							]},
					{Pieza:"36M",IniTrazo:{x:594,y:426},Cara:"transparent",
					lCurva:[{x1:594,y1:426,x2:613,y2:422,x3:611,y3:417},//V
							{x1:611,y1:417,x2:597,y2:411,x3:605,y3:396},//M
							{x1:605,y1:396,x2:617,y2:388,x3:606,y3:385},//P
							{x1:606,y1:385,x2:598,y2:384,x3:598,y3:377},//P
							{x1:598,y1:377,x2:585,y2:400,x3:594,y3:426},
							]},
					{Pieza:"36D",IniTrazo:{x:645,y:427},Cara:"transparent",
					lCurva:[{x1:645,y1:427,x2:638,y2:423,x3:640,y3:417},//V
							{x1:640,y1:417,x2:652,y2:409,x3:638,y3:396},//D
							{x1:638,y1:396,x2:631,y2:388,x3:641,y3:383},//P
							{x1:641,y1:383,x2:648,y2:384,x3:650,y3:379},//P
							{x1:650,y1:379,x2:670,y2:412,x3:645,y3:427},
							]},
					{Pieza:"36P",IniTrazo:{x:605,y:396},Cara:"transparent",
					lCurva:[{x1:605,y1:396,x2:622,y2:405,x3:638,y3:396},//P
							{x1:638,y1:396,x2:631,y2:388,x3:641,y3:383},//P
							{x1:641,y1:383,x2:648,y2:384,x3:650,y3:379},//P
							{x1:650,y1:379,x2:625,y2:359,x3:598,y3:377},//P
							{x1:598,y1:377,x2:598,y2:384,x3:606,y3:385},//P
							{x1:606,y1:385,x2:617,y2:388,x3:605,y3:396},//P
							]},
					{Pieza:"36V",IniTrazo:{x:645,y:427},Cara:"transparent",
					lCurva:[{x1:645,y1:427,x2:638,y2:423,x3:640,y3:417},//V
							{x1:640,y1:417,x2:622,y2:409,x3:611,y3:417},//V
							{x1:611,y1:417,x2:613,y2:422,x3:594,y3:426},//V
							{x1:594,y1:426,x2:618,y2:438,x3:645,y3:427},
							]},
					{Pieza:"37O",IniTrazo:{x:673,y:396},Cara:"transparent",
					lCurva:[{x1:673,y1:396,x2:690,y2:405,x3:709,y3:396},//P
							{x1:709,y1:396,x2:718,y2:409,x3:707,y3:417},//D
							{x1:707,y1:417,x2:690,y2:409,x3:674,y3:417},//V
							{x1:674,y1:417,x2:662,y2:409,x3:673,y3:396},//M
							]},
					{Pieza:"37M",IniTrazo:{x:663,y:424},Cara:"transparent",
					lCurva:[{x1:663,y1:424,x2:673,y2:423,x3:674,y3:417},//V
							{x1:674,y1:417,x2:662,y2:409,x3:673,y3:396},//M
							{x1:673,y1:396,x2:680,y2:387,x3:673,y3:383},//P
							{x1:673,y1:383,x2:665,y2:386,x3:668,y3:379},//P
							{x1:668,y1:379,x2:650,y2:406,x3:663,y3:424},
							]},
					{Pieza:"37D",IniTrazo:{x:719,y:424},Cara:"transparent",
					lCurva:[{x1:719,y1:424,x2:707,y2:421,x3:707,y3:417},//V
							{x1:707,y1:417,x2:718,y2:409,x3:709,y3:396},//D
							{x1:709,y1:396,x2:703,y2:389,x3:711,y3:385},//P
							{x1:711,y1:385,x2:716,y2:388,x3:718,y3:382},//P
							{x1:718,y1:382,x2:728,y2:408,x3:719,y3:424},
							]},
					{Pieza:"37P",IniTrazo:{x:673,y:396},Cara:"transparent",
					lCurva:[{x1:673,y1:396,x2:690,y2:405,x3:709,y3:396},//P
							{x1:709,y1:396,x2:703,y2:389,x3:711,y3:385},//P
							{x1:711,y1:385,x2:716,y2:388,x3:718,y3:382},//P
							{x1:718,y1:382,x2:695,y2:359,x3:668,y3:379},//P
							{x1:668,y1:379,x2:665,y2:386,x3:673,y3:383},//P
							{x1:673,y1:383,x2:680,y2:387,x3:673,y3:396},//P
							]},
					{Pieza:"37V",IniTrazo:{x:663,y:424},Cara:"transparent",
					lCurva:[{x1:663,y1:424,x2:673,y2:423,x3:674,y3:417},//V
							{x1:674,y1:417,x2:690,y2:409,x3:707,y3:417},//V
							{x1:707,y1:417,x2:707,y2:421,x3:719,y3:424},//V
							{x1:719,y1:424,x2:711,y2:435,x3:690,y3:432},//V
							{x1:690,y1:432,x2:672,y2:435,x3:663,y3:424},//V
							]},
					{Pieza:"38O",IniTrazo:{x:736,y:396},Cara:"transparent",
					lCurva:[{x1:736,y1:396,x2:753,y2:405,x3:767,y3:396},//P
							{x1:767,y1:396,x2:781,y2:409,x3:767,y3:417},//D
							{x1:767,y1:417,x2:753,y2:409,x3:736,y3:417},//V
							{x1:736,y1:417,x2:729,y2:409,x3:736,y3:396},//M
							]},
					{Pieza:"38M",IniTrazo:{x:728,y:423},Cara:"transparent",
					lCurva:[{x1:728,y1:423,x2:736,y2:423,x3:736,y3:417},//V
							{x1:736,y1:417,x2:729,y2:409,x3:736,y3:396},//M
							{x1:736,y1:396,x2:742,y2:388,x3:736,y3:382},//P
							{x1:736,y1:382,x2:729,y2:388,x3:732,y3:379},//P
							{x1:732,y1:379,x2:717,y2:400,x3:728,y3:423},
							]},
					{Pieza:"38D",IniTrazo:{x:776,y:425},Cara:"transparent",
					lCurva:[{x1:776,y1:425,x2:770,y2:423,x3:767,y3:417},//V
							{x1:767,y1:417,x2:781,y2:409,x3:767,y3:396},//D
							{x1:767,y1:396,x2:760,y2:382,x3:772,y3:384},//P
							{x1:772,y1:384,x2:778,y2:388,x3:780,y3:381},//P
							{x1:780,y1:381,x2:790,y2:415,x3:776,y3:425},
							]},
					{Pieza:"38P",IniTrazo:{x:736,y:396},Cara:"transparent",
					lCurva:[{x1:736,y1:396,x2:753,y2:405,x3:767,y3:396},//P
							{x1:767,y1:396,x2:760,y2:382,x3:772,y3:384},//P
							{x1:772,y1:384,x2:778,y2:388,x3:780,y3:381},//P
							{x1:780,y1:381,x2:753,y2:358,x3:732,y3:379},//P
							{x1:732,y1:379,x2:729,y2:388,x3:736,y3:382},//P
							{x1:736,y1:382,x2:742,y2:388,x3:736,y3:396},//P
							]},
					{Pieza:"38V",IniTrazo:{x:776,y:425},Cara:"transparent",
					lCurva:[{x1:776,y1:425,x2:770,y2:423,x3:767,y3:417},//V
							{x1:767,y1:417,x2:753,y2:409,x3:736,y3:417},//V
							{x1:736,y1:417,x2:736,y2:423,x3:728,y3:423},//V
							{x1:728,y1:423,x2:734,y2:434,x3:753,y3:430},//V
							{x1:753,y1:430,x2:774,y2:433,x3:776,y3:425},//V
							]},
					{Pieza:"18T",IniTrazo:{x:14,y:125},Cara:"transparent",
					lCurva:[{x1:14,y1:125,x2:20,y2:112,x3:16,y3:82},
							{x1:16,y1:82,x2:17,y2:61,x3:17,y3:57},
							{x1:17,y1:57,x2:26,y2:64,x3:24,y3:73},
							{x1:24,y1:73,x2:25,y2:90,x3:31,y3:114},
							{x1:24,y1:114,x2:44,y2:99,x3:29,y3:64},
							{x1:29,y1:64,x2:47,y2:70,x3:45,y3:100},
							{x1:45,y1:100,x2:44,y2:116,x3:50,y3:126},
							
							]},
					{Pieza:"17T",IniTrazo:{x:66,y:126},Cara:"transparent",
					lCurva:[{x1:66,y1:126,x2:70,y2:112,x3:69,y3:98},
							{x1:69,y1:62,x2:69,y2:78,x3:70,y3:51},
							{x1:70,y1:51,x2:75,y2:54,x3:72,y3:50},
							{x1:72,y1:50,x2:87,y2:52,x3:98,y3:67},
							{x1:98,y1:67,x2:107,y2:77,x3:105,y3:110},
							{x1:105,y1:110,x2:100,y2:117,x3:108,y3:127},
							//{x1:72,y1:50,x2:82,y2:61,x3:82,y3:74},
							]},
					{Pieza:"16T",IniTrazo:{x:119,y:126},Cara:"transparent",
					lCurva:[{x1:119,y1:126,x2:125,y2:105,x3:120,y3:84},
							{x1:120,y1:84,x2:117,y2:63,x3:124,y3:51},
							{x1:124,y1:51,x2:127,y2:45,x3:133,y3:56},
							{x1:133,y1:56,x2:136,y2:50,x3:139,y3:42},
							{x1:139,y1:42,x2:154,y2:43,x3:151,y3:49},
							{x1:151,y1:49,x2:166,y2:47,x3:168,y3:92},
							{x1:168,y1:92,x2:165,y2:119,x3:172,y3:124},
							{x1:172,y1:124,x2:145,y2:118,x3:119,y3:126},
							]},
					{Pieza:"15T",IniTrazo:{x:183,y:127},Cara:"transparent",
					lCurva:[{x1:183,y1:127,x2:186,y2:95,x3:188,y3:59},
							{x1:188,y1:59,x2:190,y2:49,x3:193,y3:38},
							{x1:193,y1:38,x2:198,y2:30,x3:201,y3:42},
							{x1:201,y1:42,x2:203,y2:64,x3:211,y3:127},
							{x1:211,y1:127,x2:198,y2:122,x3:183,y3:127},
							]},
					{Pieza:"14T",IniTrazo:{x:225,y:127},Cara:"transparent",
					lCurva:[{x1:225,y1:127,x2:229,y2:82,x3:230,y3:39},
							{x1:230,y1:39,x2:237,y2:35,x3:246,y3:40},
							{x1:246,y1:40,x2:250,y2:74,x3:255,y3:126},
							{x1:255,y1:126,x2:239,y2:120,x3:225,y3:127},
							
							]},
					{Pieza:"13T",IniTrazo:{x:268,y:124},Cara:"transparent",
					lCurva:[{x1:268,y1:124,x2:273,y2:71,x3:277,y3:22},
							{x1:277,y1:22,x2:282,y2:22,x3:290,y3:22},
							{x1:290,y1:22,x2:297,y2:76,x3:301,y3:124},
							{x1:301,y1:124,x2:284,y2:115,x3:268,y3:124},
							]},
					{Pieza:"12T",IniTrazo:{x:313,y:124},Cara:"transparent",
					lCurva:[{x1:313,y1:124,x2:320,y2:60,x3:320,y3:41},
							{x1:320,y1:41,x2:322,y2:30,x3:328,y3:42},
							{x1:328,y1:42,x2:337,y2:60,x3:343,y3:124},
							{x1:343,y1:124,x2:327,y2:114,x3:313,y3:124},
							]},
					{Pieza:"11T",IniTrazo:{x:354,y:121},Cara:"transparent",
					lCurva:[{x1:354,y1:121,x2:360,y2:63,x3:370,y3:32},
							{x1:370,y1:32,x2:373,y2:27,x3:378,y3:32},
							{x1:378,y1:32,x2:388,y2:66,x3:393,y3:127},
							{x1:393,y1:127,x2:375,y2:96,x3:354,y3:121},
							]},
					{Pieza:"21T",IniTrazo:{x:407,y:124},Cara:"transparent",
					lCurva:[{x1:407,y1:124,x2:412,y2:64,x3:422,y3:32},
							{x1:422,y1:32,x2:427,y2:27,x3:430,y3:32},
							{x1:430,y1:32,x2:440,y2:66,x3:446,y3:122},
							{x1:446,y1:122,x2:424,y2:103,x3:407,y3:124},
							]},
					{Pieza:"22T",IniTrazo:{x:458,y:121},Cara:"transparent",
					lCurva:[{x1:458,y1:121,x2:462,y2:60,x3:474,y3:39},
							{x1:474,y1:39,x2:478,y2:33,x3:479,y3:42},
							{x1:479,y1:42,x2:481,y2:70,x3:487,y3:125},
							{x1:487,y1:125,x2:472,y2:111,x3:458,y3:121},
							]},
					{Pieza:"23T",IniTrazo:{x:500,y:128},Cara:"transparent",
					lCurva:[{x1:500,y1:128,x2:500,y2:61,x3:512,y3:21},
							{x1:512,y1:21,x2:518,y2:21,x3:523,y3:21},
							{x1:523,y1:22,x2:529,y2:87,x3:531,y3:121},
							{x1:531,y1:121,x2:515,y2:114,x3:500,y3:128},
							]},
					{Pieza:"24T",IniTrazo:{x:546,y:125},Cara:"transparent",
					lCurva:[{x1:546,y1:125,x2:549,y2:68,x3:556,y3:39},
							{x1:556,y1:39,x2:563,y2:34,x3:570,y3:39},
							{x1:570,y1:39,x2:573,y2:80,x3:574,y3:128},
							{x1:574,y1:128,x2:565,y2:120,x3:546,y3:125},
							]},
					{Pieza:"25T",IniTrazo:{x:590,y:127},Cara:"transparent",
					lCurva:[{x1:590,y1:127,x2:594,y2:86,x3:599,y3:39},
							{x1:599,y1:39,x2:601,y2:30,x3:608,y3:39},
							{x1:608,y1:39,x2:614,y2:58,x3:617,y3:129},
							{x1:617,y1:129,x2:603,y2:122,x3:590,y3:127},
							]},
					{Pieza:"26T",IniTrazo:{x:629,y:128},Cara:"transparent",
					lCurva:[{x1:629,y1:128,x2:635,y2:101,x3:632,y3:73},
							{x1:632,y1:73,x2:633,y2:58,x3:642,y3:50},
							{x1:642,y1:50,x2:645,y2:50,x3:648,y3:50},
							{x1:648,y1:50,x2:650,y2:39,x3:661,y3:46},
							{x1:661,y1:46,x2:664,y2:55,x3:666,y3:63},
							{x1:666,y1:63,x2:664,y2:55,x3:667,y3:52},
							{x1:667,y1:52,x2:672,y2:45,x3:678,y3:52},
							{x1:678,y1:52,x2:683,y2:70,x3:681,y3:94},
							{x1:681,y1:94,x2:676,y2:109,x3:683,y3:126},
							{x1:683,y1:126,x2:655,y2:118,x3:629,y3:128},
							]},
					{Pieza:"27T",IniTrazo:{x:694,y:127},Cara:"transparent",
					lCurva:[{x1:694,y1:127,x2:696,y2:110,x3:695,y3:93},
							{x1:695,y1:93,x2:695,y2:71,x3:708,y3:58},
							{x1:708,y1:58,x2:711,y2:55,x3:717,y3:56},
							{x1:717,y1:56,x2:720,y2:49,x3:723,y3:50},
							{x1:723,y1:50,x2:731,y2:47,x3:729,y3:55},
							{x1:729,y1:55,x2:733,y2:76,x3:732,y3:101},
							{x1:732,y1:101,x2:733,y2:116,x3:735,y3:125},
							{x1:735,y1:125,x2:716,y2:119,x3:694,y3:127},
							]},
					{Pieza:"28T",IniTrazo:{x:749,y:127},Cara:"transparent",
					lCurva:[{x1:749,y1:127,x2:750,y2:110,x3:753,y3:86},
							{x1:753,y1:86,x2:759,y2:62,x3:778,y3:56},
							{x1:778,y1:56,x2:784,y2:51,x3:783,y3:63},
							{x1:783,y1:63,x2:785,y2:91,x3:787,y3:127},
							{x1:787,y1:127,x2:770,y2:118,x3:749,y3:127},
							]},
					{Pieza:"48T",IniTrazo:{x:24,y:494},Cara:"transparent",
					lCurva:[{x1:24,y1:494,x2:19,y2:536,x3:18,y3:544},
							{x1:18,y1:544,x2:18,y2:550,x3:23,y3:559},
							{x1:23,y1:559,x2:27,y2:567,x3:29,y3:559},
							{x1:29,y1:559,x2:38,y2:531,x3:48,y3:508},
							{x1:48,y1:508,x2:48,y2:533,x3:38,y3:559},
							{x1:38,y1:559,x2:36,y2:563,x3:45,y3:560},
							{x1:45,y1:560,x2:77,y2:537,x3:68,y3:491},
							{x1:68,y1:491,x2:45,y2:497,x3:24,y3:494},
							]},
					{Pieza:"47T",IniTrazo:{x:84,y:493},Cara:"transparent",
					lCurva:[{x1:84,y1:493,x2:82,y2:508,x3:78,y3:540},
							{x1:78,y1:540,x2:82,y2:560,x3:85,y3:571},
							{x1:85,y1:571,x2:88,y2:578,x3:92,y3:571},
							{x1:92,y1:571,x2:96,y2:537,x3:110,y3:510},
							{x1:107,y1:571,x2:102,y2:580,x3:114,y3:571},
							{x1:114,y1:571,x2:139,y2:540,x3:133,y3:493},
							{x1:133,y1:493,x2:110,y2:498,x3:84,y3:493},
							]},
					{Pieza:"46T",IniTrazo:{x:149,y:493},Cara:"transparent",
					lCurva:[{x1:149,y1:493,x2:149,y2:505,x3:144,y3:534},
							{x1:144,y1:534,x2:143,y2:553,x3:144,y3:576},
							{x1:144,y1:576,x2:146,y2:586,x3:155,y3:576},
							{x1:155,y1:576,x2:162,y2:537,x3:178,y3:512},
							{x1:178,y1:512,x2:185,y2:551,x3:176,y3:575},
							{x1:176,y1:575,x2:175,y2:583,x3:185,y3:578},
							{x1:185,y1:578,x2:207,y2:562,x3:203,y3:495},
							{x1:203,y1:495,x2:176,y2:500,x3:149,y3:493},
							]},
					{Pieza:"45T",IniTrazo:{x:215,y:494},Cara:"transparent",
					lCurva:[{x1:215,y1:494,x2:222,y2:543,x3:226,y3:581},
							{x1:226,y1:581,x2:228,y2:588,x3:234,y3:579},
							{x1:234,y1:579,x2:241,y2:531,x3:244,y3:494},
							{x1:244,y1:494,x2:220,y2:494,x3:215,y3:494},
							]},
					{Pieza:"44T",IniTrazo:{x:260,y:494},Cara:"transparent",
					lCurva:[{x1:260,y1:494,x2:271,y2:690,x3:287,y3:494},
							{x1:287,y1:494,x2:255,y2:494,x3:260,y3:494},
							]},
					{Pieza:"43T",IniTrazo:{x:301,y:505},Cara:"transparent",
					lCurva:[{x1:301,y1:505,x2:313,y2:720,x3:334,y3:505},
							{x1:334,y1:505,x2:310,y2:505,x3:301,y3:505},
							]},
					{Pieza:"42T",IniTrazo:{x:345,y:507},Cara:"transparent",
					lCurva:[{x1:345,y1:507,x2:348,y2:685,x3:364,y3:507},
							{x1:361,y1:507,x2:355,y2:507,x3:345,y3:507},
							]},
					{Pieza:"41T",IniTrazo:{x:376,y:507},Cara:"transparent",
					lCurva:[{x1:376,y1:507,x2:382,y2:685,x3:394,y3:507},
							{x1:394,y1:507,x2:385,y2:507,x3:376,y3:507},
							]},
					{Pieza:"31T",IniTrazo:{x:406,y:507},Cara:"transparent",
					lCurva:[{x1:406,y1:507,x2:416,y2:685,x3:426,y3:507},
							{x1:426,y1:507,x2:412,y2:507,x3:406,y3:507},
							]},
					{Pieza:"32T",IniTrazo:{x:437,y:507},Cara:"transparent",
					lCurva:[{x1:437,y1:507,x2:447,y2:685,x3:456,y3:507},
							{x1:456,y1:507,x2:442,y2:507,x3:437,y3:507},
							]},
					{Pieza:"33T",IniTrazo:{x:467,y:505},Cara:"transparent",
					lCurva:[{x1:467,y1:505,x2:483,y2:720,x3:499,y3:505},
							{x1:499,y1:505,x2:482,y2:505,x3:467,y3:505},
							]},
					{Pieza:"34T",IniTrazo:{x:513,y:493},Cara:"transparent",
					lCurva:[{x1:513,y1:493,x2:523,y2:698,x3:541,y3:493},
							{x1:541,y1:493,x2:521,y2:493,x3:513,y3:493},
							]},
					{Pieza:"35T",IniTrazo:{x:554,y:493},Cara:"transparent",
					lCurva:[{x1:554,y1:493,x2:569,y2:698,x3:584,y3:493},
							{x1:584,y1:493,x2:565,y2:493,x3:554,y3:493},
							]},
					{Pieza:"36T",IniTrazo:{x:599,y:493},Cara:"transparent",
					lCurva:[{x1:599,y1:493,x2:599,y2:507,x3:597,y3:529},
							{x1:597,y1:529,x2:597,y2:555,x3:615,y3:578},
							{x1:615,y1:578,x2:623,y2:583,x3:622,y3:576},
							{x1:622,y1:576,x2:616,y2:540,x3:624,y3:513},
							{x1:624,y1:513,x2:639,y2:545,x3:646,y3:577},
							{x1:646,y1:577,x2:652,y2:585,x3:656,y3:576},
							{x1:656,y1:576,x2:658,y2:537,x3:652,y3:493},
							{x1:652,y1:493,x2:625,y2:494,x3:599,y3:493},
							]},
					{Pieza:"37T",IniTrazo:{x:668,y:493},Cara:"transparent",
					lCurva:[{x1:668,y1:493,x2:665,y2:512,x3:667,y3:529},
							{x1:667,y1:529,x2:672,y2:551,x3:686,y3:573},
							{x1:686,y1:573,x2:693,y2:579,x3:692,y3:567},
							{x1:692,y1:567,x2:685,y2:535,x3:691,y3:509},
							{x1:691,y1:509,x2:704,y2:539,x3:707,y3:569},
							{x1:707,y1:569,x2:708,y2:577,x3:715,y3:571},
							{x1:715,y1:571,x2:725,y2:545,x3:714,y3:493},
							{x1:714,y1:493,x2:689,y2:495,x3:668,y3:493},
							]},
					{Pieza:"38T",IniTrazo:{x:732,y:493},Cara:"transparent",
					lCurva:[{x1:732,y1:493,x2:722,y2:532,x3:756,y3:561},
							{x1:756,y1:561,x2:764,y2:564,x3:761,y3:556},
							{x1:761,y1:556,x2:750,y2:532,x3:754,y3:509},
							{x1:754,y1:509,x2:765,y2:535,x3:770,y3:558},
							{x1:770,y1:558,x2:775,y2:568,x3:778,y3:556},
							{x1:778,y1:556,x2:785,y2:542,x3:777,y3:493},
							{x1:777,y1:493,x2:752,y2:495,x3:732,y3:493},
							]},
					{Pieza:"18C",IniTrazo:{x:14,y:126},Cara:"transparent",
					lCurva:[{x1:14,y1:126,x2:-10,y2:152,x3:21,y3:165},
							{x1:21,y1:165,x2:31,y2:162,x3:47,y3:165},
							{x1:47,y1:165,x2:65,y2:162,x3:51,y3:126},
							{x1:51,y1:126,x2:30,y2:124,x3:14,y3:126},
							]},
					{Pieza:"17C",IniTrazo:{x:66,y:126},Cara:"transparent",
					lCurva:[{x1:66,y1:126,x2:49,y2:160,x3:73,y3:169},
							{x1:73,y1:169,x2:87,y2:162,x3:99,y3:169},
							{x1:99,y1:165,x2:123,y2:163,x3:108,y3:126},
							{x1:108,y1:126,x2:82,y2:124,x3:66,y3:126},
							]},
					{Pieza:"16C",IniTrazo:{x:119,y:126},Cara:"transparent",
					lCurva:[{x1:119,y1:128,x2:105,y2:165,x3:130,y3:171},
							{x1:130,y1:171,x2:142,y2:163,x3:162,y3:171},
							{x1:162,y1:171,x2:181,y2:161,x3:173,y3:126},
							{x1:173,y1:126,x2:150,y2:114,x3:119,y3:126},
							]},
					{Pieza:"15C",IniTrazo:{x:183,y:126},Cara:"transparent",
					lCurva:[{x1:183,y1:126,x2:171,y2:155,x3:178,y3:163},
							{x1:178,y1:163,x2:196,y2:185,x3:216,y3:163},
							{x1:216,y1:163,x2:221,y2:154,x3:212,y3:126},
							{x1:212,y1:126,x2:198,y2:125,x3:183,y3:126},
							]},
					{Pieza:"14C",IniTrazo:{x:225,y:128},Cara:"transparent",
					lCurva:[{x1:225,y1:128,x2:222,y2:142,x3:218,y3:157},
							{x1:218,y1:157,x2:239,y2:200,x3:261,y3:157},
							{x1:261,y1:157,x2:259,y2:142,x3:255,y3:128},
							{x1:255,y1:128,x2:240,y2:120,x3:225,y3:128},
							]},
					{Pieza:"13C",IniTrazo:{x:269,y:125},Cara:"transparent",
					lCurva:[{x1:269,y1:125,x2:265,y2:140,x3:262,y3:154},
							{x1:262,y1:154,x2:275,y2:205,x3:307,y3:165},
							{x1:307,y1:165,x2:302,y2:142,x3:301,y3:126},
							{x1:301,y1:125,x2:286,y2:118,x3:269,y3:125},
							]},
					{Pieza:"12C",IniTrazo:{x:313,y:125},Cara:"transparent",
					lCurva:[{x1:313,y1:125,x2:307,y2:149,x3:308,y3:166},
							{x1:308,y1:166,x2:325,y2:184,x3:347,y3:169},
							{x1:347,y1:169,x2:345,y2:142,x3:342,y3:124},
							{x1:342,y1:124,x2:320,y2:115,x3:313,y3:125},
							]},
					{Pieza:"11C",IniTrazo:{x:354,y:122},Cara:"transparent",
					lCurva:[{x1:354,y1:122,x2:346,y2:163,x3:351,y3:177},
							{x1:351,y1:177,x2:374,y2:177,x3:398,y3:177},
							{x1:398,y1:177,x2:397,y2:142,x3:394,y3:127},
							{x1:394,y1:127,x2:373,y2:98,x3:354,y3:122},
							]},
					{Pieza:"21C",IniTrazo:{x:408,y:124},Cara:"transparent",
					lCurva:[{x1:408,y1:124,x2:398,y2:150,x3:400,y3:178},
							{x1:400,y1:178,x2:425,y2:177,x3:450,y3:175},
							{x1:450,y1:175,x2:453,y2:147,x3:447,y3:122},
							{x1:447,y1:122,x2:420,y2:103,x3:408,y3:124},
							]},
					{Pieza:"22C",IniTrazo:{x:458,y:122},Cara:"transparent",
					lCurva:[{x1:458,y1:122,x2:453,y2:151,x3:452,y3:170},
							{x1:452,y1:170,x2:475,y2:182,x3:492,y3:164},
							{x1:492,y1:164,x2:490,y2:137,x3:487,y3:125},
							{x1:487,y1:125,x2:471,y2:110,x3:458,y3:122},
							]},
					{Pieza:"23C",IniTrazo:{x:500,y:128},Cara:"transparent",
					lCurva:[{x1:500,y1:128,x2:495,y2:147,x3:494,y3:164},
							{x1:494,y1:164,x2:520,y2:205,x3:538,y3:152},
							{x1:538,y1:152,x2:534,y2:131,x3:532,y3:121},
							{x1:532,y1:121,x2:518,y2:115,x3:500,y3:128},
							]},
					{Pieza:"24C",IniTrazo:{x:546,y:126},Cara:"transparent",
					lCurva:[{x1:546,y1:126,x2:539,y2:144,x3:539,y3:152},
							{x1:539,y1:152,x2:550,y2:205,x3:581,y3:159},
							{x1:581,y1:159,x2:578,y2:137,x3:574,y3:128},
							{x1:574,y1:128,x2:562,y2:120,x3:546,y3:126},
							]},
					{Pieza:"25C",IniTrazo:{x:589,y:128},Cara:"transparent",
					lCurva:[{x1:589,y1:128,x2:574,y2:152,x3:588,y3:167},
							{x1:588,y1:167,x2:603,y2:179,x3:620,y3:167},
							{x1:620,y1:167,x2:628,y2:152,x3:618,y3:129},
							{x1:618,y1:129,x2:600,y2:121,x3:589,y3:128},
							]},
					{Pieza:"26C",IniTrazo:{x:629,y:128},Cara:"transparent",
					lCurva:[{x1:629,y1:128,x2:610,y2:152,x3:639,y3:172},
							{x1:639,y1:172,x2:655,y2:168,x3:670,y3:172},
							{x1:670,y1:172,x2:690,y2:165,x3:683,y3:127},
							{x1:683,y1:127,x2:653,y2:118,x3:629,y3:128},
							]},
					{Pieza:"27C",IniTrazo:{x:694,y:127},Cara:"transparent",
					lCurva:[{x1:694,y1:127,x2:675,y2:158,x3:700,y3:169},
							{x1:700,y1:172,x2:715,y2:168,x3:728,y3:169},
							{x1:728,y1:169,x2:746,y2:158,x3:736,y3:126},
							{x1:736,y1:126,x2:720,y2:120,x3:694,y3:127},
							]},
					{Pieza:"26C",IniTrazo:{x:749,y:128},Cara:"transparent",
					lCurva:[{x1:749,y1:128,x2:732,y2:153,x3:754,y3:164},
							{x1:754,y1:164,x2:765,y2:163,x3:782,y3:164},
							{x1:782,y1:164,x2:800,y2:158,x3:788,y3:127},
							{x1:788,y1:127,x2:767,y2:120,x3:749,y3:128},
							]},
					{Pieza:"48C",IniTrazo:{x:24,y:494},Cara:"transparent",
					lCurva:[{x1:24,y1:494,x2:4,y2:459,x3:29,y3:451},
							{x1:29,y1:451,x2:46,y2:457,x3:64,y3:451},
							{x1:64,y1:451,x2:84,y2:450,x3:68,y3:490},
							{x1:68,y1:490,x2:54,y2:497,x3:24,y3:494},
							]},
					{Pieza:"47C",IniTrazo:{x:85,y:493},Cara:"transparent",
					lCurva:[{x1:85,y1:493,x2:67,y2:450,x3:93,y3:451},
							{x1:93,y1:451,x2:110,y2:457,x3:126,y3:451},
							{x1:126,y1:451,x2:148,y2:450,x3:134,y3:493},
							{x1:134,y1:493,x2:112,y2:497,x3:85,y3:493},
							]},
					{Pieza:"46C",IniTrazo:{x:150,y:493},Cara:"transparent",
					lCurva:[{x1:150,y1:493,x2:129,y2:456,x3:157,y3:447},
							{x1:157,y1:447,x2:179,y2:454,x3:193,y3:447},
							{x1:193,y1:447,x2:218,y2:450,x3:202,y3:494},
							{x1:202,y1:494,x2:178,y2:499,x3:150,y3:493},
							]},
					{Pieza:"45C",IniTrazo:{x:216,y:493},Cara:"transparent",
					lCurva:[{x1:216,y1:493,x2:213,y2:479,x3:208,y3:459},
							{x1:208,y1:459,x2:231,y2:428,x3:251,y3:457},
							{x1:251,y1:457,x2:248,y2:479,x3:245,y3:493},
							{x1:245,y1:493,x2:228,y2:494,x3:216,y3:493},
							]},
					{Pieza:"44C",IniTrazo:{x:259,y:494},Cara:"transparent",
					lCurva:[{x1:259,y1:494,x2:257,y2:479,x3:252,y3:461},
							{x1:252,y1:461,x2:273,y2:415,x3:294,y3:461},
							{x1:294,y1:461,x2:290,y2:483,x3:288,y3:493},
							{x1:288,y1:493,x2:274,y2:494,x3:259,y3:494},
							]},
					{Pieza:"43C",IniTrazo:{x:302,y:505},Cara:"transparent",
					lCurva:[{x1:302,y1:505,x2:300,y2:483,x3:295,y3:455},
							{x1:295,y1:455,x2:320,y2:420,x3:338,y3:451},
							{x1:338,y1:451,x2:335,y2:483,x3:332,y3:505},
							{x1:332,y1:505,x2:317,y2:503,x3:302,y3:505},
							]},
					{Pieza:"42C",IniTrazo:{x:345,y:507},Cara:"transparent",
					lCurva:[{x1:345,y1:507,x2:337,y2:467,x3:339,y3:446},
							{x1:339,y1:446,x2:350,y2:446,x3:368,y3:446},
							{x1:368,y1:446,x2:368,y2:469,x3:364,y3:507},
							{x1:364,y1:507,x2:354,y2:505,x3:345,y3:507},
							]},
					{Pieza:"41C",IniTrazo:{x:376,y:507},Cara:"transparent",
					lCurva:[{x1:376,y1:507,x2:371,y2:484,x3:370,y3:446},
							{x1:370,y1:446,x2:380,y2:446,x3:400,y3:446},
							{x1:400,y1:446,x2:400,y2:470,x3:394,y3:507},
							{x1:394,y1:507,x2:384,y2:505,x3:376,y3:507},
							]},
					{Pieza:"31C",IniTrazo:{x:407,y:507},Cara:"transparent",
					lCurva:[{x1:407,y1:507,x2:403,y2:479,x3:400,y3:446},
							{x1:400,y1:446,x2:412,y2:446,x3:431,y3:446},
							{x1:431,y1:446,x2:429,y2:482,x3:425,y3:507},
							{x1:425,y1:507,x2:415,y2:505,x3:407,y3:507},
							]},
					{Pieza:"32C",IniTrazo:{x:437,y:507},Cara:"transparent",
					lCurva:[{x1:437,y1:507,x2:434,y2:479,x3:431,y3:446},
							{x1:431,y1:446,x2:452,y2:446,x3:462,y3:446},
							{x1:462,y1:446,x2:460,y2:479,x3:456,y3:507},
							{x1:456,y1:507,x2:445,y2:505,x3:437,y3:507},
							]},
					{Pieza:"33C",IniTrazo:{x:468,y:505},Cara:"transparent",
					lCurva:[{x1:468,y1:505,x2:464,y2:480,x3:462,y3:448},
							{x1:462,y1:448,x2:479,y2:420,x3:505,y3:457},
							{x1:505,y1:457,x2:502,y2:484,x3:498,y3:505},
							{x1:498,y1:505,x2:488,y2:504,x3:468,y3:505},
							]},
					{Pieza:"34C",IniTrazo:{x:513,y:493},Cara:"transparent",
					lCurva:[{x1:513,y1:493,x2:507,y2:477,x3:505,y3:463},
							{x1:505,y1:463,x2:525,y2:415,x3:548,y3:463},
							{x1:548,y1:463,x2:545,y2:480,x3:541,y3:492},
							{x1:541,y1:492,x2:528,y2:492,x3:513,y3:493},
							]},
					{Pieza:"35C",IniTrazo:{x:556,y:492},Cara:"transparent",
					lCurva:[{x1:556,y1:492,x2:549,y2:477,x3:548,y3:458},
							{x1:548,y1:458,x2:571,y2:425,x3:591,y3:459},
							{x1:591,y1:459,x2:589,y2:480,x3:584,y3:492},
							{x1:584,y1:492,x2:570,y2:492,x3:556,y3:492},
							]},
					{Pieza:"36C",IniTrazo:{x:599,y:493},Cara:"transparent",
					lCurva:[{x1:599,y1:493,x2:580,y2:453,x3:607,y3:447},
							{x1:607,y1:447,x2:621,y2:454,x3:642,y3:447},
							{x1:642,y1:447,x2:670,y2:453,x3:651,y3:492},
							{x1:651,y1:492,x2:625,y2:493,x3:599,y3:492},
							]},
					{Pieza:"37C",IniTrazo:{x:668,y:493},Cara:"transparent",
					lCurva:[{x1:668,y1:493,x2:647,y2:453,x3:674,y3:450},
							{x1:674,y1:450,x2:691,y2:457,x3:708,y3:450},
							{x1:708,y1:450,x2:732,y2:453,x3:714,y3:492},
							{x1:714,y1:492,x2:690,y2:493,x3:668,y3:492},
							]},
					{Pieza:"38C",IniTrazo:{x:732,y:492},Cara:"transparent",
					lCurva:[{x1:732,y1:492,x2:710,y2:453,x3:737,y3:450},
							{x1:737,y1:450,x2:754,y2:457,x3:771,y3:450},
							{x1:771,y1:450,x2:794,y2:453,x3:775,y3:492},
							{x1:775,y1:492,x2:757,y2:493,x3:732,y3:492},
							]},

					];
var TConducto =[{Pieza:"18",IniTrazo:{x:33,y:190},Cara:"transparent",
					lCurva:[{x1:33,y1:213,x2:33,y2:213,x3:33,y3:213},
							{x1:33,y1:213,x2:24,y2:212,x3:20,y3:220},
							{x1:20,y1:220,x2:16,y2:225,x3:7,y3:210},
							{x1:7,y1:210,x2:10,y2:195,x3:33,y3:190},
							]},
					];
var Extrac =[{Pieza:"18",IniTrazo:{x:13,y:236},Cara:"transparent",
					lCurva:[{x1:9,y1:242,x2:53,y2:186},
							{x1:55,y1:244,x2:11,y2:186},
							]},
			{Pieza:"17",IniTrazo:{x:66,y:253},Cara:"transparent",
					lCurva:[{x1:66,y1:253,x2:107,y2:182},
							{x1:105,y1:253,x2:66,y2:182},
							]},
			{Pieza:"16",IniTrazo:{x:0,y:0},Cara:"transparent",
					lCurva:[{x1:119,y1:254,x2:170,y2:182},
							{x1:170,y1:254,x2:123,y2:182},
							]},
			{Pieza:"15",IniTrazo:{x:0,y:0},Cara:"transparent",
					lCurva:[{x1:179,y1:241,x2:214,y2:189},
							{x1:214,y1:241,x2:181,y2:189},
							]},	
			{Pieza:"14",IniTrazo:{x:0,y:0},Cara:"transparent",
					lCurva:[{x1:224,y1:241,x2:256,y2:193},
							{x1:256,y1:239,x2:221,y2:193},
							]},	
			{Pieza:"13",IniTrazo:{x:0,y:0},Cara:"transparent",
					lCurva:[{x1:269,y1:238,x2:302,y2:200},
							{x1:299,y1:236,x2:265,y2:199},
							]},
			{Pieza:"12",IniTrazo:{x:0,y:0},Cara:"transparent",
					lCurva:[{x1:314,y1:230,x2:345,y2:206},
							{x1:341,y1:230,x2:310,y2:206},
							]},	
			{Pieza:"11",IniTrazo:{x:0,y:0},Cara:"transparent",
					lCurva:[{x1:361,y1:236,x2:393,y2:197},
							{x1:389,y1:235,x2:352,y2:200},
							]},	
			{Pieza:"21",IniTrazo:{x:0,y:0},Cara:"transparent",
					lCurva:[{x1:409,y1:237,x2:444,y2:197},
							{x1:443,y1:235,x2:405,y2:200},
							]},	
			{Pieza:"22",IniTrazo:{x:0,y:0},Cara:"transparent",
					lCurva:[{x1:457,y1:232,x2:490,y2:207},
							{x1:485,y1:235,x2:454,y2:207},
							]},
			{Pieza:"23",IniTrazo:{x:0,y:0},Cara:"transparent",
					lCurva:[{x1:498,y1:235,x2:533,y2:200},
							{x1:532,y1:235,x2:496,y2:202},
							]},
			{Pieza:"24",IniTrazo:{x:0,y:0},Cara:"transparent",
					lCurva:[{x1:545,y1:235,x2:573,y2:195},
							{x1:574,y1:234,x2:543,y2:198},
							]},
			{Pieza:"25",IniTrazo:{x:0,y:0},Cara:"transparent",
					lCurva:[{x1:588,y1:237,x2:620,y2:194},
							{x1:618,y1:236,x2:590,y2:194},
							]},
			{Pieza:"26",IniTrazo:{x:0,y:0},Cara:"transparent",
					lCurva:[{x1:630,y1:243,x2:680,y2:192},
							{x1:678,y1:245,x2:634,y2:188},
							]},
			{Pieza:"27",IniTrazo:{x:0,y:0},Cara:"transparent",
					lCurva:[{x1:694,y1:243,x2:735,y2:192},
							{x1:734,y1:245,x2:692,y2:187},
							]},
			{Pieza:"28",IniTrazo:{x:0,y:0},Cara:"transparent",
					lCurva:[{x1:749,y1:240,x2:785,y2:199},
							{x1:786,y1:241,x2:746,y2:191},
							]},
			{Pieza:"48",IniTrazo:{x:0,y:0},Cara:"transparent",
					lCurva:[{x1:20,y1:423,x2:71,y2:381},
							{x1:70,y1:424,x2:27,y2:374},
							]},
			{Pieza:"47",IniTrazo:{x:0,y:0},Cara:"transparent",
					lCurva:[{x1:80,y1:420,x2:135,y2:380},
							{x1:137,y1:422,x2:89,y2:374},
							]},
			{Pieza:"46",IniTrazo:{x:0,y:0},Cara:"transparent",
					lCurva:[{x1:148,y1:420,x2:199,y2:377},
							{x1:207,y1:418,x2:151,y2:378},
							]},
			{Pieza:"45",IniTrazo:{x:0,y:0},Cara:"transparent",
					lCurva:[{x1:214,y1:421,x2:243,y2:383},
							{x1:249,y1:420,x2:218,y2:384},
							]},
			{Pieza:"44",IniTrazo:{x:0,y:0},Cara:"transparent",
					lCurva:[{x1:256,y1:419,x2:290,y2:386},
							{x1:292,y1:418,x2:260,y2:384},
							]},
			{Pieza:"43",IniTrazo:{x:0,y:0},Cara:"transparent",
					lCurva:[{x1:298,y1:416,x2:331,y2:381},
							{x1:338,y1:416,x2:303,y2:381},
							]},
			{Pieza:"42",IniTrazo:{x:0,y:0},Cara:"transparent",
					lCurva:[{x1:340,y1:411,x2:364,y2:384},
							{x1:365,y1:410,x2:346,y2:386},
							]},
			{Pieza:"41",IniTrazo:{x:0,y:0},Cara:"transparent",
					lCurva:[{x1:371,y1:411,x2:395,y2:384},
							{x1:397,y1:412,x2:376,y2:384},
							]},
			{Pieza:"31",IniTrazo:{x:0,y:0},Cara:"transparent",
					lCurva:[{x1:401,y1:411,x2:425,y2:384},
							{x1:429,y1:412,x2:407,y2:385},
							]},
			{Pieza:"32",IniTrazo:{x:0,y:0},Cara:"transparent",
					lCurva:[{x1:433,y1:412,x2:455,y2:383},
							{x1:459,y1:411,x2:439,y2:380},
							]},
			{Pieza:"33",IniTrazo:{x:0,y:0},Cara:"transparent",
					lCurva:[{x1:464,y1:416,x2:495,y2:378},
							{x1:503,y1:416,x2:471,y2:381},
							]},
			{Pieza:"34",IniTrazo:{x:0,y:0},Cara:"transparent",
					lCurva:[{x1:507,y1:417,x2:541,y2:388},
							{x1:543,y1:417,x2:512,y2:387},
							]},
			{Pieza:"35",IniTrazo:{x:0,y:0},Cara:"transparent",
					lCurva:[{x1:552,y1:417,x2:584,y2:385},
							{x1:585,y1:419,x2:556,y2:384},
							]},
			{Pieza:"36",IniTrazo:{x:0,y:0},Cara:"transparent",
					lCurva:[{x1:595,y1:426,x2:651,y2:379},
							{x1:652,y1:423,x2:597,y2:378},
							]},
			{Pieza:"37",IniTrazo:{x:0,y:0},Cara:"transparent",
					lCurva:[{x1:662,y1:426,x2:719,y2:382},
							{x1:718,y1:426,x2:668,y2:379},
							]},
			{Pieza:"38",IniTrazo:{x:0,y:0},Cara:"transparent",
					lCurva:[{x1:730,y1:426,x2:780,y2:380},
							{x1:776,y1:425,x2:731,y2:380},
							]},

					];

var odon =[{Pieza:18,fig:{x1:5,y1:10,x2:55,y2:290}},
					{Pieza:17,fig:{x1:60,y1:10,x2:55,y2:290}},
					{Pieza:16,fig:{x1:115,y1:10,x2:60,y2:290}},
					{Pieza:15,fig:{x1:175,y1:10,x2:42,y2:290}},
					{Pieza:14,fig:{x1:217,y1:10,x2:44,y2:290}},
					{Pieza:13,fig:{x1:261,y1:10,x2:46,y2:290}},
					{Pieza:12,fig:{x1:307,y1:10,x2:40,y2:290}},
					{Pieza:11,fig:{x1:347,y1:10,x2:52,y2:290}},
					{Pieza:21,fig:{x1:399,y1:10,x2:52,y2:290}},
					{Pieza:22,fig:{x1:451,y1:10,x2:42,y2:290}},
					{Pieza:23,fig:{x1:493,y1:10,x2:45,y2:290}},
					{Pieza:24,fig:{x1:538,y1:10,x2:43,y2:290}},
					{Pieza:25,fig:{x1:581,y1:10,x2:43,y2:290}},
					{Pieza:26,fig:{x1:624,y1:10,x2:60,y2:290}},
					{Pieza:27,fig:{x1:684,y1:10,x2:56,y2:290}},
					{Pieza:28,fig:{x1:740,y1:10,x2:55,y2:290}},
					//abajo
					{Pieza:48,fig:{x1:15,y1:320,x2:60,y2:279}},
					{Pieza:47,fig:{x1:75,y1:320,x2:65,y2:279}},
					{Pieza:46,fig:{x1:140,y1:320,x2:68,y2:279}},
					{Pieza:45,fig:{x1:208,y1:320,x2:44,y2:279}},
					{Pieza:44,fig:{x1:252,y1:320,x2:43,y2:279}},
					{Pieza:43,fig:{x1:295,y1:320,x2:43,y2:279}},
					{Pieza:42,fig:{x1:338,y1:320,x2:30,y2:279}},
					{Pieza:41,fig:{x1:368,y1:320,x2:32,y2:279}},
					{Pieza:31,fig:{x1:400,y1:320,x2:31,y2:279}},
					{Pieza:32,fig:{x1:431,y1:320,x2:31,y2:279}},
					{Pieza:33,fig:{x1:462,y1:320,x2:43,y2:279}},
					{Pieza:34,fig:{x1:505,y1:320,x2:43,y2:279}},
					{Pieza:35,fig:{x1:548,y1:320,x2:44,y2:279}},
					{Pieza:36,fig:{x1:592,y1:320,x2:68,y2:279}},
					{Pieza:37,fig:{x1:660,y1:320,x2:63,y2:279}},
					{Pieza:38,fig:{x1:723,y1:320,x2:62,y2:279}},
					]	;		

var vimplan =[{Pieza:"18I",fig:{x1:10,y1:47,x2:40,y2:80}},
					{Pieza:"17I",fig:{x1:65,y1:47,x2:40,y2:80}},
					{Pieza:"16I",fig:{x1:120,y1:42,x2:50,y2:80}},
					{Pieza:"15I",fig:{x1:182,y1:35,x2:30,y2:90}},
					{Pieza:"14I",fig:{x1:222,y1:35,x2:34,y2:90}},
					{Pieza:"13I",fig:{x1:268,y1:20,x2:34,y2:100}},
					{Pieza:"12I",fig:{x1:312,y1:35,x2:30,y2:90}},
					{Pieza:"11I",fig:{x1:353,y1:15,x2:40,y2:100}},
					{Pieza:"21I",fig:{x1:408,y1:30,x2:37,y2:90}},
					{Pieza:"22I",fig:{x1:458,y1:35,x2:30,y2:90}},
					{Pieza:"23I",fig:{x1:498,y1:20,x2:35,y2:100}},
					{Pieza:"24I",fig:{x1:545,y1:35,x2:32,y2:90}},
					{Pieza:"25I",fig:{x1:589,y1:35,x2:30,y2:90}},
					{Pieza:"26I",fig:{x1:629,y1:20,x2:54,y2:105}},
					{Pieza:"27I",fig:{x1:695,y1:47,x2:40,y2:80}},
					{Pieza:"28I",fig:{x1:748,y1:47,x2:40,y2:80}},
					//abajo
					{Pieza:"48I",fig:{x1:16,y1:495,x2:55,y2:90}},
					{Pieza:"47I",fig:{x1:76,y1:495,x2:60,y2:95}},
					{Pieza:"46I",fig:{x1:140,y1:495,x2:68,y2:95}},
					{Pieza:"45I",fig:{x1:215,y1:495,x2:30,y2:95}},
					{Pieza:"44I",fig:{x1:259,y1:495,x2:30,y2:95}},
					{Pieza:"43I",fig:{x1:301,y1:502,x2:31,y2:95}},
					{Pieza:"42I",fig:{x1:341,y1:502,x2:23,y2:95}},
					{Pieza:"41I",fig:{x1:374,y1:502,x2:21,y2:95}},
					{Pieza:"31I",fig:{x1:405,y1:502,x2:21,y2:95}},
					{Pieza:"32I",fig:{x1:434,y1:502,x2:22,y2:95}},
					{Pieza:"33I",fig:{x1:467,y1:502,x2:32,y2:95}},
					{Pieza:"34I",fig:{x1:511,y1:495,x2:30,y2:95}},
					{Pieza:"35I",fig:{x1:553,y1:495,x2:30,y2:95}},
					{Pieza:"36I",fig:{x1:595,y1:495,x2:60,y2:95}},
					{Pieza:"37I",fig:{x1:663,y1:495,x2:60,y2:95}},
					{Pieza:"38I",fig:{x1:728,y1:495,x2:55,y2:90}},
					]	;						


					var estadopieza="";
// Get all buttons with class="btn" inside the container
var btns2 = btnContainer2.getElementsByClassName("btn");
for (var i = 0; i < btns2.length; i++) {
  	btns2[i].addEventListener("click", function() {
  		//btnContainer2.style.width="400px";
  		//btnContainer2.style.height="100px";
  		//document.getElementById("myDIV").style.right="0px";
  		//document.getElementById("myDIV").classList.add('desp1');
  		if (this.className.indexOf("btn-success")!=-1){
  			//alert(this.className.indexOf("btn-success"));	
  			estadopieza=EnumEstado.Previo;
  			
  		}
  		if (this.className.indexOf("btn-danger")!=-1){
  			estadopieza=EnumEstado.Realizado;

  		}
  		if (this.className.indexOf("btn-primary")!=-1){
  			estadopieza=EnumEstado.ARealizar;

  		}

  		btnContainer2.classList.remove("m-fadeIn");
  		btnContainer2.classList.add("m-fadeOut");
  		btnContainer2.style.left="-1000px";
  		btnContainer2.style.width="0px";
		btnContainer2.style.height="0px";

  		});
  };
// Loop through the buttons and add the active class to the current/clicked button
//var btns = document.getElementsByClassName("btn");

for (var i = 0; i < btns.length; i++) {
  btns[i].addEventListener("click", function() {
  	//var position = this.offset();
	//alert(this.offsetLeft);
  	
  		sbtn = this.id;
  	
  	//document.getElementById("myDIV").style.top = "100px";
  	//this.className += " example-toggled-element";
  	//this.classList.add('example-toggled-element');
  	//this.style.top="200px";
  	//var el=document.getElementById("myDIV2");
  	btnContainer2.classList.remove("m-fadeOut");
  	//var el=document.getElementsByClassName("example-relative");
	btnContainer2.style.width="0px";
	btnContainer2.style.height="0px";

	btnContainer2.style.left=this.offsetLeft +200+"px";
	btnContainer2.style.top=350+"px";
	btnContainer2.classList.add("m-fadeIn");
	btnContainer2.style.width="260px";
  	btnContainer2.style.height="80px";
	//el.style.display="none";
  	//document.getElementById("myDIV").style.right="1000px";
  	//document.getElementById("myDIV").style.right="1000px";
  	//document.getElementById("myDIV").style.top = this.style.top;
  	//document.getElementById("myDIV").classList.remove('desp');
  	//document.getElementById("myDIV").classList.add("m-fadeOut");
  	//setTimeout(function () {
  	//	el.style.width="400px";
  	//	el.style.height="100px";
  		//document.getElementById("myDIV").style.right="0px";
  		//document.getElementById("myDIV").classList.add('desp1');
  	//	el.classList.remove("m-fadeIn");
  	//	el.classList.add("m-fadeOut");
        //document.getElementById("myDIV").classList.add('hide');
    //}, 2000);

  	
  	
  	//alert(this.style.top);
    //var current = document.getElementsByClassName("active");
    //current[0].className = current[0].className.replace(" active", "");
    //this.className += " active";
  });
}
// var btnAbrirPopup = document.getElementById('btn-prueba-popup');
// btnAbrirPopup.addEventListener('click', function(){
// 	var scliente =[{IdCliente:"18I",Nombre:"Gaston, Pellegrini",DNI:"22222222",FechaNacimiento:"1980-03-20",ObraSocial:"Swiss Medical",Plan:"SG 3",HCI:"22235",Domicilio:"Centenera 2686",Localidad:"CABA",Barrio:"Pompeya",tel:"498292022",cel:"1559829202" },
// 					{IdCliente:"11D",Nombre:"Silvio Molina",DNI:"22222222",FechaNacimiento:"1980-03-20",ObraSocial:"OSDE",Plan:"410",HCI:"22236",Domicilio:"Alvarez Thomas 1410",Localidad:"CABA",Barrio:"Chacarita",tel:"1235548",cel:"1111111"}];
// 	var shtml='';
// 	abrirpupup(scliente,"Cliente","Buscar cliente");
// });
// var btnAbrirOSPopup = document.getElementById('btn-OS-popup');
// btnAbrirOSPopup.addEventListener('click', function(){
// 	var scliente =[{IdPlan:"1",ObraSocial:"Swiss Medical",Plan:"SG 3"},{IdPlan:"2",ObraSocial:"OSDE",Plan:"410"},];
// 	var shtml='';
// 	abrirpupup(scliente,"Obra Social","Buscar plan obra social");
// });