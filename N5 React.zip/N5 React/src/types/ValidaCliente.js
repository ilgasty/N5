var form = document.getElementById("example-date-input");
form.addEventListener("change", function( event ) {
	var d = form.value;
    var inDate = new Date(d);
    var anio = inDate.getFullYear();
    var fec_actual = new Date() ; 
 var fec_anio = fec_actual.getFullYear() ;
    var edad   =  fec_anio -anio ;
    document.getElementById("IdEdad").value=edad;
  //event.target.style.background = "pink";
}, true);
var btnAbrirPopup = document.getElementById('btn-abrir-popup'),
	overlay = document.getElementById('overlay'),
	popup = document.getElementById('popup'),
	btnCerrarPopup = document.getElementById('btn-cerrar-popup');
	//txtbusquedaPopup=document.getElementById('txt-busqueda-popup');

btnAbrirPopup.addEventListener('click', function(){

	abrirpupup();

	
	

});
/*
btnCerrarPopup.addEventListener('click', function(e){
	e.preventDefault();
	
	
	overlay.classList.remove('active');
	popup.classList.remove('active');
});*/
function abrirpupup(objbuscar,titulo,subtitulo){
	//let approved = objbuscar.filter(student => student[2] >= 11);
	
	overlay.classList.add('active');
	popup.classList.add('active');
	var divAbrirPopup = document.getElementById('popup'),
		shtml="";
			
       shtml='';
       shtml=shtml + '<button class="btn-cerrar-popup" id="btn-cerrar-popup">Close</button>';
       shtml=shtml +' <h3>'+titulo+'</h3> <h4>'+ subtitulo +'</h4> <form action=""> <div class="contenedor-inputs">';
       shtml=shtml + '<input id="txt-busqueda-popup" type="text" placeholder="Nombre">  </div>';
       shtml=shtml +' </form> ';
	shtml= shtml +'<table class="table table-hover">';
	var scliente=objbuscar
	for (var i in scliente) {
	//alert(" Propiedad: "+ i + " Valor: " + scliente[i]);
		shtml= shtml + '<tr class="row" id="'+i+'">';
		var filt=0;
		var aprueba=JSON.stringify(scliente[i]);
		for( j in scliente[i] ){
			
			if (filt<3){
				shtml= shtml + '<td >' + scliente[i][j] + '</td>';
			}
			
       		filt++;
			
			//alert(" Propiedad: "+ j + " Valor: " + scliente[i][j]);
		}
		
		shtml= shtml + '</tr>';
	}
	shtml= shtml + '</table>';
    divAbrirPopup.innerHTML= shtml;
    for (var i in scliente) {
		var div=document.getElementById(i);
    	div.addEventListener('click', function(e){
			var index=this.id;
			for( j in scliente[index] ){
				var prop=document.getElementById(j);
				if (prop!=null){
					prop.value=scliente[index][j]
				}
			}
		overlay.classList.remove('active');
		popup.classList.remove('active');
		});
	}
    
    btnCerrarPopup=document.getElementById('btn-cerrar-popup');
	btnCerrarPopup.addEventListener('click', function(e){
	
		overlay.classList.remove('active');
		popup.classList.remove('active');
	});

	var txtbusquedaPopup=document.getElementById('txt-busqueda-popup');
	txtbusquedaPopup.addEventListener('keyup', function(e){
			e.preventDefault();
		for (var i in scliente) {
			var aprueba=JSON.stringify(scliente[i]);
			for( j in scliente[i] ){
				alert(" Propiedad: "+ j + " Valor: " + scliente[i][j]);
			}
			shtml= shtml + '</tr>';
		}
	});
       //alert(shtml);
}

export default  abrirpupup;
