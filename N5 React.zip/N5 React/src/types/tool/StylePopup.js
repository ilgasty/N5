import React from 'react';
import { makeStyles } from '@material-ui/core/styles';

const drawerWidth = 240;

export const StylePopup = makeStyles((theme) =>( 
    {
		bgmodal:{
			backgroundColor: 'rgba(0,0,0,0.75)',
			transition: "all 0.3s ease-in-out",
		},
		
		modal : {
			position: 'absolute',
			 top: '50%',
			 left: '50%',
			overflow: 'auto',
			width: '100%',
			height:'100%',
			//padding:'10%',
	
			alignContent:'center',
			backgroundColor:'White',
			bgcolor: 'background.paper',
			border: '2px solid #000',
			transform: 'translate(-50%, -50%)',
			transition: "all 0.3s ease-in-out",
			"&:hover":{
				boxShadow: '0px 7px 8px -4px rgb(0 0 0 / 20%), 0px 12px 17px 2px rgb(0 0 0 / 14%), 0px 5px 22px 4px rgb(0 0 0 / 12%)',
				transition: "all 0.3s ease-in-out",
				//height:'70%',
				//width: '50%',
				//top: '20px',
				//left: '50px',
				
			}
			
		  },
		
	}
	));