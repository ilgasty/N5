import React from 'react';
import { makeStyles } from '@material-ui/core/styles';

const drawerWidth = 240;

export const StyleAnimation = makeStyles((theme) =>( 
    {
		mini:{
			height:0,
			visibility:"hidden",
			
			position:'absolute',
		},
		EffAnima:{
			display:"flex",
			//animation: "$card2 ease 3s",
			animation: "$card 2s infinite",
			//transform: "rotate(360deg)",
			animation: "$card2 ease 3s",
			transition: "all 0.3s ease-in-out",
		},
		
		Desaparece:{
			visibility:"hidden",
			//width:0,
			transform: "scale(0.5)",
			//transform: "rotate(360deg)",
			//animation: "$card2 ease 3s",
			//transition: "all 0.3s ease-in-out",
		},
		Aparece:{
			visibility:"visible",
			//width:0,
			transform: "scale(0.5)",
			//transform: "rotate(360deg)",
			animation: "$card2 ease 3s",
			//transition: "all 0.3s ease-in-out",
		},
		TextAnim:{
			display:"flex",
			//animation: "$card2 ease 3s",
			width:80,
			//transform: "rotate(360deg)",
			
			transition: "all 0.3s ease-in-out",
		},
		TextDes:{
			visibility:"hidden",
			width:0,
			transform: "scale(0.5)",
			//transform: "rotate(360deg)",
			animation: "$card2 ease 3s",
			//transition: "all 0.3s ease-in-out",
		},
		Card:{
			//display: 'flex',
			//width:"49%",
			margin:2,
			padding:5,
			"&:hover":{
				boxShadow: '0px 7px 8px -4px rgb(0 0 0 / 20%), 0px 12px 17px 2px rgb(0 0 0 / 14%), 0px 5px 22px 4px rgb(0 0 0 / 12%)',
				transition: "all 0.3s ease-in-out",
				
				
			}
			
		},
		CardMedia:{
			transition: "all 0.3s ease-in-out",	
			transform: "rotate(360deg)",
			animation: "$pulse ease 3s",
			"&:hover": {
				//top:-50,
				//marginLeft: -500,
				transform: "scale(1.01)",
				transition: "all 0.3s ease-in-out",
				backgroundColor: "#333",
			  },
			  
		},
		buttonanima: {
			
			//borderRadius: "50%",
			animation: "$pulse 2s infinite",
		  },
		Box:{ display: 'flex', flexDirection: 'column', margin: 10,
		 //opacity:0,
		 //transition: "all 0.3s ease-in-out",
		 animation: "$card ease 3s"
		  },
		BoxActive:{ display: 'flex', flexDirection: 'column', 
		 margin: 10,
		 
		  animation: "$card2 ease 3s"
		  //opacity: 1
		  },
		  pulse: {
			background: "black",
			borderRadius: "50%",
			margin: 10,
			height: 20,
			width: 20,
			boxShadow: "0 0 0 0 rgba(0, 0, 0, 1)",
			transform: "scale(1)",
			animation: "$pulse 2s infinite"
		  },
		  "@keyframes pulse": {
			"0%": {
			  transform: "scale(0.95)",
			  boxShadow: "0 0 0 0 rgba(0, 0, 0, 0.7)"
			},
			"70%": {
			  transform: "scale(1)",
			  boxShadow: "0 0 0 10px rgba(0, 0, 0, 0)"
			},
			"100%": {
			  transform: "scale(0.95)",
			  boxShadow: "0 0 0 0 rgba(0, 0, 0, 0)"
			}
		  },
		  "@keyframes card2": {
			"0%": {
				opacity: 0,
				//transform: "scale(0.95)",
			},
			"100%": {
				opacity: 1
			}
		  },
		  "@keyframes card": {
			"0%": {
				opacity: 0
			},
			"100%": {
				opacity: 1
			}
		  }
	}
	));