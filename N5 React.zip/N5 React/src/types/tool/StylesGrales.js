import React from 'react';
import { makeStyles } from '@material-ui/core/styles';

const drawerWidth = 240;

export const StylesGrales = makeStyles((theme) =>( 
    {
        paper: {
            marginTop: 8,
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            // width:"100%",
            // marginLeft: "60px",

        },
        paperItems:{
            marginTop: 4,
            display: "flex",
            flexDirection: "column",
            width:"100%",
            padding: 10 ,
        },
        form: {
            width: "100%",
            marginTop: 20
        },
        submit: {
            marginTop: 15

        },
        avatar: {
            // margin: 5,
            backgroundColor: "#1976d2",
            width: 90,
            height:90
        },
        icon: {
            fontSize:40
        },

        //////////////////////////
        root: {
            display: 'flex',
        },
       
        content: {
        //     flexGrow: 1,
        //     padding: theme.spacing(3),
        //     transition: theme.transitions.create('margin', {
        //         easing: theme.transitions.easing.sharp,
        //         duration: theme.transitions.duration.leavingScreen,
        //     }),
        //     marginLeft: -drawerWidth,

            flexGrow: 1,
            padding: theme.spacing(3),
            marginLeft:  theme.spacing(6) + 1,
            // width: `calc(100%  ${drawerWidth}px)`,
        
            maxWidth: `calc(100% - ${(theme.spacing(6))}px)`,
        },


        /////////styles,mios
            seccionDesktop: {
                display: "none",
                [theme.breakpoints.up("md")]: {
                    display:"flex"
                }
            
            },
            seccionMobile: {
                display: "flex",
                [theme.breakpoints.up("md")]: {
                    display:"none"
                }
            },
            grow: {
                flexGrow:1
            },
            avatarSize: {
                width: 40,
                height: 40
            },
            list: {
                width:240
            },
            listitemtext: {
                fontSize:"14px",
                fontWeight: "600",
                paddingLeft:"17px"
            },
            menuButton: {
                marginRight: 35,
                "&:focus, &.mui-focusVisible": {
                    outline: "0px"
                }
            },
            usuCaption :{
                marginTop:"7px"
            },
            cards: {
                maxWidth: 240,
            }



        ////////////
    }
));