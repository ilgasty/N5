﻿///en esta constante defino como van a distriubuirse los controeles dentro del div
///display:flex siginifica que va uno tras otro
///flexDirection le indico como quiero que vayan, columns esuno abajo de otro
///dato: las pantsallas siemopre se dividen en 12 columnas, con xs, md y sd le indico cuantas columnas de be tomar la grid
///los celulares son xs y las tables md (se usa generalmente tambien para escritorio)
const style = {
    paper: {
        marginTop: 8,
        display: "flex",
        flexDirection: "column",
        alignItems: "center"
    },
    form: {
        width: "100%",
        marginTop: 20
    },
    submit: {
        marginTop: 15

    },
    avatar: {
        // margin: 5,
        backgroundColor: "#1976d2",
        width: 90,
        height:90
    },
    icon: {
        fontSize:40
    },
    buttoefecto: {
        height:0,
		animation: "$card 2s infinite",
	  },
      "@keyframes card": {
		"0%": {
			opacity: 0
		},
		"100%": {
			opacity: 1
		}
	  },
};

export default style;
