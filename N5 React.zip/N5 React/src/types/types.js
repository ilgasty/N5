
export const types = {
    login: '[Auth] Login',
    logout: '[Auth] Logout',
    authCheking: '[auth] Checking login state',
    authChekingFinish: '[auth] Finish Checking login state',
    authStartLogin: '[auth] Start Login',
    authLogin: '[auth] Login',
    authLogout : '[auth] Logout',
    authStartUpdPerfil: '[auth] Start UPDPerfilUsuario',
    authEndUpdPerfil: '[auth] Finish UPDPerfilUsuario',


    uiSetError: '[UI] Set Error',
    uiRemoveError: '[UI] Remove Error',
    uiStartLoading: '[UI] Start loading',
    uiFinishLoading: '[UI] Finish loading',

    noteAddNew: '[Note] New note',
    noteActive: '[Note] Set Active note',
    noteLoad: '[Note] Load  note',
    noteFileURL: '[Note] Update Image URL',
    noteUpdate: '[Note] Update note ',
    noteDelete: '[Note] Delete note',
    noteLogoutCleaning: '[Note] Logout Cleaning  note',

    odontoAddNew: '[ODTGR] Nueva Prestacion',

    filtroStartLoading: '[FLTR] Start Loading',
    filtroFinishLoading: '[FLTR] Finish Loading',
    filtroClean: '[FLTR] Cleaning Filter',
    filtroSetting: '[FLTR] Setting Filter',
    filtroValueSetting: '[FLTR] Setting Value Filter',
    filtroSetFiltroOriginal: '[FLTR] Setting Filtro Original',
    filtroReset: '[FLTR] Reset Filtro',

    carritoAddNew: '[ECOM] Nueva item Carrito',
    carritoUpdate: '[ECOM] Update item Carrito ',
    carritoDeleteAll: '[ECOM] Delet all Carrito ',

}