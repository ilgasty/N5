import { createMuiTheme } from "@material-ui/core";
 import {lightBlue, purple,yellow,} from '@material-ui/core/colors'

export const theme = createMuiTheme({
    palette: {
        primary:{
            main: purple[500]  //el purple viene con todas lasprooiedad del primary ¿, anivel colores
        },
        secondary: {
            main: lightBlue[500]
        }
    }

});
