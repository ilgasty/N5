import { getAllDatos } from "./tipoConvenioAction";
import HttpCliente from '../servicios/HttpCliente';
import axios from 'axios';
import Swal from "sweetalert2";

///Esto se usa para llamar a los servicio que son publico s y no requieren el token
/// loginUsuario
const instanciaConAPI=axios.create();
instanciaConAPI.CancelToken= axios.CancelToken;
instanciaConAPI.isCancel= axios.isCancel;
export const registrarusuario=(entidad)=>{
	return async () =>{
		let respChek= await instanciaConAPI.post('/usuario/registrar', entidad)
	/*	.then( response => {
			//console.log("ok",response.errors)
			let usuarioLog= response.data;

			return usuarioLog;
		})
		.catch(err=>{
			console.log("Error",err.response)
			Swal.fire('Error',err.response.data.errores, 'error');
			return err.response.data
		});*/

		return respChek;
	}
}