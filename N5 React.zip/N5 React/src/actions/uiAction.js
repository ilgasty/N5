import { types } from "../types/types"


export const setErrorAction = ( errmsg ) =>{
    
    return {
        type: types.uiSetError,
        payload: errmsg
    }
}

export const removeErrorAction = ( ) =>{
    
    return {
        type: types.uiRemoveError
    }
}

export const startLoadingAction= () => {
    return {
        type: types.uiStartLoading

    }
}

export const finishLoadingAction = () => {
    return {
        type: types.uiFinishLoading
    }
}

