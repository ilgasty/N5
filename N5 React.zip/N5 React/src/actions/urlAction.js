import { types } from "../types/types";
import HttpCliente from '../servicios/HttpCliente';
import isBoolean from "validator/lib/isBoolean";

export const getAllDatos =  (url,entidad) => {
   
    return async (dispatch) =>{
        //console.log("Entidad", entidad);
        // const respuesta= await fetchConToken('auth/renew'); //al ser un get puedo pasar solo el endpoint
       let respChek=  await HttpCliente.get(`/${url}`)
                        .then( resp => {
                            
                           if (typeof(resp.data)=="boolean"){
                            return resp.data;
                           }
                             let datosAll= resp.data;
                            datosAll.ok=true;
                            
                            return datosAll;
                        })
                        .catch( err => {
                            //console.log(err);
                            return {ok: false,error:err}
                        });
       
        return respChek;
    }

};
export const posDatos =  (url,entidad) => {
   
    return async (dispatch) =>{
        //console.log("Entidad", entidad);
        // const respuesta= await fetchConToken('auth/renew'); //al ser un get puedo pasar solo el endpoint
       return await HttpCliente.post(`/${url}`,entidad)
                        .then( resp => {
                           
                             let datosAll= resp.data;
                        
                            return datosAll;
                        })
                        .catch( err => {
                            console.log("Error url",err);
                            let datosAll={error: err,ok:false};
                            return datosAll
                        });
       
        //return respChek;
    }

};
export const putDatos =  (url,entidad) => {
   
    return async (dispatch) =>{
        //console.log("Entidad", entidad);
        // const respuesta= await fetchConToken('auth/renew'); //al ser un get puedo pasar solo el endpoint
       return await HttpCliente.put(`/${url}`,entidad)
                        .then( resp => {
                           
                             let datosAll= resp.data;
                        
                            return datosAll;
                        })
                        .catch( err => {
                            console.log("Error url",err);
                            let datosAll={error: err,ok:false};
                            return datosAll
                        });
       
        //return respChek;
    }

};
export const posDatos2 =  (url,entidad) => {
   
    return async (dispatch) =>{
        //console.log("Entidad", entidad);
        // const respuesta= await fetchConToken('auth/renew'); //al ser un get puedo pasar solo el endpoint
        await HttpCliente.post(`/${url}`,entidad)
                        .then( resp => {
                             let datosAll= resp.data;
                            datosAll.ok=true;
                            return datosAll;
                        })
                        .catch( err => {
                            console.log("Error url",err);
                            return {err}
                        });
       
        //return respChek;
    }

};