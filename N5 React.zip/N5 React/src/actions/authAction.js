import Swal from 'sweetalert2';
import { types } from "../types/types";
import { finishLoadingAction, startLoadingAction } from './uiAction';
import HttpCliente from '../servicios/HttpCliente';
import axios from 'axios';

///Esto se usa para llamar a los servicio que son publico s y no requieren el token
/// loginUsuario
const instanciaConAPI=axios.create();
instanciaConAPI.CancelToken= axios.CancelToken;
instanciaConAPI.isCancel= axios.isCancel;

export const starLoginEmailPassword= ( email, password)=>{

    return  async  (dispatch)=>{
        //aca se podrina hacer varios dispatch

        dispatch( startLoadingAction() );

        const usuario={
            email,
            password
        }
        //console.log(usuario);
            
        await instanciaConAPI.post('/usuario/login', usuario)
            .then( response => {

                let usuarioLog= response.data;

                if(usuarioLog && usuarioLog.imagenPerfil){
                    let foto=usuarioLog.imagenPerfil;
                    const nuevaFoto="data:image/" + foto.extension + ";base64," + foto.data;
                    usuarioLog.imagenPerfil=nuevaFoto;
                };

                //Guardo el token el el lcalStorage
                localStorage.setItem('token', usuarioLog.token);
                localStorage.setItem('token-initDate', new Date().getTime());

                console.log(usuarioLog);
                // usuario: {
                    // //     nombreCompleto: '',
                    // //     email: '',
                    // //     userName: '',
                    // //     foto:''
                    
                    // // },
                    // // autenticado:false
                    
                dispatch( loginAction( usuarioLog ));
                Swal.fire('Bienvenido',usuarioLog.nombreCompleto,'success');
                dispatch ( finishLoadingAction());
            })
            .catch( e => {   ///capturo el error y lo paso como respuesta al componente
                        //resolve(error.response)
                        //console.log(e);
                        if (e.response) {
                            console.log(e.response.data.errores);
                            Swal.fire('Error',e.response.data.errores.mensaje, 'error'); //estoy pasando el texto del error que viene de firebase

                        }else {
                            Swal.fire('Error','Error Conexión', 'error'); //estoy pasando el texto del error que viene de firebase
                        }
                        //console.log(e.response);
                        dispatch ( finishLoadingAction());
            });
    }
    //retorna un callback, que tiene como parametro el disparch, que me lo proporciona thunk (middleware)
}

export const loginAction = ( usuarioLog) => {
    //console.log('paso por el loginAction');

        let usuario={...usuarioLog};

        //saco datos que no quiero guardar en el contexto(redux<9)
        delete usuario['ok'];
        delete usuario['token'];

        return {
            type: types.authLogin,
            payload: {
                usuario,
                autenticado: true
            }
        }
}




//cheuqeo el token si es valido y si esta almacendao ppor si refresca la pantalla
/// cuanto 
export const startChecking =  () => {
    return async (dispatch) =>{
        dispatch(checkingFinish ());
      
    }

};


export const actualizarUsuario = (usuario) => {
    return async(dispatch) => {
       
        dispatch(startUpdPerfilUsuario());

        const respUpdUsr= await HttpCliente.put('/usuario/updusuario', usuario)
            .then(response => {
                if(response.data && response.data.imagenPerfil){
                    let fotoperfil=response.data.imagenPerfil;
                    const nuevaFoto="data:image/" + fotoperfil.extension + ";base64," + fotoperfil.data;
                    response.data.imagenPerfil=nuevaFoto;
                };
                
                console.log(response.data);
                
                return response.data;

            })
            .catch(err => {   ///capturo el error y lo paso como respuesta al componente
                console.log(err.response);
                if (err.response) {
                    console.log(err.response.data.errores);
                    Swal.fire('Error',err.response.data.errores.mensaje, 'error'); //estoy pasando el texto del error que viene de firebase

                }else {
                    Swal.fire('Error','Error Conexión', 'error'); //estoy pasando el texto del error que viene de firebase
                }
                return {ok: false}
            });

            if (respUpdUsr.ok) {   //elok viene de mi respuesta de la api
                console.log("Actualzio Bien!");
                dispatch (loginAction(respUpdUsr));
                Swal.fire('Actualizacion realizada con éxito','','success');

                
           }else {
                console.log("Actualizo mal!!");
              
           }
           dispatch(finishUpdPerfilUsuario());
    };
};


///////ACTUALIZACION PARCIAL DATOS DEL USUARIO ///////////////////////////

export const actualizarUsuarioParcial = (usuario) => {
    return async(dispatch) => {
       
        dispatch(startUpdPerfilUsuario());

        const respUpdUsr= await HttpCliente.put('/usuario/updusrpartial', usuario)
            .then(response => {
                if(response.data && response.data.imagenPerfil){
                    let fotoperfil=response.data.imagenPerfil;
                    const nuevaFoto="data:image/" + fotoperfil.extension + ";base64," + fotoperfil.data;
                    response.data.imagenPerfil=nuevaFoto;
                };
                
                console.log(response.data);
                
                return response.data;

            })
            .catch(err => {   ///capturo el error y lo paso como respuesta al componente
                console.log(err.response);
                if (err.response) {
                    console.log(err.response.data.errores);
                    Swal.fire('Error',err.response.data.errores.mensaje, 'error'); //estoy pasando el texto del error que viene de firebase

                }else {
                    Swal.fire('Error','Error Conexión', 'error'); //estoy pasando el texto del error que viene de firebase
                }
                return {ok: false}
            });

            if (respUpdUsr.ok) {   //elok viene de mi respuesta de la api
                console.log("Actualzio Bien!");
                dispatch (loginAction(respUpdUsr));
                Swal.fire('Actualizacion realizada con éxito','','success');

                
           }else {
                console.log("Actualizo mal!!");
              
           }
           dispatch(finishUpdPerfilUsuario());
    };
};


///////ACTUALIZACION PASSWORD DATOS DEL USUARIO ///////////////////////////

export const actualizarUsuarioPass = (usuario) => {
    return async(dispatch) => {
       
        dispatch(startUpdPerfilUsuario());

        const respUpdUsr= await HttpCliente.put('/usuario/updusrpass', usuario)
            .then(response => {
                if(response.data && response.data.imagenPerfil){
                    let fotoperfil=response.data.imagenPerfil;
                    const nuevaFoto="data:image/" + fotoperfil.extension + ";base64," + fotoperfil.data;
                    response.data.imagenPerfil=nuevaFoto;
                };
                
                console.log(response.data);
                
                return response.data;

            })
            .catch(err => {   ///capturo el error y lo paso como respuesta al componente
                console.log(err.response);
                if (err.response) {
                    console.log(err.response.data.errores);
                    Swal.fire('Error',err.response.data.errores.mensaje, 'error'); //estoy pasando el texto del error que viene de firebase

                }else {
                    Swal.fire('Error','Error Conexión', 'error'); //estoy pasando el texto del error que viene de firebase
                }
                return {ok: false}
            });

            if (respUpdUsr.ok) {   //elok viene de mi respuesta de la api
                console.log("Actualzio Bien!");
                dispatch (loginAction(respUpdUsr));
                Swal.fire('Actualizacion realizada con éxito','','success');

                
           }else {
                console.log("Actualizo mal!!");
              
           }
           dispatch(finishUpdPerfilUsuario());
    };
};



const checkingFinish =()=>({
    type: types.authChekingFinish
});

export const startLogout = () =>{

    return (dispatch) =>{

        localStorage.clear();  ///borrot el token, etc que tengo en el lovalstorage

        dispatch( logout() );
    }
};

const logout = () => ({ type: types.authLogout});

const startUpdPerfilUsuario = () => {
    return  {
        type: types.authStartUpdPerfil
    }
};

const finishUpdPerfilUsuario = () => {
    return  {
        type: types.authEndUpdPerfil
    }
}

// export const loginUsuario = (usuario,dispatch) => {
//     return new Promise((resolve, eject) => {
//         instanciaConAPI.post('/usuario/login', usuario).then(response => {
//             if(response.data && response.data.imagen){
//                 let foto=response.data.imagen;
//                 const nuevaFoto="data:image/" + foto.extension + ";base64," + foto.data;
//                 response.data.imagen=nuevaFoto;
//             };
            
//             //actualziao la variable global
//             dispatch ({
//                 type: "INICIAR_SESION",
//                 usuario:response.data,
//                 autenticado:true
//             });
//             resolve(response);
//         }).catch(error => {   ///capturo el error y lo paso como respuesta al componente
//             resolve(error.response)
//         });

//     });

// };





// export const startRegisterWithEmailandPassword= ( email, password, name ) =>{
// //como es asyncronoc devuelve un callback
// return ( dispatch ) =>{
//         firebase.auth().createUserWithEmailAndPassword ( email, password )
//         .then ( async ({ user }) => {
//             ///como no tengo el displayname en el on¿bejto user (si es log por redes sociales si) actualizo el dato en firestore con la soguiente instruccion
//             await user.updateProfile({
//                 displayName:name
//             });
//             // console.log(user);
//             dispatch( loginAction( user.uid, user.displayName ) )
//         })
//         .catch(e => {
//             //console.log('error',e);
//             Swal.fire('Error',e.message, 'error'); //estoy pasando el texto del error que viene de firebase
//         })
// }

// }



// export const startGoogleLogin= () =>{

// return (dispatch) =>{

//     firebase.auth().signInWithPopup(googleAuthProvider)  //devuelve una promesa
//         .then ( ({ user }) => {
//             dispatch( loginAction( user.uid, user.displayName ) )
//             //console.log(userCred);
//         })
//         .catch(e => {
//             console.log('error',e);
//         })
// }

// }


//en el objeto no pongo uid:uid porque son el mismo nombre. pero se puede poner igual 

// export const logoutAction = () =>{
// return {
//     type: types.logout
// }
// }

// ///esta funciona hace el logout de firebase y es asyncrono
// export const starLogout= () => {

// return async (dispatch) => {
//      await firebase.auth().signOut(); //esto devuelvo una promesa deberia en el then  esta el ok y en el catch el error del motivo por el cual no se pudo hacer logout en firebase
//                                 //para el ejemplo no lo ponemos
//     dispatch( logoutAction() );
// }

//}
